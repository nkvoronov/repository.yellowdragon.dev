# -*- coding: utf8 -*-

import urllib.parse
import re
import json
import xbmcgui

from urllib.parse import urlunparse, urlencode

from lib.tools import addon
from lib.tools import utils

BASE_HOSTNAME_CAA = 'coverartarchive.org'

class CoverArtArchive(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('CoverArtArchive.__init__')

    def _caa_request(self, mbid, imageid=None, size=None, entitytype='release'):
        utils.log('CoverArtArchive._caa_request')       
        if mbid:
            path = [entitytype, mbid]
        else:
            path = [entitytype, '1']
        if imageid and size:
            path.append("%s-%s" % (imageid, size))
        elif imageid:
            path.append(imageid)
        url = urlunparse((
            'http',
            BASE_HOSTNAME_CAA,
            '/%s' % '/'.join(path),
            '',
            '',
            ''
        ))
        utils.log('%s' % (url))       
        return utils.get_JSON_response(url=url, cache_days=1, folder='CoverArtArchive')
        
    def _json_images(self, response, images):
        utils.log('CoverArtArchive._json_images')       
        if response:
            if response.get('images'):
                for img in response.get('images'):
                    if img.get('front') == True:
                        if img.get('thumbnails'):
                            if img.get('thumbnails').get('large'):
                                images['icon'] = img.get('thumbnails').get('large')
                                break
                            if img.get('thumbnails').get('500'):
                                images['icon'] = img.get('thumbnails').get('500')
                                break
                            if img.get('thumbnails').get('small'):
                                images['icon'] = img.get('thumbnails').get('small')
                                break
                            if img.get('thumbnails').get('250'):
                                images['icon'] = img.get('thumbnails').get('250')
                                break
        
        return images

    def get_image_list(self, releaseid, images):
        utils.log('CoverArtArchive.get_image_list')
        response = self._caa_request(releaseid)       
        return self._json_images(response, images)

    def get_release_group_image_list(self, releasegroupid, images):
        utils.log('CoverArtArchive.get_release_group_image_list')        
        response = self._caa_request(releasegroupid, entitytype='release-group')
        return self._json_images(response, images)
        
    def get_release_group_image_front(self, releasegroupid, size=None):
        utils.log('CoverArtArchive.get_release_group_image_front')
        return self.get_image(releasegroupid, 'front', size=size, entitytype='release-group')
        
    def get_image_front(self, releaseid, size=None):
        utils.log('CoverArtArchive.get_image_front')        
        return self.get_image(releaseid, 'front', size=size)
        
    def get_image_back(self, releaseid, size=None):
        utils.log('CoverArtArchive.get_image_back')        
        return self.get_image(releaseid, 'back', size=size)
        
    def get_image(self, mbid, coverid, size=None, entitytype='release'):
        utils.log('CoverArtArchive.get_image')        
        if isinstance(coverid, int):
            coverid = '%d' % (coverid, )
        if isinstance(size, int):
            size = '%d' % (size, )
        return self._caa_request(mbid, coverid, size=size, entitytype=entitytype)
        
CAA = CoverArtArchive()