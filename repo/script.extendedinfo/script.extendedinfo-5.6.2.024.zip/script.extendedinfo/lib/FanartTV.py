# -*- coding: utf8 -*-

import urllib.parse
import re
import json
import xbmcgui
from urllib.parse import urlunparse, urlencode

from lib.tools import addon
from lib.tools import utils

BASE_HOSTNAME_FANART = 'webservice.fanart.tv'
FANART_TYPES = ['movies/', 'tv/', 'music/', 'music/albums/', 'music/labels/']

class FanartTV(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('FanartTV.__init__')

    def _ft_request(self, id, ftypes):
        utils.log('FanartTV._ft_request')
        args = {}
        
        args['api_key'] = addon.setting('fanarttv_apikey')
        
        path = FANART_TYPES[ftypes]
            
        newargs = []
        for key, value in sorted(args.items()):
            if isinstance(value, str):
                value = value.encode('utf8')
            newargs.append((key, value))
        
        
        url = urlunparse((
            'http',
            BASE_HOSTNAME_FANART,
            '/v3/%s%s' % (path,id),
            '',
            urlencode(newargs),
            ''
        ))
        utils.log('%s' % (url))
        
        return utils.get_JSON_response(url=url, cache_days=1, folder='FanartTV')
        
    def get_movies_images(self, imdb_id, images):
        utils.log('FanartTV.get_movies_images')
        response = self._ft_request(imdb_id, 0)
        images = {}
        if response.get('imdb_id'):
            if response.get('hdmovielogo'):
                images['logo'] = response.get('hdmovielogo')[0].get('url')
            if response.get('moviedisc'):
                images['discart'] = response.get('moviedisc')[0].get('url')            
            if response.get('movielogo'):
                images['logo'] = response.get('movielogo')[0].get('url')
            if response.get('movieposter'):
                images['poster'] = response.get('movieposter')[0].get('url')
            else:
                if poster:
                    images['poster'] = poster
            if response.get('hdmovieclearart'):
                images['clearart'] = response.get('hdmovieclearart')[0].get('url')
            if response.get('moviebackground'):
                images['fanart'] = response.get('moviebackground')[0].get('url')
            else:
                if fanart:
                    images['fanart'] = fanart
            if response.get('moviebanner'):
                images['banner'] = response.get('moviebanner')[0].get('url')
            if response.get('moviethumb'):
                images['icon'] = response.get('moviethumb')[0].get('url')
            else:
                if icon:
                    images['icon'] = icon
        else:    
            if icon:
                images['icon'] = icon
            if poster:
                images['poster'] = poster
            if fanart:
                images['fanart'] = fanart
        return images
           
    def get_tv_images(self, imdb_id, images):
        utils.log('FanartTV.get_tv_images')
        response = self._ft_request(imdb_id, 1)
        if response.get('imdb_id'):
            if response.get('clearlogo'):
                images['tvshow.clearlogo'] = response.get('clearlogo')[0].get('url')
            if response.get('hdtvlogo'):
                images['clearlogo'] = response.get('hdtvlogo')[0].get('url')            
            if response.get('clearart'):
                images['clearart'] = response.get('clearart')[0].get('url')
            if response.get('showbackground'):
                images['tvshow.fanart'] = response.get('showbackground')[0].get('url')
            if response.get('tvthumb'):
                images['icon'] = response.get('tvthumb')[0].get('url')              
            if response.get('seasonposter'):
                images['season.poster'] = response.get('seasonposter')[0].get('url')       
            if response.get('seasonthumb'):
                images['season.icon'] = response.get('seasonthumb')[0].get('url')        
            if response.get('hdclearart'):
                images['tvshow.clearart'] = response.get('hdclearart')[0].get('url')
            if response.get('tvbanner'):
                images['tvshow.banner'] = response.get('tvbanner')[0].get('url')
            if response.get('tvposter'):
                images['tvshow.poster'] = response.get('tvposter')[0].get('url')    
            if response.get('seasonbanner'):
                images['season.banner'] = response.get('seasonbanner')[0].get('url')
        return images
            
    def get_music_images(self, mbid_id, images):
        utils.log('FanartTV.get_music_images')
        response = self._ft_request(mbid_id, 2)
        if response.get('mbid_id'):
            if response.get('artistbackground'):
                images['fanart'] = response.get('artistbackground')[0].get('url')          
            if response.get('artistthumb'):
                images['icon'] = response.get('artistthumb')[0].get('url')
            if response.get('musiclogo'):
                images['artist.clearlogo'] = response.get('musiclogo')[0].get('url')
            if response.get('hdmusiclogo'):
                images['clearlogo'] = response.get('hdmusiclogo')[0].get('url')
        return images
        
    def get_music_albums_images(self, mbid_id, ambid_id, images):
        utils.log('FanartTV.get_music_albums_images')
        response = self._ft_request(mbid_id, 2)
        if response.get('mbid_id'):
            if response.get('artistbackground'):
                images['fanart'] = response.get('artistbackground')[0].get('url') 
            if response.get('artistthumb'):
                images['artist.thumb'] = response.get('artistthumb')[0].get('url')
            if response.get('musiclogo'):
                images['artist.clearlogo'] = response.get('musiclogo')[0].get('url')
            if response.get('hdmusiclogo'):
                images['clearlogo'] = response.get('hdmusiclogo')[0].get('url')
            if response.get('albums'):
                if response.get('albums').get(ambid_id):
                    if response.get('albums').get(ambid_id).get('albumcover'):
                        images['icon'] = response.get('albums').get(ambid_id).get('albumcover')[0].get('url')
                    if response.get('albums').get(ambid_id).get('cdart'):
                        images['discart'] = response.get('albums').get(ambid_id).get('cdart')[0].get('url')
        return images
        
    def get_music_labels_images(self, mbid_id, images):
        utils.log('FanartTV.get_music_labels_images')
        response = self._ft_request(mbid_id, 4)
        if response.get('mbid_id'):
            if response.get('musiclabel'):
                images['label'] = response.get('musiclabel')[0].get('url')
        return images
        
FT = FanartTV()
    
    