# -*- coding: utf8 -*-

from lib.tools import addon
from lib.tools import utils

OMDB_KEY = addon.setting('omdb_apikey')
BASE_URL = 'http://www.omdbapi.com/?apikey=%s&tomatoes=true&plot=full&r=json&%s'

class OMDB(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('OMDB.__init__')

    def get_movie_info(self, imdb_id):
        url = 'i=%s' % (imdb_id)
        results = utils.get_JSON_response(BASE_URL % (OMDB_KEY, url), 20, 'OMDB')
        if not results:
            return None
        return {k: v for (k, v) in results.items() if v != 'N/A'}
        
omdb = OMDB()