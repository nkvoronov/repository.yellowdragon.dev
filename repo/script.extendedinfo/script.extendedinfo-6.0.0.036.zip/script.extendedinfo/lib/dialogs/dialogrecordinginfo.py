# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import unicode_literals

import xbmcgui

from lib.musicbrainz import mb
from lib.dialogs import DialogMusicInfo

from lib.tools import imagetools
from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

ID_CONTROL_PLOT = 132
ID_LIST_RECORDING = 161
ID_LIST_GENRES = 190

chm = ActionHandler(type='alt')

class DialogRecordingInfo(DialogMusicInfo):

    TYPE = 'Song'
    
    TYPE_ALT = 'recording'

    LISTS = [(ID_LIST_RECORDING, 'recordinfo'),
             (ID_LIST_GENRES, 'genres')
    ]
    
    def __init__(self, *args, **kwargs):
        utils.log('DialogRecordingInfo.__init__')
        super(DialogRecordingInfo, self).__init__(*args, **kwargs)
        data = mb.extended_recording_info(recording_id=kwargs.get('id'), release_id=kwargs.get('rid'))
        if not data:
            return None
        self.info, self.lists = data

    def onInit(self):
        utils.log('DialogRecordingInfo.onInit')
        self.get_youtube_vids(self.info.get_property('youtube_search'))
        super(DialogRecordingInfo, self).onInit()

    def onClick(self, control_id):
        utils.log('DialogRecordingInfo.onClick')
        super(DialogRecordingInfo, self).onClick(control_id)
        chm.serve(control_id, self)
        
    @chm.click(ID_CONTROL_PLOT)
    def show_plot(self, control_id):
        utils.log('DialogRecordingInfo.show_plot')
        xbmcgui.Dialog().textviewer(heading=addon.LANG(32037),
                                    text=self.info.get_property('description'))