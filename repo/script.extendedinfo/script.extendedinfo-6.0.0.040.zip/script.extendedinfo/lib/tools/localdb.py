# -*- coding: utf8 -*-

import json
import itertools

from lib.tools import kodijson
from lib.tools import addon
from lib.tools import utils
from lib.tools import AudioItem
from lib.tools import VideoItem
from lib.tools import ItemList

PLUGIN_BASE = 'plugin://script.extendedinfo/?info='

MOVIE_PROPS = ['title', 'genre', 'year', 'rating', 'director', 'trailer',
               'tagline', 'plot', 'plotoutline', 'originaltitle', 'lastplayed',
               'playcount', 'writer', 'studio', 'mpaa', 'cast', 'country',
               'imdbnumber', 'runtime', 'set', 'showlink', 'streamdetails',
               'top250', 'votes', 'file', 'sorttitle',
               'resume', 'setid', 'dateadded', 'tag', 'art', 'userrating', 'ratings', 'uniqueid'
]

TV_PROPS = ['title', 'genre', 'year', 'rating', 'plot',
            'studio', 'mpaa', 'cast', 'playcount', 'episode',
            'imdbnumber', 'premiered', 'votes', 'lastplayed',
            'file', 'originaltitle',
            'sorttitle', 'episodeguide', 'season', 'watchedepisodes',
            'dateadded', 'tag', 'art', 'userrating', 'ratings', 'uniqueid', 'runtime'
]
            
ARTIST_PROPS = ['instrument', 'style', 'mood', 'born', 'formed', 'description', 'genre', 'died',
                'disbanded', 'yearsactive', 'musicbrainzartistid', 'fanart', 'thumbnail', 'art',
                'sortname', 'type', 'gender', 'disambiguation'
]

ALBUM_PROPS = ['title', 'description', 'artist', 'genre', 'theme', 'mood', 'style', 'type',
               'albumlabel', 'rating', 'votes', 'userrating','year', 'musicbrainzalbumid', 
               'musicbrainzalbumartistid', 'fanart', 'thumbnail', 'artistid', 'art'
]

SONG_PROPS = ['title', 'artist', 'albumartist', 'genre', 'year', 'rating', 'album', 'track', 'disc',
              'duration', 'comment', 'lyrics', 'musicbrainztrackid', 'musicbrainzartistid',
              'musicbrainzalbumid', 'musicbrainzalbumartistid', 'playcount', 'fanart', 'thumbnail',
              'file', 'artistid', 'albumid', 'votes', 'userrating', 'mood', 'art', 'samplerate',
              'bitrate', 'channels' 
]

class LocalDB(object):

    def __init__(self, *args, **kwargs):
        utils.log('LocalDB.__init__')
        self.info = {}
        self.artists = []
        self.albums = []

    def get_artists(self):
        """
        get list of artists from db (limited metadata)
        """
        utils.log('LocalDB.get_artists')
        self.artists = kodijson.get_artists(['musicbrainzartistid', 'thumbnail'])
        return self.artists

    def get_similar_artists(self, artist_id):
        """
        get list of artists from db which are similar to artist with *artist_id
        based on LastFM online data
        """
        utils.log('LocalDB.get_similar_artists')
        return None
        if simi_artists is None:
            utils.log('Last.fm didn\'t return proper response')
            return None
        if not self.artists:
            self.artists = self.get_artists()
        artists = ItemList(content_type='artists')
        for simi_artist, kodi_artist in itertools.product(simi_artists, self.artists):
            if kodi_artist['musicbrainzartistid'] and kodi_artist['musicbrainzartistid'] == simi_artist['mbid']:
                artists.append(kodi_artist)
            elif kodi_artist['artist'] == simi_artist['name']:
                data = kodijson.get_json(method='AudioLibrary.GetArtistDetails',
                                         params={'properties': ['genre', 'description', 'mood', 'style', 'born', 'died', 'formed', 'disbanded', 'yearsactive', 'instrument', 'fanart', 'thumbnail'], 
                                         'artistid': kodi_artist['artistid']
                                        })
                                         
                item = data['result']['artistdetails']
                
                artwork = {'thumb': item['thumbnail'],
                           'fanart': item['fanart']
                }
                           
                artists.append({
                    'label': item['label'],
                    'artwork': artwork,
                    'title': item['label'],
                    'genre': ' / '.join(item['genre']),
                    'artist_description': item['description'],
                    'userrating': item['userrating'],
                    'born': item['born'],
                    'died': item['died'],
                    'formed': item['formed'],
                    'disbanded': item['disbanded'],
                    'yearsactive': ' / '.join(item['yearsactive']),
                    'style': ' / '.join(item['style']),
                    'mood': ' / '.join(item['mood']),
                    'instrument': ' / '.join(item['instrument']),
                    'librarypath': 'musicdb://artists/%s/' % item['artistid']
                })
                
        utils.log('%i of %i artists found in last.FM are in Kodi database' % (len(artists), len(simi_artists)))
        return artists

    def get_similar_movies(self, dbid):
        """
        get list of movies from db which are similar to movie with *dbid
        based on metadata-centric ranking
        """
        utils.log('LocalDB.get_similar_movies')
        movie = kodijson.get_json(method='VideoLibrary.GetMovieDetails',
                                  params={'properties': ['genre', 'director', 'country', 'year', 'mpaa'], 'movieid': dbid})
        if 'moviedetails' not in movie['result']:
            return []
        comp_movie = movie['result']['moviedetails']
        genres = comp_movie['genre']
        data = kodijson.get_json(method='VideoLibrary.GetMovies',
                                 params={'properties': ['genre', 'director', 'mpaa', 'country', 'year'], 'sort': {'method': 'random'}})
        if 'movies' not in data['result']:
            return []
        quotalist = []
        for item in data['result']['movies']:
            item['mediatype'] = 'movie'
            diff = abs(int(item['year']) - int(comp_movie['year']))
            hit = 0.0
            miss = 0.00001
            quota = 0.0
            for genre in genres:
                if genre in item['genre']:
                    hit += 1.0
                else:
                    miss += 1.0
            if hit > 0.0:
                quota = float(hit) / float(hit + miss)
            if genres and item['genre'] and genres[0] == item['genre'][0]:
                quota += 0.3
            if diff < 3:
                quota += 0.3
            elif diff < 6:
                quota += 0.15
            if comp_movie['country'] and item['country'] and comp_movie['country'][0] == item['country'][0]:
                quota += 0.4
            if comp_movie['mpaa'] and item['mpaa'] and comp_movie['mpaa'] == item['mpaa']:
                quota += 0.4
            if comp_movie['director'] and item['director'] and comp_movie['director'][0] == item['director'][0]:
                quota += 0.6
            quotalist.append((quota, item['movieid']))
        quotalist = sorted(quotalist,
                           key=lambda quota: quota[0],
                           reverse=True)
        movies = ItemList(content_type='movies')
        for i, list_movie in enumerate(quotalist):
            if comp_movie['movieid'] is not list_movie[1]:
                newmovie = self.get_movie_dbid(list_movie[1])
                movies.append(newmovie)
                if i == 20:
                    break
        return movies

    def get_movies(self, limit=10):
        """
        get list of movies with length *limit from db
        """
        utils.log('LocalDB.get_movies')
        data = kodijson.get_json(method='VideoLibrary.GetMovies',
                                 params={'properties': MOVIE_PROPS, 'limits': {'end': limit}})
        if 'result' not in data or 'movies' not in data['result']:
            return []
        return ItemList(content_type='movies',
                        items=[self.handle_movie(item) for item in data['result']['movies']])

    def get_tvshows(self, limit=10):
        """
        get list of tvshows with length *limit from db
        """
        utils.log('LocalDB.get_tvshows')
        data = kodijson.get_json(method='VideoLibrary.GetTVShows',
                                 params={'properties': TV_PROPS, 'limits': {'end': limit}})
        if 'result' not in data or 'tvshows' not in data['result']:
            return []
        return ItemList(content_type='movies',
                        items=[self.handle_tvshow(item) for item in data['result']['tvshows']])
                        
    def get_albums(self):
        """
        get a list of all albums from db
        """
        utils.log('LocalDB.get_albums')
        data = kodijson.get_json(method='AudioLibrary.GetAlbums',
                                 params={'properties': ['title']})
        if 'result' not in data or 'albums' not in data['result']:
            return []
        return data['result']['albums']
        
    #MOVIE
        
    def get_movie_dbid(self, movieid):
        """
        get info from db for movie with *movieid
        """
        utils.log('LocalDB.get_movie_dbid')
        response = kodijson.get_json(method='VideoLibrary.GetMovieDetails',
                                     params={'properties': MOVIE_PROPS, 'movieid': int(movieid)
        })
        if 'result' in response and 'moviedetails' in response['result']:
            return self.handle_movie(response['result']['moviedetails'])
        return {}

    def handle_movie(self, movie):
        """
        convert movie data to listitems
        """
        utils.log('LocalDB.handle_movie')
        trailer = PLUGIN_BASE + 'playtrailer&&dbid=%s' % movie['movieid']
        
        if addon.setting('infodialog_onclick') != 'false':
            path = PLUGIN_BASE + 'extendedinfo&&dbid=%s' % movie['movieid']
        else:
            path = PLUGIN_BASE + 'playmovie&&dbid=%i' % movie['movieid']
        resume = movie['resume']
        if (resume['position'] and resume['total']) > 0:
            resumable = 'true'
            played = int((float(resume['position']) / float(resume['total'])) * 100)
        else:
            resumable = 'false'
            played = 0

        db_movie = VideoItem(label=movie.get('label'), path=path)
        
        db_movie.set_infos({
            'title': movie.get('label'),
            'dbid': int(movie['movieid']),
            'file': movie.get('file'),
            'year': movie.get('year'),
            'writer': ' / '.join(movie['writer']),
            'mediatype': 'movie',
            'set': movie.get('set'),
            'playcount': movie.get('playcount'),
            'setid': movie.get('setid'),
            'top250': movie.get('top250'),
            'imdbnumber': movie.get('imdbnumber'),
            'userrating': movie.get('userrating'),
            'trailer': trailer,
            'rating': round(float(movie['rating']), 1),
            'director': ' / '.join(movie.get('director')),
            'writer': ' / '.join(movie.get('writer')),
            'genre': ' / '.join(movie['genre']),
            'plot': movie.get('plot'),
            'plotoutline': movie.get('plotoutline'),
            'studio': ' / '.join(movie.get('studio')),
            'mpaa': movie.get('mpaa'),
            'originaltitle': movie.get('originaltitle')
        })
        
        db_movie.set_properties({
            'imdb_id': movie.get('imdbnumber'),
            'showlink': ' / '.join(movie['showlink']),
            'percentplayed': played,
            'resume': resumable
        })
        
        db_movie.set_artwork(movie['art'])
        
        db_movie.set_videoinfos(movie['streamdetails']['video'])
        db_movie.set_audioinfos(movie['streamdetails']['audio'])
        
        stream_info = media_streamdetails(movie['file'].lower(), movie['streamdetails'])
        
        db_movie.update_properties(stream_info)
        
        db_movie.set_cast(movie.get('cast'))
        
        return db_movie
        
    #TVSHOW
        
    def get_tvshow_dbid(self, tvshowid):
        """
        get info from db for tvshow with *tvshowid
        """
        utils.log('LocalDB.get_tvshow_dbid')
        response = kodijson.get_json(method='VideoLibrary.GetTVShowDetails',
                                     params={'properties': TV_PROPS, 'tvshowid': int(tvshowid)
        })
        if 'result' in response and 'tvshowdetails' in response['result']:
            return self.handle_tvshow(response['result']['tvshowdetails'])
        return {}    

    def handle_tvshow(self, tvshow):
        """
        convert tvshow data to listitems
        """
        utils.log('LocalDB.handle_tvshow')
        
        if addon.setting('infodialog_onclick') != 'false':
            path = PLUGIN_BASE + 'extendedtvinfo&&dbid=%s' % tvshow['tvshowid']
        else:
            path = PLUGIN_BASE + 'action&&id=ActivateWindow(videos,videodb://tvshows/titles/%s/,return)' % tvshow['tvshowid']
            
        db_tvshow = VideoItem(label=tvshow.get('label'), path=path)
        
        db_tvshow.set_infos({
            'title': tvshow.get('label'),
            'dbid': int(tvshow['tvshowid']),
            'genre': ' / '.join(tvshow.get('genre')),
            'rating': round(float(tvshow['rating']), 1),
            'mediatype': 'tvshow',
            'mpaa': tvshow.get('mpaa'),
            'plot': tvshow.get('plot'),
            'votes': tvshow.get('votes'),
            'studio': ' / '.join(tvshow.get('studio')),
            'premiered': tvshow.get('premiered'),
            'playcount': tvshow.get('playcount'),
            'imdbnumber': tvshow.get('imdbnumber'),
            'userrating': tvshow.get('userrating'),
            'duration': tvshow.get('duration'),
            'year': tvshow.get('year'),
            'originaltitle': tvshow.get('originaltitle')
        })
        
        db_tvshow.set_properties({
            'imdb_id': tvshow.get('imdbnumber'),
            'file': tvshow.get('file'),
            'watchedepisodes': tvshow.get('watchedepisodes'),
            'totalepisodes': tvshow.get('episode')
        })
        
        db_tvshow.set_artwork(tvshow['art'])
        
        db_tvshow.set_cast(tvshow.get('cast'))
        
        return db_tvshow
        
    def get_tvshow_id_by_episode(self, dbid):
        utils.log('LocalDB.get_tvshow_id_by_episode')
        if not dbid:
            return None
        data = kodijson.get_json(method='VideoLibrary.GetEpisodeDetails',
                                 params={'properties': ['tvshowid'], 'episodeid': dbid})
        if 'episodedetails' not in data['result']:
            return None
        return self.get_imdb_id(media_type='tvshow', dbid=str(data['result']['episodedetails']['tvshowid']))

    def get_compare_info(self, media_type='movie'):
        """
        fetches info needed for the locally-available check
        Caches some info as window properties.
        Hacky, but by far fastest way to cache between sessions
        """
        utils.log('LocalDB.get_compare_info')
        items = self.get_list(media_type)
        infos = ['ids', 'idx', 'otitles', 'titles']
        if not self.info.get(media_type):
            self.info[media_type] = {}
            dct = self.info[media_type]
            dct['ids'] = addon.get_global('%s_ids.JSON' % media_type)
            if dct['ids'] and dct['ids'] != '[]':
                dct['ids'] = json.loads(dct['ids'])
                dct['otitles'] = json.loads(addon.get_global('%s_otitles.JSON' % media_type))
                dct['titles'] = json.loads(addon.get_global('%s_titles.JSON' % media_type))
                dct['idx'] = json.loads(addon.get_global('%s_idx.JSON' % media_type))
            else:
                for info in infos:
                    dct[info] = []
                for item in items:
                    dct['ids'].append(item['%sid' % media_type])
                    dct['titles'].append(item['label'].lower())
                    if media_type == 'movie' or media_type == 'tvshow':
                        dct['idx'].append(item['imdbnumber'])
                        dct['otitles'].append(item['originaltitle'].lower())
                    elif media_type == 'artist':
                        dct['idx'].append(item['musicbrainzartistid'][0])
                        dct['otitles'].append(item['artist'].lower())
                    elif media_type == 'album':
                        dct['idx'].append(item['musicbrainzalbumid'])
                        dct['otitles'].append(item['label'].lower())
                    elif media_type == 'song':
                        dct['idx'].append(item['musicbrainztrackid'])
                        dct['otitles'].append(item['label'].lower())
                for info in infos:
                    addon.set_global('%s_%s.JSON' % (media_type, info), json.dumps(dct[info]))
            self.info[media_type] = dct

    def get_list(self, media_type):
        utils.log('LocalDB.get_list')
        if media_type == 'movie':
            return kodijson.get_movies(['originaltitle', 'imdbnumber'])
        elif media_type == 'tvshow':
            return kodijson.get_tvshows(['originaltitle', 'imdbnumber'])
        elif media_type == 'artist':
            return kodijson.get_artists(['musicbrainzartistid', 'thumbnail'])
        elif media_type == 'album':
            return kodijson.get_albums(['musicbrainzalbumid', 'thumbnail'])
        elif media_type == 'song':
            return kodijson.get_songs(['musicbrainztrackid', 'thumbnail'])
            
    def get_info(self, media_type, item_id):
        utils.log('LocalDB.get_info')
        if media_type == 'movie':
            return self.get_movie_dbid(item_id)
        elif media_type == 'tvshow':
            return self.get_tvshow_dbid(item_id)
        elif media_type == 'artist':
            return self.get_artist_dbid(item_id)
        elif media_type == 'album':
            return self.get_album_dbid(item_id)
        elif media_type == 'song':
            return self.get_song_dbid(item_id)

    def merge_with_local(self, media_type, items, sort=None, sort_by=None, sort_order=None):
        """
            merge *items from online sources with local db info (and sort)
        works for movies and tvshows
        """
        utils.log('LocalDB.merge_with_local')
        self.get_compare_info(media_type)
        all_items = []
        info = self.info[media_type]
        for item in items:
            index = False
            index2 = False
            title = item.get_info('title').lower()
            if media_type == 'movie' or media_type == 'tvshow':
                imdb_id = item.get_property('imdb_id')                
                otitle = item.get_info('originaltitle').lower()
                if 'imdb_id' in item.get_properties() and imdb_id in info['idx']:
                    index = info['idx'].index(imdb_id)
                elif 'title' in item.get_infos() and title in info['titles']:
                    index = info['titles'].index(title)
                elif 'originaltitle' in item.get_infos() and otitle in info['otitles']:
                    index = info['otitles'].index(otitle)
                if index:
                    local_item = self.get_info(media_type, info['ids'][index])
                    if local_item:
                        try:
                            diff = abs(int(local_item.get_info('year')) - int(item.get_info('year')))
                            if diff > 1:
                                remote_items.append(item)
                                continue
                        except Exception:
                            pass
                        item.update_from_listitem(local_item)
            elif media_type == 'artist' or media_type == 'album' or media_type == 'song':
                if media_type == 'artist':
                    musicbrainzartistid = item.get_property('musicbrainzartistid')
                    if 'musicbrainzartistid' in item.get_properties() and musicbrainzartistid in info['idx']:
                        index = info['idx'].index(musicbrainzartistid)
                elif media_type == 'album':                   
                    if 'musicbrainzreleasesid' in item.get_properties():
                        musicbrainzreleasesid = item.get_property('musicbrainzreleasesid')
                        for mbid in musicbrainzreleasesid.split(', '):
                            if mbid in info['idx']:
                                index = info['idx'].index(mbid)
                                break
                    elif 'musicbrainzreleaseid' in item.get_properties():
                        musicbrainzreleaseid = item.get_property('musicbrainzreleaseid')
                        if musicbrainzreleaseid in info['idx']:
                            index = info['idx'].index(musicbrainzreleaseid)
                elif media_type == 'song':
                    musicbrainztrackid = item.get_property('musicbrainztrackid')
                    if 'musicbrainztrackid' in item.get_properties() and musicbrainztrackid in info['idx']:
                        index = info['idx'].index(musicbrainztrackid)
                if 'title' in item.get_infos() and title in info['titles']:
                    index2 = info['titles'].index(title)
                if (index == index2) and (index != False) and (index2 != False):
                    local_item = self.get_info(media_type, info['ids'][index])
                    if local_item:
                        label = item.label
                        item.update_from_listitem(local_item)
                        item.label = label
            all_items.append(item)
        if sort:
            all_items = self.sort_items(all_items, sort_by, sort_order)
        return ItemList(content_type=media_type, items=all_items)

    def compare_album_with_library(self, online_list):
        """
        merge *albums from online sources with local db info
        """
        utils.log('LocalDB.compare_album_with_library')
        if not self.albums:
            self.albums = self.get_albums()
        for item in online_list:
            for local_item in self.albums:
                if not item.get_info('title') == local_item['title']:
                    continue
                data = kodijson.get_json(method='AudioLibrary.getAlbumDetails',
                                         params={'properties': ['thumbnail'], 'albumid': local_item['albumid']
                })
                album = data['result']['albumdetails']
                item.set_info('dbid', album['albumid'])
                item.set_path(PLUGIN_BASE + 'playalbum&&dbid=%i' % album['albumid'])
                if album['thumbnail']:
                    item.update_artwork({'thumb': album['thumbnail']})
                break
        return online_list

    def get_set_name(self, dbid):
        """
        get name of set for movie with *dbid
        """
        utils.log('LocalDB.get_set_name')
        data = kodijson.get_json(method='VideoLibrary.GetMovieDetails',
                                 params={'properties': ['setid'], 'movieid': dbid
        })
        if 'result' not in data or 'moviedetails' not in data['result']:
            return None
        set_dbid = data['result']['moviedetails'].get('setid')
        if set_dbid:
            data = kodijson.get_json(method='VideoLibrary.GetMovieSetDetails',
                                     params={'setid': set_dbid
            })
            return data['result']['setdetails'].get('label')

    def get_imdb_id(self, media_type, dbid):
        utils.log('LocalDB.get_imdb_id')
        if not dbid:
            return None
        if media_type == 'movie':
            data = kodijson.get_json(method='VideoLibrary.GetMovieDetails',
                                     params={'properties': ['imdbnumber', 'title', 'year'], 'movieid': int(dbid)
            })
            if 'result' in data and 'moviedetails' in data['result']:
                return data['result']['moviedetails']['imdbnumber']
        elif media_type == 'tvshow':
            data = kodijson.get_json(method='VideoLibrary.GetTVShowDetails',
                                     params={'properties': ['imdbnumber', 'title', 'year'], 'tvshowid': int(dbid)
            })
            if 'result' in data and 'tvshowdetails' in data['result']:
                return data['result']['tvshowdetails']['imdbnumber']
        return None
        
    # ARTIST
    
    def get_artist_mbid(self, dbid):
        utils.log('LocalDB.get_artist_mbid')
        if not dbid:
            return None
        data = kodijson.get_json(method='AudioLibrary.GetArtistDetails',
                                 params={'properties': ['musicbrainzartistid'], 'artistid': int(dbid)
        })
        if 'result' in data and 'artistdetails' in data['result']:
            return data['result']['artistdetails']['musicbrainzartistid'][0]
        return None

    def get_artist_dbid(self, artistid):
        """
        get info from db for artist with *artistid
        """
        utils.log('LocalDB.get_artist_dbid')
        response = kodijson.get_json(method='AudioLibrary.GetArtistDetails',
                                     params={'properties': ARTIST_PROPS, 'artistid': int(artistid)
        })
        if 'result' in response and 'artistdetails' in response['result']:
            return self.handle_artist(response['result']['artistdetails'])
        return {}

    def get_artist_filter(self, artist):
        utils.log('LocalDB.get_artist_filter')
        response = kodijson.get_json(method='AudioLibrary.GetArtists',
                                     params={
                                        'filter': {
                                            'and': [{
                                                'field': 'artist',
                                                'operator': 'is',
                                                'value': artist
                                        }]}, 
                                        'properties': ARTIST_PROPS
        })
        if 'result' in response and 'artists' in response['result']:
            return self.handle_artist(response['result']['artists'][0])
        return {}
        
    def handle_artist(self, artist):
        """
        convert artist data to listitems
        """
        utils.log('LocalDB.handle_artist')
        dbid = int(artist['artistid'])
        db_media_type = 'artist'

        if addon.setting('infodialog_onclick') != 'false':
            path = PLUGIN_BASE + 'extendedartistinfo&&dbid=%s' % dbid
        else:
            path = PLUGIN_BASE + 'action&&id=ActivateWindow(music,musicdb://artists/%s/,return)' % dbid
        path = 'musicdb://artists/%s/' % dbid        
        title = artist.get('label')
        label = title
        
        db_artist = AudioItem(label=label, path=path)
        
        db_artist.set_infos({
            'dbid': dbid,        
            'title': title,            
            'genre': ' / '.join(artist.get('genre')),
            'mediatype': db_media_type
        })
        
        db_artist.set_properties({
            'musicbrainzartistid': artist.get('musicbrainzartistid')[0],
            'artist_born': artist.get('born'),
            'artist_died': artist.get('died'),
            'artist_description': artist.get('description'),
            'description': artist.get('description'),
            'artist_type': artist.get('type'),
            'artist_sortname': artist.get('sortname'),
            'artist_gender': artist.get('gender'),
            'artist_genre': ' / '.join(artist.get('genre')),            
            'artist_formed': artist.get('formed'),
            'artist_disbanded': artist.get('disbanded'),
            'artist_yearsactive': artist.get('yearsactive'),
            'artist_instrument': artist.get('instrument'),
            'artist_mood': artist.get('mood'),
            'artist_style': artist.get('style')                                 
        })
        
        db_artist.set_artwork(artist['art'])
        
        return db_artist

    def check_local_artist(self, item):
        utils.log('LocalDB.check_local_artist')
        update = False
        musicbrainzartistid = item.get_property('musicbrainzartistid')
        title = item.get_info('title').lower()
        local_item = self.get_artist_filter(title)
        if local_item:
            local_musicbrainzartistid = local_item.get_property('musicbrainzartistid')
            if local_musicbrainzartistid == musicbrainzartistid:                
                label = item.label
                item.update_from_listitem(local_item)                
                item.label = label
                update = True
        return (update, item)
        
    # ALBUM
    
    def get_album_mbid(self, dbid):
        utils.log('LocalDB.get_album_mbid')
        if not dbid:
            return None
        data = kodijson.get_json(method='AudioLibrary.GetAlbumDetails',
                                 params={'properties': ['musicbrainzalbumid'], 'albumid': int(dbid)
        })
        if 'result' in data and 'albumdetails' in data['result']:
            return data['result']['albumdetails']['musicbrainzalbumid']
        return None
    
    def get_album_dbid(self, albumid):
        """
        get info from db for album with *albumid
        """
        utils.log('LocalDB.get_album_dbid')
        response = kodijson.get_json(method='AudioLibrary.GetAlbumDetails',
                                     params={'properties': ALBUM_PROPS, 'albumid': int(albumid)
        })
        if 'result' in response and 'albumdetails' in response['result']:
            return self.handle_album(response['result']['albumdetails'])
        return {}
        
    def get_album_filter(self, album, artist):
        utils.log('LocalDB.get_album_filter')
        response = kodijson.get_json(method='AudioLibrary.GetAlbums',
                                     params={
                                        'filter': {
                                            'and': [{
                                                'field': 'album',
                                                'operator': 'is',
                                                'value': album
                                                },{
                                                'field': 'artist',
                                                'operator': 'is',
                                                'value': artist                                                
                                        }]}, 
                                        'properties': ALBUM_PROPS
        })
        if 'result' in response and 'albums' in response['result']:
            return self.handle_album(response['result']['albums'][0])
        return {} 
        
    def handle_album(self, album):
        """
        convert album data to listitems
        """
        utils.log('LocalDB.handle_album')
        dbid = int(album['albumid'])
        db_media_type = 'album'
        
        if addon.setting('infodialog_onclick') != 'false':
            path = PLUGIN_BASE + 'extendedalbuminfo&&dbid=%s' % dbid
        else:
            path = PLUGIN_BASE + 'action&&id=ActivateWindow(music,musicdb://albums/%s/,return)' % dbid
        path = 'musicdb://albums/%s/' % dbid           
        title = album.get('label')
        artist = ', '.join(album.get('artist'))
        label = title
        if artist:
            label = artist + ' - ' + title
        
        db_album = AudioItem(label=label, path=path)
        
        db_album.set_infos({
            'dbid': dbid,
            'title': title,           
            'artist': artist,
            'genre': ' / '.join(album.get('genre')),
            'year': album.get('year'),
            'mediatype': db_media_type           
        })
        
        db_album.set_properties({
            'musicbrainzalbumid': album.get('musicbrainzalbumid'),
            'musicbrainzalbumartistid': album.get('musicbrainzalbumartistid'),
            'description': album.get('description'),
            'album_description': album.get('description'),
            'album_type': album.get('type'),            
            'album_mood': album.get('mood'),
            'album_style': album.get('style'),
            'album_theme': album.get('theme'),                                 
            'album_label': album.get('albumlabel'),                              
            'album_rating': album.get('rating'),
            'album_userrating': album.get('userrating'),
            'album_votes': album.get('votes')
        })
        
        db_album.set_artwork(album['art'])
        
        return db_album
       
    def check_local_album(self, item, release=False):
        utils.log('LocalDB.check_local_album')
        update = False
        if release:
            musicbrainzreleaseid = item.get_property('musicbrainzreleaseid')
            releases = [musicbrainzreleaseid]
        else:
            musicbrainzreleasesid = item.get_property('musicbrainzreleasesid')
            releases = musicbrainzreleasesid.split(', ')        
        title = item.get_info('title').lower()
        artist = item.get_info('artist').lower()
        local_item = self.get_album_filter(title, artist)        
        if local_item:
            musicbrainzalbumid = local_item.get_property('musicbrainzalbumid')
            if musicbrainzalbumid in releases:
                label = item.label
                item.update_from_listitem(local_item)
                item.label = label
                update = True
        return (update, item)
        
    # SONG
    
    def get_song_mbid(self, dbid):
        utils.log('LocalDB.get_song_mbid')
        if not dbid:
            return (None, None)
        data = kodijson.get_json(method='AudioLibrary.GetSongDetails',
                                 params={'properties': ['musicbrainztrackid', 'albumid'], 'songid': int(dbid)
        }) 
        if 'result' in data and 'songdetails' in data['result']:
            musicbrainztrackid = data['result']['songdetails']['musicbrainztrackid']
            albumid = data['result']['songdetails']['albumid']
            return (musicbrainztrackid, albumid)
        return  (None, None)
    
    def get_song_dbid(self, songid):
        """
        get info from db for song with *song_id
        """
        utils.log('LocalDB.get_song_dbid')
        response = kodijson.get_json(method='AudioLibrary.GetSongDetails',
                                     params={'properties': SONG_PROPS, 'songid': int(songid)
        })
        if 'result' in response and 'songdetails' in response['result']:
            return self.handle_song(response['result']['songdetails'])
        return {}
        
    def get_song_filter(self, album, artist, song):
        utils.log('LocalDB.get_song_filter')
        response = kodijson.get_json(method='AudioLibrary.GetSongs',
                                     params={
                                        'filter': {
                                            'and': [{
                                                'field': 'album',
                                                'operator': 'is',
                                                'value': album
                                                },{
                                                'field': 'artist',
                                                'operator': 'is',
                                                'value': artist 
                                                },{
                                                'field': 'title',
                                                'operator': 'is',
                                                'value': song                                                
                                        }]}, 
                                        'properties': SONG_PROPS
        })
        if 'result' in response and 'songs' in response['result']:
            return self.handle_song(response['result']['songs'][0])        
        return {}
        
    def handle_song(self, song):
        """
        convert song data to listitems
        """
        utils.log('LocalDB.handle_song')
        dbid = int(song['songid'])
        db_media_type = 'song'
        
        if addon.setting('infodialog_onclick') != 'false':
            path = PLUGIN_BASE + 'extendedsonginfo&&dbid=%s' % dbid
        else:
            path = PLUGIN_BASE + 'action&&id=ActivateWindow(music,musicdb://songs/%s/,return)' % dbid
        path = 'musicdb://songs/%s/' % dbid            
        title = song.get('label')
        artist = ', '.join(song.get('artist'))
        label = title
        if artist:
            label = artist + ' - ' + title
        
        db_song = AudioItem(label=label, path=path)
        
        db_song.set_infos({
            'dbid': dbid,
            'title': title,
            'duration': song.get('duration'),
            'artist': artist,
            'album': song.get('album'),
            'genre': ' / '.join(song.get('genre')),
            'year': song.get('year'),
            'mediatype': db_media_type,            
            'tracknumber': song.get('track'),
            'discnumber': song.get('disc'),            
            'filename': song.get('file')            
        })
        
        db_song.set_properties({
            'musicbrainztrackid': song.get('musicbrainztrackid'),
            'musicbrainzartistid': song.get('musicbrainzartistid'),
            'musicbrainzalbumid': song.get('musicbrainzalbumid'),
            'musicbrainzalbumartistid': song.get('musicbrainzalbumartistid'),
            'comment': song.get('comment'),
            'description': song.get('comment'),
            'song_rating': song.get('rating'),
            'song_userrating': song.get('userrating'),
            'song_votes': song.get('votes'),
            'samplerate': song.get('samplerate'),
            'bitrate': song.get('bitrate'),
            'channels': song.get('channels')
        })
        
        db_song.set_artwork(song['art'])
        
        return db_song
        
    def check_local_song(self, item):
        utils.log('LocalDB.check_local_song')
        update = False
        musicbrainztrackid = item.get_property('musicbrainztrackid')
        title = item.get_info('title').lower()
        artist = item.get_info('artist').lower()
        album = item.get_info('album').lower()
        local_item = self.get_song_filter(album, artist, title)        
        if local_item:
            local_musicbrainztrackid = local_item.get_property('musicbrainztrackid')           
            if local_musicbrainztrackid == musicbrainztrackid:
                label = item.label
                item.update_from_listitem(local_item)                
                item.label = label
                update = True
        return (update, item)
        
    def sort_items(self, items, sort_by, sort_order):
        utils.log('LocalDB.sort_items')
        if sort_order == 'desc':
            order = True
        elif sort_order == 'asc':
            order = False
        else:
            order = True
        if sort_by:
            if sort_by in ['genre', 'year', 'premiered', 'originaltitle', 'rating', 'votes']:
                items = sorted(items,
                               key=lambda k: k.get_info(sort_by),
                               reverse=order)
            elif sort_by == 'types/year/title':
                items = sorted(items,
                               key=lambda k: (k.get_property('album_primary_type'), k.get_property('album_secondary_types'), k.get_info('year'), k.get_info('title')),
                               reverse=order)
            elif sort_by == 'status/date/country':
                items = sorted(items,
                               key=lambda k: (k.get_property('release_status'), k.get_property('release_date'), k.get_property('release_country')),
                               reverse=order)
            elif sort_by == 'disk/track':
                items = sorted(items,
                               key=lambda k: (k.get_property('disk_position'), k.get_property('recording_position')),
                               reverse=order)
            else:
                items = sorted(items,
                               key=lambda k: k.get_property(sort_by),
                               reverse=order)
        return items

def media_streamdetails(filename, streamdetails):
    utils.log('localdb:media_streamdetails')
    info = {}
    video = streamdetails['video']
    audio = streamdetails['audio']
    if video:
        # see StreamDetails.cpp
        if video[0]['width'] + video[0]['height'] == 0:
            info['VideoResolution'] = ''
        elif video[0]['width'] <= 720 and video[0]['height'] <= 480:
            info['VideoResolution'] = '480'
        elif video[0]['width'] <= 768 and video[0]['height'] <= 576:
            info['VideoResolution'] = '576'
        elif video[0]['width'] <= 960 and video[0]['height'] <= 544:
            info['VideoResolution'] = '540'
        elif video[0]['width'] <= 1280 and video[0]['height'] <= 720:
            info['VideoResolution'] = '720'
        elif video[0]['width'] <= 1920 and video[0]['height'] <= 1080:
            info['VideoResolution'] = '1080'
        elif video[0]['width'] * video[0]['height'] >= 6000000:
            info['VideoResolution'] = '4K'
        else:
            info['videoresolution'] = ''
        info['VideoCodec'] = str(video[0]['codec'])
        info['VideoAspect'] = select_aspectratio(video[0]['aspect'])
    if audio:
        info['AudioCodec'] = audio[0]['codec']
        info['AudioChannels'] = audio[0]['channels']
        streams = []
        for i, item in enumerate(audio, start=1):
            language = item['language']
            if language in streams or language == 'und':
                continue
            streams.append(language)
            streaminfo = {'AudioLanguage.%d' % i: language,
                          'AudioCodec.%d' % i: item['codec'],
                          'AudioChannels.%d' % i: str(item['channels'])}
            info.update(streaminfo)
        subs = []
        for i, item in enumerate(streamdetails['subtitle'], start=1):
            language = item['language']
            if language in subs or language == 'und':
                continue
            subs.append(language)
            info.update({'SubtitleLanguage.%d' % i: language})
    return info

def select_aspectratio(aspect):
    utils.log('localdb:select_aspectratio')    
    # see StreamDetails.cpp
    aspect = float(aspect)
    if aspect < 1.3499:  # sqrt(1.33*1.37)
        return '1.33'
    elif aspect < 1.5080:  # sqrt(1.37*1.66)
        return '1.37'
    elif aspect < 1.7190:  # sqrt(1.66*1.78)
        return '1.66'
    elif aspect < 1.8147:  # sqrt(1.78*1.85)
        return '1.78'
    elif aspect < 2.0174:  # sqrt(1.85*2.20)
        return '1.85'
    elif aspect < 2.2738:  # sqrt(2.20*2.35)
        return '2.20'
    elif aspect < 2.3749:  # sqrt(2.35*2.40)
        return '2.35'
    elif aspect < 2.4739:  # sqrt(2.40*2.55)
        return '2.40'
    elif aspect < 2.6529:  # sqrt(2.55*2.76)
        return '2.55'
    else:
        return '2.76'