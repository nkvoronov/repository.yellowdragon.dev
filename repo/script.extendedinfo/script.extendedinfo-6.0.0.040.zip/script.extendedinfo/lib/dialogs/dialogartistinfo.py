# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import unicode_literals

import xbmcgui

from lib.musicbrainz import mb
from lib.dialogs import DialogMusicInfo

from lib.tools import imagetools
from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

ID_CONTROL_PLOT = 132

ID_LIST_ALBUMS = 150
ID_LIST_ALBUMS_COMPILATION = 151
ID_LIST_ALBUMS_LIVE = 152
ID_LIST_SINGLES = 153
ID_LIST_SINGLES_LIVE = 154
ID_LIST_EPS = 155
ID_LIST_EPS_LIVE = 156

ID_LIST_GENRES = 190
ID_LIST_LABELS = 191

ID_LIST_IMAGES = 210
ID_LIST_BACKDROPS = 211

ID_BUTTON_PLAY = 8
ID_BUTTON_FOLDER = 120
ID_BUTTON_ARTIST = 100
ID_BUTTON_GROUP = 101
ID_BUTTON_REALESE = 102
ID_BUTTON_MANAGE = 445

chm = ActionHandler(type='alt')

class DialogArtistInfo(DialogMusicInfo):

    TYPE = 'Artist'
    
    TYPE_ALT = 'artist'

    LISTS = [(ID_LIST_ALBUMS, 'album'),
             (ID_LIST_ALBUMS_COMPILATION, 'albumcompilation'),
             (ID_LIST_ALBUMS_LIVE, 'albumlive'),
             (ID_LIST_SINGLES, 'single'),
             (ID_LIST_SINGLES_LIVE, 'singlelive'),
             (ID_LIST_EPS, 'ep'),
             (ID_LIST_EPS_LIVE, 'eplive'),
             (ID_LIST_GENRES, 'genres'),
             (ID_LIST_LABELS, 'labels'),
             (ID_LIST_IMAGES, 'images'),
             (ID_LIST_BACKDROPS, 'backdrops')
    ]

    def __init__(self, *args, **kwargs):
        utils.log('DialogArtistInfo.__init__')
        super(DialogArtistInfo, self).__init__(*args, **kwargs)
        data = mb.extended_artist_info(artist_id=kwargs.get('id'),
                                       dbid=kwargs.get('dbid'))
        if not data:
            return None
        self.info, self.lists = data

    def onInit(self):
        utils.log('DialogArtistInfo.onInit')
        self.get_youtube_vids(self.info.get_property('youtube_search'))
        super(DialogArtistInfo, self).onInit()

    def onClick(self, control_id):
        utils.log('DialogArtistInfo.onClick')
        super(DialogArtistInfo, self).onClick(control_id)
        chm.serve(control_id, self)
        
    def set_buttons(self):
        utils.log('DialogArtistInfo.set_buttons')
        super(DialogArtistInfo, self).set_buttons()
        self.set_visible(ID_BUTTON_PLAY, False)
        self.set_visible(ID_BUTTON_ARTIST, False)
        self.set_visible(ID_BUTTON_GROUP, False)
        self.set_visible(ID_BUTTON_REALESE, False)
        
    @chm.click(ID_CONTROL_PLOT)
    def show_plot(self, control_id):
        utils.log('DialogArtistInfo.show_plot')
        xbmcgui.Dialog().textviewer(heading=addon.LANG(32037),
                                    text=self.info.get_property('description'))