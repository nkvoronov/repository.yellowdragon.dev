# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import xbmc
import xbmcgui

from lib import MusicBrainz as mb
from lib.WindowManager import wm

from lib.tools import addon
from lib.tools import utils
from lib.tools import busy
from lib.tools import confirmdialog
from lib.tools import selectdialog
from lib.tools import ActionHandler
from lib.tools import DialogBaseList

ID_BUTTON_SORT = 5001
ID_BUTTON_GENREFILTER = 5002
ID_BUTTON_YEARFILTER = 5003
ID_BUTTON_ORDER = 5004
ID_BUTTON_KEYWORDFILTER = 5009
ID_BUTTON_RUNTIMEFILTER = 5011
ID_BUTTON_VOTECOUNTFILTER = 5012

ch = ActionHandler()

def get_window(window_type):

    class DialogMusicBrainzList(DialogBaseList, window_type):

        TYPES = ['artist', 'album', 'song']

        FILTERS = {}

        TRANSLATIONS = {'artist': addon.LANG(32174),
                        'album': addon.LANG(32175),
                        'song': addon.LANG(32176)}

        SORTS = {'artist': {'score': addon.LANG(32178),
                           'revenue': addon.LANG(135)},
                 'album': {'score': addon.LANG(32178),
                           'revenue': addon.LANG(135),
                           'year': addon.LANG(562)},                           
                 'song': {'score': addon.LANG(32178),
                           'revenue': addon.LANG(135),
                           'year': addon.LANG(562)}
                }

        LABEL2 = {'score': lambda x: x.get_property('score'),
                  'revenue': lambda x: x.get_info('genre'),
                  'year': lambda x: x.get_info('year'),
        }

        @busy.set_busy
        def __init__(self, *args, **kwargs):
            utils.log('DialogMusicBrainzList.__init__')
            self.type = kwargs.get('type', '')
            self.list_id = kwargs.get('list_id', False)
            super(DialogMusicBrainzList, self).__init__(*args, **kwargs)

        def onClick(self, control_id):
            utils.log('DialogMusicBrainzList.onClick')
            super(DialogMusicBrainzList, self).onClick(control_id)
            ch.serve(control_id, self)

        def onAction(self, action):
            utils.log('DialogMusicBrainzList.onAction')
            super(DialogMusicBrainzList, self).onAction(action)
            ch.serve_action(action, self.getFocusId(), self)

        def update_ui(self):
            utils.log('DialogMusicBrainzList.update_ui')
            super(DialogMusicBrainzList, self).update_ui()

        @ch.context('artist')
        @ch.context('album')
        @ch.context('song')
        def context_menu(self, control_id):
            utils.log('DialogMusicBrainzList.context_menu')
            item_id = self.FocusedItem(control_id).getProperty('id')
            media_type = self.FocusedItem(control_id).getVideoInfoTag().getMediaType()
            #listitems = [addon.LANG(32169)] if media_type == 'tvshow' else [addon.LANG(32113)]

        @property
        def sort_key(self):
            utils.log('DialogMusicBrainzList.sort_key')
            return self.type

        @property
        def default_sort(self):
            utils.log('DialogMusicBrainzList.default_sort')
            return 'score'

        @ch.click(ID_BUTTON_SORT)
        def get_sort_type(self, control_id):
            utils.log('DialogMusicBrainzList.get_sort_type')
            if not self.choose_sort_method(self.sort_key):
                return None
            if self.sort == 'vote_average':
                self.add_filter(key='vote_count.gte',
                                value='10',
                                label='10',
                                reset=False)
            self.update()

        def add_filter(self, **kwargs):
            utils.log('DialogMusicBrainzList.add_filter')
            key = kwargs['key'].replace('.gte', '').replace('.lte', '')
            kwargs['typelabel'] = self.FILTERS[key]
            if kwargs['key'].endswith('.lte'):
                kwargs['label'] = '< %s' % kwargs['label']
            if kwargs['key'].endswith('.gte'):
                kwargs['label'] = '> %s' % kwargs['label']
            super(DialogMusicBrainzList, self).add_filter(force_overwrite=kwargs['key'].endswith(('.gte', '.lte')),
                                                    **kwargs)

        @ch.click(ID_BUTTON_ORDER)
        def toggle_order(self, control_id):
            utils.log('DialogMusicBrainzList.toggle_order')
            self.order = 'desc' if self.order == 'asc' else 'asc'
            self.update()

        @ch.click(ID_BUTTON_GENREFILTER)
        def set_genre_filter(self, control_id):
            utils.log('DialogMusicBrainzList.set_genre_filter')
            params = {'language': addon.setting('language')}
            #response = tmdb.get_data(url='genre/%s/list' % (self.type),
            #                         params=params,
            #                         cache_days=100)
            selected = [i['id'] for i in self.filters if i['type'] == 'with_genres']
            ids = [item['id'] for item in response['genres']]
            labels = [item['name'] for item in response['genres']]
            preselect = [ids.index(int(i)) for i in selected[0].split(',')] if selected else []
            indexes = xbmcgui.Dialog().multiselect(heading=addon.LANG(32151),
                                                   options=labels,
                                                   preselect=preselect)
            if indexes is None:
                return None
            self.filters = [i for i in self.filters if i['type'] != 'with_genres']
            for i in indexes:
                self.add_filter(key='with_genres',
                                value=ids[i],
                                label=labels[i],
                                reset=False)
            self.reset()

        @ch.click(ID_BUTTON_VOTECOUNTFILTER)
        def set_vote_count_filter(self, control_id):
            utils.log('DialogMusicBrainzList.set_vote_count_filter')
            ret = True
            if not self.type == 'tv':
                ret = confirmdialog.open(header=addon.LANG(32151),
                                         text=addon.LANG(32106),
                                         nolabel=addon.LANG(32150),
                                         yeslabel=addon.LANG(32149))
            if ret == -1:
                return None
            result = xbmcgui.Dialog().input(heading=addon.LANG(32111),
                                            type=xbmcgui.INPUT_NUMERIC)
            if result:
                self.add_filter(key='vote_count.lte' if ret == 1 else 'vote_count.gte',
                                value=result,
                                label=result)

        @ch.click(ID_BUTTON_YEARFILTER)
        def set_year_filter(self, control_id):
            utils.log('DialogMusicBrainzList.set_year_filter')
            ret = confirmdialog.open(header=addon.LANG(32151),
                                     text=addon.LANG(32106),
                                     nolabel=addon.LANG(32150),
                                     yeslabel=addon.LANG(32149))
            if ret == -1:
                return None
            result = xbmcgui.Dialog().input(heading=addon.LANG(345),
                                            type=xbmcgui.INPUT_NUMERIC)
            if not result:
                return None
            value = '{}-12-31' if ret == 1 else '{}-01-01'
            key = 'first_air_date' if self.type == 'tv' else 'primary_release_date'
            self.add_filter(key='%s.%s' % (key, 'lte' if ret == 1 else 'gte'),
                            value=value.format(result),
                            label=result)

        @ch.click(ID_BUTTON_RUNTIMEFILTER)
        def set_runtime_filter(self, control_id):
            utils.log('DialogMusicBrainzList.set_runtime_filter')
            ret = confirmdialog.open(header=addon.LANG(32151),
                                     text=addon.LANG(32106),
                                     nolabel=addon.LANG(32150),
                                     yeslabel=addon.LANG(32149))
            if ret == -1:
                return None
            result = xbmcgui.Dialog().input(heading=xbmc.getLocalizedString(2050),
                                            type=xbmcgui.INPUT_NUMERIC)
            if not result:
                return None
            self.add_filter(key='with_runtime.%s' % ('lte' if ret == 1 else 'gte'),
                            value=result,
                            label='{} min'.format(result))

        @ch.info('artist')
        @ch.click_by_type('artist')
        def open_artist(self, control_id):
            utils.log('DialogMusicBrainzList.open_artist')
            #wm.open_artist_info(mb_id=self.FocusedItem(control_id).getProperty('id'),
                               #dbid=self.FocusedItem(control_id).getAudioInfoTag().getDbId())

        @ch.info('album')
        @ch.click_by_type('album')
        def open_album(self, control_id):
            utils.log('DialogMusicBrainzList.open_album')
            # wm.open_album_info(mb_id=self.FocusedItem(control_id).getProperty('id'),
                                # dbid=self.FocusedItem(control_id).getAudioInfoTag().getDbId())
                                
        @ch.info('song')
        @ch.click_by_type('song')
        def open_song(self, control_id):
            utils.log('DialogMusicBrainzList.open_song')
            # wm.open_song_info(mb_id=self.FocusedItem(control_id).getProperty('id'),
                                # dbid=self.FocusedItem(control_id).getAudioInfoTag().getDbId())

        @ch.click(ID_BUTTON_KEYWORDFILTER)
        def set_keyword_filter(self, control_id):
            utils.log('DialogMusicBrainzList.set_keyword_filter')
            result = xbmcgui.Dialog().input(heading=addon.LANG(16017),
                                            type=xbmcgui.INPUT_ALPHANUM)
            if not result or result == -1:
                return None
            #keywords = tmdb.get_keywords(result)
            if not keywords:
                return None
            if len(keywords) > 1:
                index = xbmcgui.Dialog().select(heading=addon.LANG(32114),
                                                list=[item['name'] for item in keywords])
                keyword = keywords[index] if index > -1 else None
                if not keyword:
                    return None
            else:
                keyword = keywords[0]
            self.add_filter(key='with_keywords',
                            value=keyword['id'],
                            label=keyword['name'])

        def fetch_data(self, force=False):  # TODO: rewrite
            utils.log('DialogMusicBrainzList.fetch_data')
            sort_by = self.sort + '.' + self.order
            
            utils.log(sort_by)
            utils.log(self.type)
            utils.log(self.mode)

            if self.mode == 'search':
                self.filter_label = addon.LANG(32146) % self.search_str if self.search_str else ''
                return mb.search(search_str=self.search_str,
                                         media_type=self.type,
                                         page=self.page,
                                         cache_days=0 if force else 2)
                
    utils.log('get_window')
    return DialogMusicBrainzList
