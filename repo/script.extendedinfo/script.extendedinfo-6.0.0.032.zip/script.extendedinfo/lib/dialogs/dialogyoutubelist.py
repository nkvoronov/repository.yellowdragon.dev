# -*- coding: utf8 -*-

import datetime
import xbmcgui

from lib.youtube import youtube
from lib.windowmanager import wm
from lib.dialogs import DialogBaseVideoList

from lib.tools import addon
from lib.tools import utils
from lib.tools import windows
from lib.tools import busy
from lib.tools import ActionHandler

LIST_YOUTUBE = 'script-extendedinfo-YoutubeList.xml'

chv = ActionHandler(type='video')

ID_BUTTON_SORTTYPE = 5001
ID_BUTTON_PUBLISHEDFILTER = 5002
ID_BUTTON_LANGUAGEFILTER = 5003
ID_BUTTON_DIMENSIONFILTER = 5006
ID_BUTTON_DURATIONFILTER = 5008
ID_BUTTON_CAPTIONFILTER = 5009
ID_BUTTON_DEFINITIONFILTER = 5012
ID_BUTTON_TYPEFILTER = 5013

class DialogYoutubeList(DialogBaseVideoList, windows.DialogXML):

    TYPES = ['video', 'channel', 'playlist']

    FILTERS = {'channelId': addon.LANG(19029),
               'publishedAfter': addon.LANG(172),
               'regionCode': addon.LANG(248),
               'videoDimension': addon.LANG(32057),
               'videoDuration': addon.LANG(180),
               'videoCaption': addon.LANG(287),
               'videoDefinition': addon.LANG(169),
               'videoType': 'Type',
               'relatedToVideoId': addon.LANG(32058)
    }

    TRANSLATIONS = {'video': addon.LANG(157),
                    'channel': addon.LANG(19029), 
                    'playlist': addon.LANG(559)                    
    }

    SORTS = {'video': {'date': addon.LANG(552),
                       'rating': addon.LANG(563),
                       'relevance': addon.LANG(32060),
                       'title': addon.LANG(369),
                       'viewCount': addon.LANG(32061)
             },
             'channel': {'date': addon.LANG(552),
                         'rating': addon.LANG(563),
                         'relevance': addon.LANG(32060),
                         'title': addon.LANG(369),
                         'videoCount': addon.LANG(32068)
             },             
             'playlist': {'date': addon.LANG(552),
                          'rating': addon.LANG(563),
                          'relevance': addon.LANG(32060),
                          'title': addon.LANG(369),
                          'videoCount': addon.LANG(32068)
             }
    }

    LABEL2 = {'date': lambda x: x.get_info('premiered'),
              'relevance': lambda x: x.get_info('premiered'),
              'title': lambda x: x.get_info('premiered'),
              'viewCount': lambda x: x.get_property('viewcount'),
              'videoCount': lambda x: x.get_info('premiered'),
              'rating': lambda x: x.get_info('premiered')
    }

    @busy.set_busy
    def __init__(self, *args, **kwargs):
        utils.log('DialogYoutubeList.__init__')
        self.type = kwargs.get('type', 'video')
        super(DialogYoutubeList, self).__init__(*args, **kwargs)

    def onClick(self, control_id):
        utils.log('DialogYoutubeList.onClick')
        super(DialogYoutubeList, self).onClick(control_id)
        chv.serve(control_id, self)

    def onAction(self, action):
        utils.log('DialogYoutubeList.onAction')
        super(DialogYoutubeList, self).onAction(action)
        chv.serve_action(action, self.getFocusId(), self)

    @chv.click_by_type('video')
    def main_list_click(self, control_id):
        utils.log('DialogYoutubeList.main_list_click')
        listitem = self.FocusedItem(control_id)
        youtube_id = listitem.getProperty('youtube_id')
        media_type = listitem.getProperty('type')
        if media_type == 'channel':
            filter_ = [{'id': youtube_id,
                        'type': 'channelId',
                        'label': listitem.getLabel()}]
            wm.open_youtube_list(filters=filter_)
        else:
            wm.play_youtube_video(youtube_id=youtube_id,
                                  listitem=listitem)

    @chv.click(ID_BUTTON_PUBLISHEDFILTER)
    def set_published_filter(self, control_id):
        utils.log('DialogYoutubeList.set_published_filter')
        options = [(1, addon.LANG(32062)),
                   (7, addon.LANG(32063)),
                   (31, addon.LANG(32064)),
                   (365, addon.LANG(32065)),
                   ('custom', addon.LANG(636))
        ]
        deltas = [i[0] for i in options]
        labels = [i[1] for i in options]
        index = xbmcgui.Dialog().select(heading=addon.LANG(32151),
                                        list=labels)
        if index == -1:
            return None
        delta = deltas[index]
        if delta == 'custom':
            delta = xbmcgui.Dialog().input(heading=addon.LANG(32067),
                                           type=xbmcgui.INPUT_NUMERIC)
        if not delta:
            return None
        d = datetime.datetime.now() - datetime.timedelta(int(delta))
        self.add_filter(key='publishedAfter',
                        value=d.isoformat('T')[:-7] + 'Z',
                        label=labels[index])

    @chv.click(ID_BUTTON_LANGUAGEFILTER)
    def set_language_filter(self, control_id):
        utils.log('DialogYoutubeList.set_language_filter')
        options = [('en', 'en'),
                   ('ru', 'ru'),
                   ('de', 'de'),
                   ('fr', 'fr')
        ]
        self.choose_filter('regionCode', 32151, options)

    @chv.click(ID_BUTTON_DIMENSIONFILTER)
    def set_dimension_filter(self, control_id):
        utils.log('DialogYoutubeList.set_dimension_filter')
        options = [('2d', '2D'),
                   ('3d', '3D'),
                   ('any', addon.LANG(593))]
        self.choose_filter('videoDimension', 32151, options)

    @chv.click(ID_BUTTON_DURATIONFILTER)
    def set_duration_filter(self, control_id):
        utils.log('DialogYoutubeList.set_duration_filter')
        options = [('long', addon.LANG(33013)),
                   ('medium', addon.LANG(601)),
                   ('short', addon.LANG(33012)),
                   ('any', addon.LANG(593))
        ]
        self.choose_filter('videoDuration', 32151, options)

    @chv.click(ID_BUTTON_CAPTIONFILTER)
    def set_caption_filter(self, control_id):
        utils.log('DialogYoutubeList.set_caption_filter')
        options = [('closedCaption', addon.LANG(107)),
                   ('none', addon.LANG(106)),
                   ('any', addon.LANG(593))
        ]
        self.choose_filter('videoCaption', 287, options)

    @chv.click(ID_BUTTON_DEFINITIONFILTER)
    def set_definition_filter(self, control_id):
        utils.log('DialogYoutubeList.set_definition_filter')
        options = [('high', addon.LANG(419)),
                   ('standard', addon.LANG(602)),
                   ('any', addon.LANG(593))
        ]
        self.choose_filter('videoDefinition', 169, options)

    @chv.click(ID_BUTTON_TYPEFILTER)
    def set_type_filter(self, control_id):
        utils.log('DialogYoutubeList.set_type_filter')
        options = [('movie', addon.LANG(20338)),
                   ('episode', addon.LANG(20359)),
                   ('any', addon.LANG(593))
        ]
        self.choose_filter('videoType', 32151, options)

    @chv.click(ID_BUTTON_SORTTYPE)
    def get_sort_type(self, control_id):
        utils.log('DialogYoutubeList.get_sort_type')
        if not self.choose_sort_method(self.type):
            return None
        self.update()

    @chv.context('video')
    def context_menu(self, control_id):
        utils.log('DialogYoutubeList.context_menu')
        listitem = self.FocusedItem(control_id)
        if self.type == 'video':
            more_vids = '{} [B]{}[/B]'.format(addon.LANG(32081),
                                              listitem.getProperty('channel_title'))
            index = xbmcgui.Dialog().contextmenu(list=[addon.LANG(32069), more_vids])
            if index < 0:
                return None
            elif index == 0:
                filter_ = [{'id': listitem.getProperty('youtube_id'),
                            'type': 'relatedToVideoId',
                            'label': listitem.getLabel()}
                ]
                wm.open_youtube_list(filters=filter_)
            elif index == 1:
                filter_ = [{'id': listitem.getProperty('channel_id'),
                            'type': 'channelId',
                            'label': listitem.getProperty('channel_title')}
                ]
                wm.open_youtube_list(filters=filter_)

    def update_ui(self):
        utils.log('DialogYoutubeList.update_ui')
        is_video = self.type == 'video'
        self.getControl(ID_BUTTON_DIMENSIONFILTER).setVisible(is_video)
        self.getControl(ID_BUTTON_DURATIONFILTER).setVisible(is_video)
        self.getControl(ID_BUTTON_CAPTIONFILTER).setVisible(is_video)
        self.getControl(ID_BUTTON_DEFINITIONFILTER).setVisible(is_video)
        super(DialogYoutubeList, self).update_ui()

    @property
    def default_sort(self):
        utils.log('DialogYoutubeList.default_sort')
        return 'date'

    def add_filter(self, **kwargs):
        utils.log('DialogYoutubeList.add_filter')
        kwargs['typelabel'] = self.FILTERS[kwargs['key']]
        super(DialogYoutubeList, self).add_filter(force_overwrite=True, **kwargs)

    def fetch_data(self, force=False):
        utils.log('DialogYoutubeList.fetch_data')
        utils.log('TYPE : %s' % self.type)
        utils.log('MODE : %s' % self.mode)
        utils.log('SORT : %s' % self.sort)
        utils.log('ORDER : %s' % self.order)
        utils.log('SEARCH : %s' % self.search_str)
        self.set_filter_label()
        filters = {item['type']: item['id'] for item in self.filters}
        save_filter_label = self.filter_label
        if self.search_str:
            self.filter_label = addon.LANG(32146) % self.search_str
            if save_filter_label:
                self.filter_label = self.filter_label + ' / ' + save_filter_label
        return youtube.search(search_str=self.search_str,
                              orderby=self.sort,
                              extended=True,
                              filters=filters,
                              media_type=self.type,
                              page=self.page_token)

def open(self, search_str='', filters=None, sort='date', filter_label='', media_type='video'):
    """
    open video list, deal with window stack
    """
    utils.log('dialogyoutubelist:open')
    YouTube = DialogYoutubeList()
    dialog = YouTube(LIST_YOUTUBE, 
                     addon.PATH,
                     search_str=search_str,
                     filters=[] if not filters else filters,
                     filter_label=filter_label,
                     type=media_type)
    return dialog