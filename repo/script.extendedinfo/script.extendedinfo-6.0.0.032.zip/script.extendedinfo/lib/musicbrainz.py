# -*- coding: utf8 -*-

import re
import time
import urllib.parse

from .fanarttv import ftv
from .coverartarchive import caa

from lib.tools import addon
from lib.tools import utils
from lib.tools import AudioItem
from lib.tools import ItemList
from lib.tools import localdb

PLUGIN_BASE = 'plugin://script.extendedinfo/?info='

URL_BASE = 'https://musicbrainz.org/ws/2'
LUCENE_SPECIAL = r'([+\-&|!(){}\[\]\^"~*?:\\\/])'
MIN_LIMIT = 25
MAX_LIMIT = 100

# lookup:   URL_BASE/<ENTITY_TYPES>/<MBID>?inc=<INCLUDES_LOOKUP>
# browse:   URL_BASE/<ENTITY_TYPES>?<BROWSING_ENTITY_TYPES>=<MBID>&limit=<LIMIT>&offset=<OFFSET>&inc=<INCLUDES_BROWSE>
# search:   URL_BASE/<ENTITY_TYPES>?query=<QUERY>&limit=<LIMIT>&offset=<OFFSET>

# genre all:/genre/all?limit=<LIMIT>&offset=<OFFSET>

# https://musicbrainz.org/ws/2/artist?query=accept&fmt=json 
# https://musicbrainz.org/ws/2/release-group?query=accept&fmt=json
# https://musicbrainz.org/ws/2/release?query=accept&fmt=json
# https://musicbrainz.org/ws/2/recording?query=paranoid&fmt=json

# ENTITY_TYPES
ENTITY_TYPE_CORE = ['area', 'artist', 'event', 'genre', 'instrument', 'label', 'place', 'recording', 'release', 'release-group', 'series', 'work', 'url']
ENTITY_TYPE_NON_CORE = ['rating', 'tag', 'collection', 'genre']
ENTITY_TYPE_OTHER = ['discid', 'isrc', 'iswc']
ENTITY_TYPES = ENTITY_TYPE_CORE + ENTITY_TYPE_NON_CORE + ENTITY_TYPE_OTHER

RELATABLE_TYPES = ['area', 'artist', 'event', 'instrument', 'label', 'place', 'recording', 'release', 'release-group', 'series', 'url', 'work']
RELATION_INCLUDES = [entity + '-rels' for entity in RELATABLE_TYPES]
TAG_INCLUDES = ['tags', 'user-tags']
RATING_INCLUDES = ['ratings', 'user-ratings']

VALID_INCLUDES_LOOKUP = {
    'area' : ['aliases', 'annotation'] + RELATION_INCLUDES,
    'artist': [
        'recordings', 'releases', 'release-groups', 'works', # Subqueries
        'various-artists', 'discids', 'media', 'isrcs',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'collection': ['releases'],
    'event' : ['aliases'] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'genre' : [],
    'annotation': [],
    'instrument': ['aliases', 'annotation'] + RELATION_INCLUDES + TAG_INCLUDES,
    'label': [
        'releases', # Subqueries
        'discids', 'media',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'place' : ['aliases', 'annotation'] + RELATION_INCLUDES + TAG_INCLUDES,
    'recording': [
        'artists', 'releases', # Subqueries
        'discids', 'media', 'artist-credits', 'isrcs',
        'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': [
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': [
        'artists', 'releases', 'discids', 'media',
        'artist-credits', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'series': [
        'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'work': [
        'artists', # Subqueries
        'aliases', 'annotation'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'discid': [ # Discid should be the same as release
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'isrc': ['artists', 'releases', 'puids', 'isrcs'],
    'iswc': ['artists'],   
}

VALID_INCLUDES_BROWSE = {
    'artist': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'event': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'label': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'recording': ['artist-credits', 'isrcs'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': ['artist-credits', 'labels', 'recordings', 'isrcs', 'release-groups', 'media', 'discids'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'place': ['aliases'] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': ['artist-credits'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'work': ['aliases', 'annotation'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,    
}

VALID_LINKED_ENTITIES = {
    'area': ['collection'],
    'artist': ['area', 'collection', 'recording', 'release', 'release-group', 'work'],
    'collection': ['area', 'artist', 'editor', 'event', 'label', 'place', 'recording', 'release', 'release-group', 'work'],
    'event': ['area', 'artist', 'collection', 'place'],
    'instrument': ['collection'],
    'label': ['area', 'collection', 'release'],
    'place': ['area', 'collection'],
    'recording': ['artist', 'collection', 'release', 'work'],
    'release': ['area', 'artist', 'collection', 'label', 'track', 'track_artist', 'recording', 'release-group'],
    'release-group': ['artist', 'collection', 'release'],
    'series': ['collection'],
    'work': ['artist', 'collection'],
    'url': ['resource'],
}

#: These can be used to filter whenever releases are includes or browsed
VALID_RELEASE_TYPES = [
    'album', 'single', 'ep', 'broadcast', 'other', # primary types
    'audio drama', 'audiobook', 'broadcast', 'compilation', 'dj-mix',
    'interview', 'live', 'mixtape/street', 'remix', 'soundtrack', 'spokenword', # secondary types
]
#: These can be used to filter whenever releases or release-groups are involved
VALID_RELEASE_STATUSES = ['official', 'promotion', 'bootleg', 'pseudo-release']

VALID_SEARCH_FIELDS = {
    'annotation': [
        'entity', 'name', 'text', 'type'
    ],
    'area': [
        'aid', 'area', 'alias', 'begin', 'comment', 'end', 'ended',
        'iso', 'iso1', 'iso2', 'iso3', 'type'
    ],
    'artist': [
        'arid', 'artist', 'artistaccent', 'alias', 'begin', 'comment',
        'country', 'end', 'ended', 'gender', 'ipi', 'sortname', 'tag', 'type',
        'area', 'beginarea', 'endarea'
    ],
    'label': [
        'alias', 'begin', 'code', 'comment', 'country', 'end', 'ended',
        'ipi', 'label', 'labelaccent', 'laid', 'sortname', 'type', 'tag',
        'area'
    ],
    'recording': [
        'arid', 'artist', 'artistname', 'creditname', 'comment',
        'country', 'date', 'dur', 'format', 'isrc', 'number',
        'position', 'primarytype', 'puid', 'qdur', 'recording',
        'recordingaccent', 'reid', 'release', 'rgid', 'rid',
        'secondarytype', 'status', 'tnum', 'tracks', 'tracksrelease',
        'tag', 'type', 'video'
    ],
    'release-group': [
        'arid', 'artist', 'artistname', 'comment', 'creditname',
        'primarytype', 'rgid', 'releasegroup', 'releasegroupaccent',
        'releases', 'release', 'reid', 'secondarytype', 'status',
        'tag', 'type'
    ],
    'release': [
        'arid', 'artist', 'artistname', 'asin', 'barcode', 'creditname',
        'catno', 'comment', 'country', 'creditname', 'date', 'discids',
        'discidsmedium', 'format', 'laid', 'label', 'lang', 'mediums',
        'primarytype', 'puid', 'quality', 'reid', 'release', 'releaseaccent',
        'rgid', 'script', 'secondarytype', 'status', 'tag', 'tracks',
        'tracksmedium', 'type'
    ],
    'series': [
        'alias', 'comment', 'sid', 'series', 'type'
    ],
    'work': [
        'alias', 'arid', 'artist', 'comment', 'iswc', 'lang', 'tag',
        'type', 'wid', 'work', 'workaccent'
    ],
}

basestring = (str,bytes)

# Exceptions.

class MusicBrainzError(Exception):
    pass

class UsageError(MusicBrainzError):
    pass

class InvalidSearchFieldError(UsageError):
    pass
    
class InvalidEntityError(UsageError):
    def __init__(self, msg='Invalid Entity', reason=None):
        super(InvalidIncludeError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg

class InvalidIncludeError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidIncludeError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg

class InvalidFilterError(UsageError):
    def __init__(self, msg='Invalid Filteres', reason=None):
        super(InvalidFilterError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg
        
class MusicBrainz(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('MusicBrainz.__init__')
        self.sort=None
        self.sort_order=None
        
    # Helpers for validating and formatting allowed sets.
    def check_entity(self, entity):
        utils.log('MusicBrainz.check_entity')
        if entity not in ENTITY_TYPES:
            raise InvalidEntityError('Bad entity: '
                                     '%s is not a valid entity' % entity)
                                     
    def check_linked_entity(self, entity, linked_entity):
        utils.log('MusicBrainz.check_linked_entity')
        if linked_entity not in VALID_LINKED_ENTITIES[entity]:
            raise InvalidEntityError('Bad linked entity: '
                                     '%s is not a valid linked entity for %s' % (linked_entity,entity))

    def check_includes_impl(self, includes, valid_includes):
        utils.log('MusicBrainz.check_includes_impl')
        for i in includes:
            if i not in valid_includes:
                raise InvalidIncludeError('Bad includes: '
                                          '%s is not a valid include' % i)
    def check_includes_lookup(self, entity, inc):
        utils.log('MusicBrainz.check_includes')
        self.check_includes_impl(inc, VALID_INCLUDES_LOOKUP[entity])
        
    def check_includes_browse(self, entity, inc):
        utils.log('MusicBrainz.check_includes')
        self.check_includes_impl(inc, VALID_INCLUDES_BROWSE[entity])

    def check_filter(self, values, valid):
        utils.log('MusicBrainz.check_filter')
        for v in values:
            if v not in valid:
                raise InvalidFilterError(v)
        
    def get_data(self, url='', params=None, cache_days=14):
        utils.log('MusicBrainz.get_data')
        params = params if params else {}
        params['fmt'] = 'json'
        params = {k: v for k, v in params.items() if v}
        url = '%s/%s?%s' % (URL_BASE, url, urllib.parse.urlencode(params))
        utils.log(url)
        return utils.get_JSON_response(url=url,
                                       cache_days=cache_days, 
                                       folder='MusicBrainz')
                                       
    def get_lookup(self, entity, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.get_lookup')
        # Build arguments.
        self.check_entity(entity)
        if mbid == '':
            raise ValueError('mbid is required')
        url = '%s/%s' % (entity, mbid)
        # Build params.
        params = {}
        # Build includes.
        if not isinstance(includes, list):
            includes = [includes]
        self.check_includes_lookup(entity, includes)        
        if len(includes) > 0:
            inc = ' '.join(includes)
            params['inc'] = inc
        return self.get_data(url=url, 
                             params=params,
                             cache_days=cache_days)
                             
    def get_browse(self, entity, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.get_browse')
        # Build arguments.
        self.check_entity(entity)
        url = entity
        # Build params.
        params = {}
        self.check_linked_entity(entity,linked_entity)
        if mbid == '':
            raise ValueError('mbid is required')
        params[linked_entity] = mbid
        # Build includes.
        if not isinstance(includes, list):
            includes = [includes]
        self.check_includes_browse(entity, includes)       
        if len(includes) > 0:
            inc = ' '.join(includes)
            params['inc'] = inc
        # Build filters.    
        if isinstance(release_status, basestring):
            release_status = [release_status]
        if isinstance(release_type, basestring):
            release_type = [release_type]
        self.check_filter(release_status, VALID_RELEASE_STATUSES)
        self.check_filter(release_type, VALID_RELEASE_TYPES)
        if (release_status 
                and 'releases' not in includes and entity != 'release'):
            raise InvalidFilterError('Can''t have a status with no release include')
        if (release_type
                and 'release-groups' not in includes and 'releases' not in includes
                and entity not in ['release-group', 'release']):
            raise InvalidFilterError('Can''t have a release type '
                    'with no releases or release-groups involved') 
        if len(release_status):
            params['status'] = '|'.join(release_status)
        if len(release_type):
            params['type'] = '|'.join(release_type)
        # Additional parameters to the browse.
        if limit:
            params['limit'] = str(limit)
        if offset:
            params['offset'] = str(offset)
        return self.get_data(url=url, 
                             params=params,
                             cache_days=cache_days)
            
    def get_search(self, entity, query='', fields={}, strict=False, limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.get_search')
        # Build arguments.
        self.check_entity(entity)
        url = entity
        # Build params.
        params = {}
        # Encode the query terms as a Lucene query string.        
        query_parts = []
        if query:
            # clean_query = util._unicode(query)
            clean_query = query
            if fields:
                clean_query = re.sub(LUCENE_SPECIAL, r'\\\1', clean_query)
                if strict:
                    query_parts.append('"%s"' % clean_query)
                else:
                    query_parts.append(clean_query.lower())
            else:
                query_parts.append(clean_query)
        for key, value in fields.items():
            # Ensure this is a valid search field.
            if key not in VALID_SEARCH_FIELDS[entity]:
                raise InvalidSearchFieldError(
                    '%s is not a valid search field for %s' % (key, entity)
                )
            elif key == 'puid':
                warn('PUID support was removed from server\n'
                     'the "puid" field is ignored',
                     Warning, stacklevel=2)
            # Escape Lucene's special characters.
            # value = util._unicode(value)
            value = re.sub(LUCENE_SPECIAL, r'\\\1', value)
            if value:
                if strict:
                    query_parts.append('%s:"%s"' % (key, value))
                else:
                    value = value.lower() # avoid AND / OR
                    query_parts.append('%s:(%s)' % (key, value))
        if strict:
            full_query = ' AND '.join(query_parts).strip()
        else:
            full_query = ' '.join(query_parts).strip()
        if not full_query:
            raise ValueError('at least one query term is required')
        # Additional parameters to the search.
        params = {'query': full_query}
        if limit:
            params['limit'] = str(limit)
        if offset:
            params['offset'] = str(offset)
        return self.get_data(url=url, 
                             params=params,
                             cache_days=cache_days)
                             
    # LOOKUPS

    def lookup_area(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_area')
        return self.get_lookup(entity='area', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_artist(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_artist')
        return self.get_lookup(entity='artist', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)
                              
    def lookup_event(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_event')
        return self.get_lookup(entity='event', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)
                              
    def lookup_genre(self, mbid='all', includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_genre')
        return self.get_lookup(entity='genre', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_instrument(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_instrument')
        return self.get_lookup(entity='instrument', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_label(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_label')
        return self.get_lookup(entity='label', 
                               mbid=mbid,
                               includes=includes,
                               cache_days=cache_days)

    def lookup_place(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_place')
        return self.get_lookup(entity='place', 
                               mbid=mbid,
                               includes=includes,
                               cache_days=cache_days)

    def lookup_recording(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_recording')
        return self.get_lookup(entity='recording', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_release(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_release')
        return self.get_lookup(entity='release', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_release_group(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_release_group')
        return self.get_lookup(entity='release-group', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_series(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_series')
        return self.get_lookup(entity='series', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_work_by(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_work')
        return self.get_lookup(entity='work', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)

    def lookup_url(self, mbid, includes=[], cache_days=14):
        utils.log('MusicBrainz.lookup_url')
        return self.get_lookup(entity='url', 
                               mbid=mbid, 
                               includes=includes,
                               cache_days=cache_days)
                              
    # BROWSE
    
    def browse_areas(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_areas')
        return self.get_browse(entity='area', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
    
    def browse_artists(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_artists')
        return self.get_browse(entity='artist', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_events(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_events')
        return self.get_browse(entity='event', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_instruments(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_instruments')
        return self.get_browse(entity='instrument', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
    
    def browse_labels(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_labels')
        return self.get_browse(entity='label', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_places(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_places')
        return self.get_browse(entity='place', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_recordings(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_recordings')
        return self.get_browse(entity='recording', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_releases(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_releases')
        return self.get_browse(entity='release', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_release_groups(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_release_groups')
        return self.get_browse(entity='release_group', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_series(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_series')
        return self.get_browse(entity='series', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_works(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_works')
        return self.get_browse(entity='work', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)
        
    def browse_urls(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], limit=MIN_LIMIT, offset=0, cache_days=14):
        utils.log('MusicBrainz.browse_urls')
        return self.get_browse(entity='url', 
                               linked_entity=linked_entity,
                               mbid=mbid,
                               includes=includes,
                               release_status=release_status,
                               release_type=release_type,
                               limit=limit,
                               offset=offset,
                               cache_days=cache_days)

    # BROWSE ALL
    
    def browse_releases_all(self, linked_entity, mbid, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.browse_releases_all')
        limit = MAX_LIMIT
        offset = 0
        releases = []
        page = 1
        count = 0
        
        response = self.browse_releases(linked_entity=linked_entity, 
                                        mbid=mbid, 
                                        includes=includes,
                                        limit=limit, 
                                        offset=offset, 
                                        cache_days=cache_days)

        page_releases = response.get('releases')
        releases += page_releases
        count = response.get('release-count')
        utils.log('release-count : %s' % count)
        while len(page_releases) >= limit:
            offset += limit
            page += 1

            response = self.browse_releases(linked_entity=linked_entity, 
                                            mbid=mbid, 
                                            includes=includes,
                                            limit=limit, 
                                            offset=offset, 
                                            cache_days=cache_days)

            page_releases = response.get('releases')
            releases += page_releases
        utils.log('release len : %s' % len(releases))
        return releases
        
    def browse_genre_all(self):
        utils.log('MusicBrainz.browse_genre_all')
        limit = MAX_LIMIT
        offset = 0
        genres = []
        page = 1
        count = 0
        
        params = {}
        params['offset'] = offset
        params['limit'] = limit        
        response = self.get_data(url='genre/all', 
                                 params=params)

        page_genres = response.get('genres')
        genres += page_genres       
        count = response.get('genre-count')
        utils.log(count)
        while len(page_genres) >= limit:
            offset += limit
            page += 1
            
            params['offset'] = offset
            response = self.get_data(url='genre/all', 
                                     params=params)

            page_genres = response.get('genres')
            genres += page_genres
        utils.log(len(genres))
        return genres

    # SEARCH

    def search_annotations(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_annotations')
        return self.get_search(entity='annotation', 
                               query=query,
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_areas(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_areas')
        return self.get_search(entity='area', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_artists(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_artists')
        return self.get_search(entity='artist', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)
                               
    def search_collections(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_collections')
        return self.get_search(entity='collection', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_events(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_events')
        return self.get_search(entity='event', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)
                               
    def search_genres(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_genres')
        return self.get_search(entity='genre', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_instruments(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_instruments')
        return self.get_search(entity='instrument', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_labels(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_labels')
        return self.get_search(entity='label', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_places(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_places')
        return self.get_search(entity='place', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_recordings(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_recordings')
        return self.get_search(entity='recording', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_releases(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_releases')
        return self.get_search(entity='release', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_release_groups(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_release_groups')
        return self.get_search(entity='release-group',
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_series(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_series')
        return self.get_search(entity='series', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)

    def search_works(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_works')
        return self.get_search(entity='work', 
                               query=query, 
                               fields=fields,
                               strict=strict,
                               limit=limit, 
                               offset=offset,                              
                               cache_days=cache_days)
                               
    def search_urls(self, query='', strict=False, limit=MIN_LIMIT, offset=0, cache_days=14, **fields):
        utils.log('MusicBrainz.search_urls')
        return self.get_search(entity='url', 
                               query=query, 
                               fields=fields, 
                               strict=strict,
                               limit=limit, 
                               offset=offset,                               
                               cache_days=cache_days)
                               
    # OTHER
        
    def get_field(self, data=None):
        utils.log('MusicBrainz.get_field')
        text = ''
        if data:
            text = data
        return text
        
    def get_subfield(self, data=None, field='name'):
        utils.log('MusicBrainz.get_subfield')
        text = ''
        if data:
            text = self.get_field(data.get(field))
        return text
        
    def get_strlist(self, data=None, field='name', sep=', ', title=False, lower=False):
        utils.log('MusicBrainz.get_strlist')
        text = ''
        lst = []
        if data:        
            for item in data:
                fld = str(self.get_field(item.get(field)))
                if fld != '':
                    if title:
                        fld = fld.title()
                    if lower:
                        fld = fld.lower()
                    if fld.find(' / ') == -1:
                        lst.append(str(fld))
            text = sep.join(lst)
        return text
       
    def get_array_tostr(self, data=None, sep=', '):
        utils.log('MusicBrainz.get_array_tostr')
        text = ''
        tps = []
        if data:       
            for item in data:
                tps.append(item) 
            text = sep.join(tps)
        return text
        
    def get_description(self, media_type):
        utils.log('MusicBrainz.get_description')
        return ''
       
    def get_artist_credit(self, data=None, field='name', sep=', '):
        utils.log('MusicBrainz.get_artists')
        text = ''
        artists = []
        if data:        
            for artistcredit in data:
                 artist = self.get_field(artistcredit.get('artist'))
                 if artist != '':
                    artists.append(self.get_field(artist.get(field)))         
            text = sep.join(artists)
        return text

    def get_releases(self, data=None):
        utils.log('MusicBrainz.get_releases')
        titles = []
        ids = []
        gids = []
        if data:
            for release in data:
                title = self.get_field(release.get('title'))
                if title != '':
                    titles.append(title)
                id = self.get_field(release.get('id'))
                if id != '':
                    ids.append(id)
                release_group = self.get_field(release.get('release-group'))
                if release_group !='':
                    gid = self.get_field(release_group.get('id'))
                    if gid !='':
                        gids.append(gid)
        return titles, ids, gids
        
    def get_media_info(self, data=None):
        utils.log('MusicBrainz.get_media_info')
        formats = '(unknown)'
        uformats = {}
        aformats = []
        track_count = []
        if data:        
            for item in data:
                fld1 = str(self.get_field(item.get('format')))
                if fld1 != '':
                    if fld1 not in uformats:
                        val = {'name': fld1,
                               'count': 1
                        }
                        uformats[fld1] = val
                        
                    else:
                        val = uformats[fld1]
                        count = int(val.get('count'))
                        count += 1
                        val = {'name': fld1,
                               'count': count
                        }
                        uformats[fld1] = val

                fld2 = str(self.get_field(item.get('track-count')))
                if fld2 != '':
                    track_count.append(fld2)
                
        for key in uformats.keys():
            val = uformats[key]
            count = int(val.get('count'))
            if count > 1:
                text = str(count) + ' X ' + key
            else:
                text = key
            aformats.append(text)
        if len(aformats) > 0:
            formats = ' + '.join(aformats)
        return formats, ' + '.join(track_count)
        
    def get_label_info(self, data=None):
        utils.log('MusicBrainz.get_releases')       
        catalognum = []
        catalognums = '[none]'
        ulabels = []
        labels = ''
        if data:
            for item in data:
                ncatalog = self.get_field(item.get('catalog-number'))
                if ncatalog != '':
                    if ncatalog not in catalognum:
                        catalognum.append(ncatalog)
                
                name = self.get_subfield(item.get('label'), 'name')
                disambiguation = self.get_subfield(item.get('label'), 'disambiguation')                
                if name != '':        
                    if disambiguation != '':
                        name = name + ' (' + disambiguation + ')'
                    if name not in ulabels:
                        ulabels.append(name)
        labels = ', '.join(ulabels)
        if len(catalognum) > 0:
            catalognums = ', '.join(catalognum)
        return labels, catalognums
        
    # ARTIST (artist)

    def handle_artist(self, results, sort=True):
        utils.log('MusicBrainz.handle_artist')
        media_type = 'artist'
        db_media_type = 'artist'
        artists = ItemList(content_type=media_type)
        path = 'extendedartistinfo&&id=%s'        
        for artist in results:            
            title = self.get_field(artist.get('name'))
            label = title
            genre = self.get_strlist(data=artist.get('tags'),
                                     sep=' / ',
                                     title=True)
            musicbrainz_artist_id = self.get_field(artist.get('id'))
            artist_born = self.get_subfield(artist.get('life-span'), 'begin')
            artist_died = self.get_subfield(artist.get('life-span'), 'end')
            description = self.get_description(media_type)
            disambiguation = self.get_field(artist.get('disambiguation'))
            artist_type = self.get_field(artist.get('type'))
            artist_sortname = self.get_field(artist.get('sort-name'))            
            artist_gender = self.get_field(artist.get('gender'))
            artist_begin_area =  self.get_subfield(artist.get('begin-area'))
            artist_end_area =  self.get_subfield(artist.get('end-area'))            
            artist_ended = self.get_subfield(artist.get('life-span'), 'ended')
            if artist_ended == 'true':
                artist_ended = True
            else:
                artist_ended = False
            country = self.get_subfield(artist.get('area'))
            if country == '':
                country = str(self.get_field(artist.get('country'))).lower()
            score = self.get_field(artist.get('score'))

            if disambiguation != '':
                label = label + ' (' + disambiguation + ')'
            
            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_artist_id)
            
            item.set_infos({
                'title': title,
                'genre': genre,
                'mediatype': db_media_type
            })
            
            item.set_properties({
                'mediatype_alt': media_type,
                'musicbrainzartistid': musicbrainz_artist_id,
                'artist_born': artist_born,
                'artist_died': artist_died,            
                'artist_description': description,
                'artist_disambiguation': disambiguation,
                'artist_type': artist_type,
                'artist_sortname': artist_sortname,                 
                'artist_gender': artist_gender,
                'artist_begin_area': artist_begin_area,
                'artist_end_area': artist_end_area,
                'artist_ended': artist_ended,
                'country': country,
                'score': score
            })
            
            item.set_artwork(self.get_image_urls(media_type=media_type,
                                                 mbid=musicbrainz_artist_id,                                                 
                                                 icon='DefaultMusicArtists.png'))
            
            artists.append(item)
            
        return localdb.merge_with_local(media_type=db_media_type,
                                        items=artists,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
                                        
    def extended_artist_info(self, artist_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for movie with *artist_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_artist_info')
        if not artist_id:
            return None
        includes = ['tags', 'ratings']
        info = self.lookup_artist(mbid=artist_id,
                                  includes=includes,
                                  cache_days=cache_days)
        if not info:
            utils.notify('Could not get artist information')
            return {}
        media_type = 'artist'
        db_media_type = 'artist'
        title = self.get_field(info.get('name'))
        label = title
        genre = self.get_strlist(data=info.get('tags'),
                                 sep=' / ',
                                 title=True)
        musicbrainz_artist_id = self.get_field(info.get('id'))
        artist_born = self.get_subfield(info.get('life-span'), 'begin')
        artist_died = self.get_subfield(info.get('life-span'), 'end')
        description = self.get_description(media_type)        
        disambiguation = self.get_field(info.get('disambiguation'))
        artist_type = self.get_field(info.get('type'))
        artist_sortname = self.get_field(info.get('sort-name'))            
        artist_gender = self.get_field(info.get('gender'))
        artist_begin_area =  self.get_subfield(info.get('begin-area'))
        artist_end_area =  self.get_subfield(info.get('end-area'))            
        artist_ended = self.get_subfield(info.get('life-span'), 'ended')
        if artist_ended == 'true':
            artist_ended = True
        else:
            artist_ended = False
        country = self.get_subfield(info.get('area'))
        if country == '':
            country = str(self.get_field(info.get('country'))).lower()
        votes_count = self.get_subfield(info.get('rating'), 'votes-count')
        rating = self.get_subfield(info.get('rating'), 'value')
        isnis = self.get_field(info.get('isnis'))
        youtube_search = title + ' band'

        if disambiguation != '':
                label = label + ' (' + disambiguation + ')'
        
        artist = AudioItem(label=label, path=PLUGIN_BASE + 'youtubevideo&&id=%s' % youtube_search)

        artist.set_infos({
                'title': title,
                'genre': genre,
                'mediatype': db_media_type
        })
            
        artist.set_properties({
                'mediatype_alt': media_type,
                'musicbrainzartistid': musicbrainz_artist_id,
                'youtube_search': youtube_search,
                'artist_born': artist_born,
                'artist_died': artist_died,            
                'description': description,
                'artist_disambiguation': disambiguation,
                'artist_type': artist_type,
                'artist_sortname': artist_sortname,            
                'artist_ended': artist_ended,
                'artist_gender': artist_gender,
                'artist_begin_area': artist_begin_area,
                'artist_end_area': artist_end_area,
                'artist_ended': artist_ended,
                'country': country,
                'votes-count': votes_count, 
                'rating': rating,
                'isnis': ', '.join(isnis)
        })
            
        artist.set_artwork(self.get_image_urls(media_type=media_type,
                                               mbid=musicbrainz_artist_id,                                               
                                               icon='DefaultMusicArtists.png'))
        
        if dbid:
            local_item = localdb.get_artist(dbid)
            artist.update_from_listitem(local_item)
        else:
            artist = localdb.merge_with_local(db_media_type, [artist])[0]

        allitems = self.handle_release_group_for_artist(artist_id=artist_id)
        
        imageinfo = ftv.get_data(url='music', 
                                 sid=artist_id)

        listitems = {'album': self.handle_release_groups_for_types(items=allitems),
                     'albumcompilation': self.handle_release_groups_for_types(items=allitems, atype2='compilation'),
                     'albumlive': self.handle_release_groups_for_types(items=allitems, atype2='live'),
                     'single': self.handle_release_groups_for_types(items=allitems, atype='single'),
                     'singlelive': self.handle_release_groups_for_types(items=allitems, atype='single', atype2='live'),
                     'ep': self.handle_release_groups_for_types(items=allitems, atype='ep'),
                     'eplive': self.handle_release_groups_for_types(items=allitems, atype='ep', atype2='live'),
                     'genres': self.handle_tags(info.get('tags')),
                     'images': self.handle_images_ftv(imageinfo.get('artistthumb'), 'icon'),
                     'backdrops': self.handle_images_ftv(imageinfo.get('artistbackground'), 'fanart')
        }   
        return (artist, listitems)
        
    def handle_release_groups_for_types(self, items=None, atype='album', atype2=''):
        utils.log('MusicBrainz.handle_release_groups_for_types')
        media_type = 'releasegroup'
        albums_type = ItemList(content_type=media_type)
        for item in items:     
            if item.get_property('album_type') == atype and item.get_property('album_type2') == atype2:
                albums_type.append(item)
        return albums_type
       
    def handle_release_group_for_artist(self, artist_id=None):
        utils.log('MusicBrainz.handle_release_group_for_artist')
        media_type = 'releasegroup'
        db_media_type = 'album'
        includes = ['artist-credits', 'release-groups', 'tags', 'ratings']
        release_groups = {}
        arelease_group = ItemList(content_type=media_type)
        releases = self.browse_releases_all(linked_entity='artist',
                                            mbid=artist_id,
                                            includes=includes)
        for release in releases:
            release_group = release.get('release-group')
            release_group_id = release_group.get('id')
            if release_group_id not in release_groups:
                ids = []
                ids.append(release.get('id'))
                rg = {'release_ids': ids, 
                      'count_releases': 1
                }
                release_groups[release_group_id] = rg
                
                title = self.get_field(release_group.get('title'))
                label = title
                artist = self.get_artist_credit(data=release_group.get('artist-credit'))
                genre = self.get_strlist(data=release_group.get('tags'),
                                         sep=' / ',
                                         title=True)
                album_genre = self.get_strlist(data=release_group.get('tags'))
                year = int(utils.get_year(self.get_field(release_group.get('first-release-date'))))                
                musicbrainz_release_group_id = release_group_id
                musicbrainz_release_ids = ''
                musicbrainz_artist_ids = self.get_artist_credit(data=release_group.get('artist-credit'),
                                                                field='id')           
                description = self.get_description(media_type)
                primary_type = str(self.get_field(release_group.get('primary-type'))).lower()           
                secondary_types = str(self.get_array_tostr(data=release_group.get('secondary-types'))).lower()
                album_rating = self.get_subfield(release_group.get('rating'), 'value')
                if album_rating != '':
                    album_rating = int(round(float(str(album_rating))*2))
                else:
                    album_rating = 0
                album_releases = 0

                item = AudioItem(label=label)
                
                item.set_infos({
                    'title': title,
                    'artist': artist,
                    'genre': genre,
                    'year': year,
                    'mediatype': db_media_type
                })
            
                item.set_properties({
                    'mediatype_alt': media_type,
                    'musicbrainzreleasegroupid': musicbrainz_release_group_id,
                    'musicbrainzartistsid': musicbrainz_artist_ids,
                    'musicbrainzreleasesid': musicbrainz_release_ids,
                    'description': description, 
                    'album_type': primary_type,
                    'album_type2': secondary_types,
                    'album_genre': album_genre,
                    'album_rating': album_rating, 
                    'album_releases': album_releases
                })
                
                musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
                item.set_artwork(self.get_image_urls(media_type=media_type,
                                                     mbid=musicbrainz_artist_id, 
                                                     ambid=musicbrainz_release_group_id,                                                     
                                                     icon='DefaultMusicAlbums.png'))
            
                arelease_group.append(item)                
            else:
                rg = release_groups[release_group_id]
                ids = list(rg.get('release_ids'))
                ids.append(release.get('id'))
                count = int(rg.get('count_releases'))
                count += 1
                rg = {'release_ids': ids, 
                      'count_releases': count
                }
                release_groups[release_group_id] = rg
                
        for item in arelease_group:
            release_group_id = item.get_property('musicbrainzreleasegroupid')
            rg = release_groups[release_group_id]
            item.set_property('musicbrainzreleasesid', ', '.join(list(rg.get('release_ids'))))
            item.set_property('album_releases', int(rg.get('count_releases')))

        return localdb.merge_with_local(media_type=db_media_type,
                                        items=arelease_group,
                                        sort=True,
                                        sort_by='types/year/title',
                                        sort_order='asc')

    def get_artist_mbid(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_artist_mbid')
        db_media_type = 'artist'
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mbid(db_media_type, dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
                                        
    # RELEASE-GROUP (album)
        
    def handle_release_group(self, results, sort=True):
        utils.log('MusicBrainz.handle_release_group')
        media_type = 'releasegroup'
        db_media_type = 'album'
        release_groups = ItemList(content_type=media_type)
        path = 'extendedreleasegroupinfo&&id=%s'
        for release_group in results:
            title = self.get_field(release_group.get('title'))
            label = title
            artist = self.get_artist_credit(data=release_group.get('artist-credit'))
            genre = self.get_strlist(data=release_group.get('tags'),
                                     sep=' / ',
                                     title=True)
            year = int(utils.get_year(self.get_field(release_group.get('first-release-date'))))            
            musicbrainz_release_group_id = self.get_field(release_group.get('id'))            
            musicbrainz_release_ids = self.get_strlist(data=release_group.get('releases'), 
                                                       field='id',
                                                       sep=', ')            
            musicbrainz_artist_ids = self.get_artist_credit(data=release_group.get('artist-credit'),
                                                            field='id')           
            description = self.get_description(media_type)
            primary_type = str(self.get_field(release_group.get('primary-type'))).title()           
            secondary_types = str(self.get_array_tostr(data=release_group.get('secondary-types'))).title()     
            album_releases = self.get_field(release_group.get('count'))
            score = self.get_field(release_group.get('score'))
            
            if artist:
                label = artist + ' - ' + title

            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_release_group_id)
            
            item.set_infos({
                'title': title,
                'artist': artist,
                'genre': genre,
                'year': year,
                'mediatype': db_media_type
            })
            
            item.set_properties({
                'mediatype_alt': media_type,
                'musicbrainzreleasegroupid': musicbrainz_release_group_id,
                'musicbrainzartistsid': musicbrainz_artist_ids,
                'musicbrainzreleasesid':musicbrainz_release_ids,
                'album_description': description, 
                'album_type': primary_type,
                'album_type2': secondary_types,
                'album_releases': album_releases,           
                'score': score
            })
            
            musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
            item.set_artwork(self.get_image_urls(media_type=media_type,
                                                 mbid=musicbrainz_artist_id, 
                                                 ambid=musicbrainz_release_group_id,                                                  
                                                 icon='DefaultMusicAlbums.png'))
            
            release_groups.append(item)

        return localdb.merge_with_local(media_type=db_media_type,
                                        items=release_groups,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
                                        
    def extended_release_group_info(self, release_group_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for release_groups with *release_group_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_release_group_info')
        if not release_group_id:
            return None
        includes = ['artist-credits', 'tags', 'ratings']
        info = self.lookup_release_group(mbid=release_group_id,
                                         includes=includes,
                                         cache_days=cache_days)
        utils.log(info)
        if not info:
            utils.notify('Could not get release-groups information')
            return {}
        media_type = 'releasegroup'
        db_media_type = 'album'
        title = self.get_field(info.get('title'))
        label = title
        artist = self.get_artist_credit(data=info.get('artist-credit'))
        genre = self.get_strlist(data=info.get('tags'),
                                 sep=' / ',
                                 title=True)
        year = int(utils.get_year(self.get_field(info.get('first-release-date'))))
        musicbrainz_release_group_id = self.get_field(info.get('id'))
        musicbrainz_artist_ids = self.get_artist_credit(data=info.get('artist-credit'),
                                                        field='id')           
        description = self.get_description(media_type)
        primary_type = str(self.get_field(info.get('primary-type'))).title()           
        secondary_types = str(self.get_array_tostr(data=info.get('secondary-types'))).title()
        votes_count = self.get_subfield(info.get('rating'), 'votes-count')
        rating = self.get_subfield(info.get('rating'), 'value')

        if artist:
            label = artist + ' - ' + title
            youtube_search = artist + ' ' + title
        else:
            youtube_search = title + ' band'

        release_group = AudioItem(label=label, path=PLUGIN_BASE + 'youtubevideo&&id=%s' % youtube_search)
            
        release_group.set_infos({
            'title': title,
            'artist': artist,
            'genre': genre,
            'year': year,
            'mediatype': db_media_type
        })
        
        release_group.set_properties({
            'mediatype_alt': media_type,
            'musicbrainzreleasegroupid': musicbrainz_release_group_id,            
            'musicbrainzartistsid': musicbrainz_artist_ids,
            'youtube_search': youtube_search,
            'description': description, 
            'album_type': primary_type,
            'album_type2': secondary_types,        
            'votes_count': votes_count, 
            'rating': rating
        })
        
        musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
        
        release_group.set_artwork(self.get_image_urls(media_type=media_type,
                                                      mbid=musicbrainz_artist_id, 
                                                      ambid=musicbrainz_release_group_id,                                                  
                                                      icon='DefaultMusicAlbums.png'))
                                             
        musicbrainz_release_ids, allitems = self.handle_releases_for_release_group(release_group_id=release_group_id)
        release_group.set_property('musicbrainzreleasesid', musicbrainz_release_ids)                                             
            
        if dbid:
            local_item = localdb.get_album(dbid)
            release_group.update_from_listitem(local_item)
        else:
            release_group = localdb.merge_with_local(db_media_type, [release_group])[0]
       
        listitems = {'official': self.handle_releases_for_status(items=allitems),
                     'bootleg': self.handle_releases_for_status(items=allitems, atype='bootleg'),
                     'other': self.handle_releases_for_status(items=allitems, atype='other'), 
                     'genres': self.handle_tags(info.get('tags'))
        }   
        return (release_group, listitems)
        
    def handle_releases_for_status(self, items=None, atype='official'):
        utils.log('MusicBrainz.handle_releases_for_status')
        media_type = 'release'
        releases_status = ItemList(content_type=media_type)
        for item in items:
            if atype != 'other':
                if item.get_property('release_status') == atype:
                    releases_status.append(item)
            else:
                if item.get_property('release_status') != 'official' and item.get_property('release_status') != 'bootleg':
                    releases_status.append(item)
        return releases_status
        
    def handle_releases_for_release_group(self, release_group_id=None):
        utils.log('MusicBrainz.handle_releases_for_release_group')
        media_type = 'release'
        db_media_type = 'album'
        includes = ['artist-credits', 'release-groups', 'labels', 'media', 'tags', 'ratings']
        areleases = ItemList(content_type=media_type)
        release_ids = []
        releases = self.browse_releases_all(linked_entity='release-group',
                                            mbid=release_group_id,
                                            includes=includes)
        for release in releases:
            title = self.get_field(release.get('title'))
            release_group = self.get_field(release.get('release-group'))
            artist = self.get_artist_credit(data=release.get('artist-credit'))            
            genre = self.get_strlist(data=release_group.get('tags'),
                                         sep=' / ',
                                         title=True)
            release_genre = self.get_strlist(data=release_group.get('tags'))
            year = int(utils.get_year(self.get_field(release_group.get('first-release-date'))))
            release_date = self.get_field(release.get('date'))
            if release_date == '':
                release_date = str(year)
            musicbrainz_release_group_id = release_group_id
            musicbrainz_release_id = self.get_field(release.get('id'))
            release_ids.append(musicbrainz_release_id)
            musicbrainz_artist_ids = self.get_artist_credit(data=release.get('artist-credit'),
                                                            field='id')
            description = self.get_description(media_type)
            release_country = self.get_field(release.get('country'))
            release_status = self.get_field(release.get('status')).lower()
            release_barcode = self.get_field(release.get('barcode'))
            if release_barcode == '':
                release_barcode = '[none]'               
            release_format, track_count = self.get_media_info(data=release.get('media'))
            release_label, release_catalognum = self.get_label_info(data=release.get('label-info'))

            label = release_catalognum

            item = AudioItem(label=label)
            
            item.set_infos({
                'title': title,
                'artist': artist,
                'genre': genre,
                'year': year,
                'mediatype': db_media_type
            })
            
            item.set_properties({
                'mediatype_alt': media_type,
                'musicbrainzreleaseid': musicbrainz_release_id,
                'musicbrainzreleasegroupid': musicbrainz_release_group_id,
                'musicbrainzartistsid': musicbrainz_artist_ids,
                'description': description,
                'release_genre': release_genre,
                'release_country': release_country,
                'release_date': release_date,
                'release_status': release_status,
                'release_barcode': release_barcode,
                'release_format': release_format,
                'release_label': release_label,
                'release_catalognum': release_catalognum,
                'track_count': track_count               
            })
            
            musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
        
            item.set_artwork(self.get_image_urls(media_type=media_type,
                                                 mbid=musicbrainz_artist_id, 
                                                 ambid=musicbrainz_release_group_id,                                                     
                                                 icon='DefaultMusicAlbums.png'))
        
            areleases.append(item)             
        return (', '.join(release_ids),  localdb.merge_with_local(media_type=db_media_type,
                                                                  items=areleases,
                                                                  sort=True,
                                                                  sort_by='status/date/country',
                                                                  sort_order='asc'))

    def get_release_group_mbid(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_release_group_mbid')
        db_media_type = 'album'
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mbid(db_media_type, dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
   
    # RELEASE (release)
    
    def handle_release(self, results, sort=True):
        utils.log('MusicBrainz.handle_release')        
        media_type = 'release'
        db_media_type = 'album'
        releases = ItemList(content_type=media_type)
        path = 'extendedreleaseinfo&&id=%s'
        #for release in results:
        return None
        
    def extended_release_info(self, release_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for release with *release_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_release_info')
        if not release_id:
            return None
        includes = []
        info = self.lookup_release(mbid=release_id,
                                   includes=includes,
                                   cache_days=cache_days)
        utils.log(info)
        if not info:
            utils.notify('Could not get song information')
            return {}
        media_type = 'release'
        db_media_type = 'album'
        return None
        
    def get_release_mbid(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_release_mbid')
        db_media_type = 'album'
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mbid(db_media_type, dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
                                        
    # RECORDING (song)
        
    def handle_recording(self, results, sort=True):
        utils.log('MusicBrainz.handle_recording')
        media_type = 'recording'
        db_media_type = 'song'
        recordings = ItemList(content_type=media_type)
        path = 'extendedrecordinginfo&&id=%s'
        for recording in results:
            title = self.get_field(recording.get('title'))
            label = title
            diration = self.get_field(recording.get('length'))
            artist = self.get_artist_credit(data=recording.get('artist-credit'))
            titles,ids,gds = self.get_releases(recording.get('releases'))           
            album = titles[0] 
            genre = self.get_strlist(data=recording.get('tags'),
                                     sep=' / ',
                                     title=True)
            year = int(utils.get_year(self.get_field(recording.get('first-release-date'))))            
            musicbrainz_track_id = self.get_field(recording.get('id'))
            musicbrainz_artist_ids = self.get_artist_credit(data=recording.get('artist-credit'),
                                                            field='id')         
            musicbrainz_release_id = ids[0]
            musicbrainz_group_release_id = gds[0]                                 
            score = self.get_field(recording.get('score'))
            
            if artist:
                label = artist + ' - ' + title
            
            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_track_id)
            
            item.set_infos({
                'title': title,
                'duration': diration,
                'artist': artist,
                'album': album,
                'genre': genre,
                'year': year,
                'mediatype': db_media_type
            })
            
            item.set_properties({
                'mediatype_alt': media_type,
                'musicbrainztrackid': musicbrainz_track_id,
                'musicbrainzartistids': musicbrainz_artist_ids,
                'musicbrainzreleaseid': musicbrainz_release_id,
                'musicbrainzgroupreleaseid': musicbrainz_group_release_id,
                'score': score
            })
            
            musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
            item.set_artwork(self.get_image_urls(media_type=media_type,
                                                 mbid=musicbrainz_artist_id, 
                                                 ambid=musicbrainz_group_release_id,                                                
                                                 icon='DefaultMusicSongs.png'))
            
            recordings.append(item)

        return localdb.merge_with_local(media_type=db_media_type,
                                        items=recordings,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
        
    def extended_recording_info(self, recording_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for recording with *recording_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_recording_info')
        if not recording_id:
            return None
        includes = []
        info = self.lookup_recording(mbid=recording_id,
                                     includes=includes,
                                     cache_days=cache_days)
        utils.log(info)
        if not info:
            utils.notify('Could not get song information')
            return {}
        media_type = 'recording'
        db_media_type = 'song'
        return None

    def get_recording_mbid(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_recording_mbid')
        db_media_type = 'song'
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mbid(db_media_type, dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
        
    def handle_tags(self, results):
        utils.log('MusicBrainz.handle_tags')
        listitems = ItemList()
        if results:
            for item in results:
                label = str(self.get_field(item.get('name'))).lower()
                if label.find(' / ') == -1:
                    listitem = AudioItem(label=label)
                    listitem.set_infos({'mediatype': 'genre'
                    })
                    listitem.set_properties({'mediatype_alt': 'genre',
                                             'count': item.get('count')
                    })
                    listitems.append(listitem)
        return listitems
        
    def handle_labels(self, results):
        utils.log('MusicBrainz.handle_labels')
        listitems = ItemList()
        return listitems
        
    def handle_images_ftv(self, results, itype='icon'):
        utils.log('MusicBrainz.handle_images_ftv')        
        images = ItemList(content_type='images')
        if results:
            for item in results:
                artwork = {}
                artwork['icon'] = item.get('url')
                artwork['poster'] = item.get('url')
                artwork['thumb'] = item.get('url')
                artwork['original'] = item.get('url')
                image = AudioItem(artwork=artwork)
                image.set_infos({'mediatype': 'music'
                })
                image.set_properties({'mediatype_alt': 'music',
                                      'type': itype,
                                      'id': item.get('id'),
                                      'likes': item.get('likes')
                })            
                images.append(image)
        return images
        
    def search_media(self, media_name=None, year='', media_type='artist', cache_days=1):
        '''
        return list of items with type *media_type for search with *media_name
        '''
        utils.log('MusicBrainz.search_media')
        return None
        
    def get_image_urls(self, media_type, mbid, ambid=None, icon=None, fanart=None):
        '''
        get a dict with all available images for given image types
        '''
        utils.log('MusicBrainz.get_image_urls')        
        images = {}        
        if icon:
            images['icon'] = icon
            images['thumb'] = icon
        if fanart:
            images['fanart'] = fanart
            
        if media_type == 'artist':
            images = ftv.get_music_images(mbid, images)
        elif media_type == 'releasegroup' or media_type == 'release':
            images = ftv.get_music_albums_images(mbid, ambid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(ambid, images)
        elif media_type == 'recording':
            images = ftv.get_music_albums_images(mbid, ambid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(ambid, images)

        images['thumb'] = images['icon']
        return images
            
    def search(self, search_str, media_type, page=1, sort=None, sort_order=None, cache_days=1):
        utils.log('MusicBrainz.search')
        self.sort = sort
        self.sort_order = sort_order
        offset = (page - 1) * MIN_LIMIT
        if media_type=='artist':
            response = self.search_artists(query=search_str, 
                                           offset=offset, 
                                           cache_days=cache_days)
        elif media_type=='releasegroup':
            response = self.search_release_groups(query=search_str, 
                                                  offset=offset, 
                                                  cache_days=cache_days)
        elif media_type=='release':
            response = self.search_releases(query=search_str, 
                                            offset=offset, 
                                            cache_days=cache_days)
        elif media_type=='recording':
            response = self.search_recordings(query=search_str, 
                                              offset=offset, 
                                              cache_days=cache_days)
        if response['count'] > 0:
            utils.log('items count %s' % response['count'])        
            if media_type == 'artist':
                itemlist = self.handle_artist(response['artists'])
            elif media_type == 'releasegroup':
                itemlist = self.handle_release_group(response['release-groups'])
            elif media_type == 'release':
                itemlist = self.handle_release(response['releases'])
            elif media_type == 'recording':
                itemlist = self.handle_recording(response['recordings'])
            itemlist.set_totals(response['count'])
            itemlist.set_total_pages(response['count'] // MIN_LIMIT + 1)
            utils.log('list items count %s' % len(itemlist))
            return itemlist
       
mb = MusicBrainz()
