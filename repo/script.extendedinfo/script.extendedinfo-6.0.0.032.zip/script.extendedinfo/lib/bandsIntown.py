# -*- coding: utf8 -*-

import urllib.parse

from lib.tools import ItemList
from lib.tools import VideoItem

from lib.tools import utils

API_KEY = 'xbmc_open_source_media_center'
BASE_URL = 'http://api.bandsintown.com/events/search?format=json&api_version=2.0&app_id=%s&' % API_KEY

class BandsInTown(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('BandsInTown.__init__')

    def handle_events(self, results):
        utils.log('BandsInTown.handle_events')
        events = ItemList()
        for event in results:
            venue = event['venue']
            item = VideoItem(label=venue['name'])
            item.set_properties({'date': event['datetime'].replace('T', ' - ').replace(':00', '', 1),
                                 'city': venue['city'],
                                 'lat': venue['latitude'],
                                 'lon': venue['longitude'],
                                 'id': venue['id'],
                                 'url': venue['url'],
                                 'region': venue['region'],
                                 'country': venue['country'],
                                 'artists': ' / '.join([art for art in event['artists']])
            })
            events.append(item)
        return events

    def get_near_events(self, artists):  # not possible with api 2.0
        utils.log('BandsInTown.get_near_events')
        arts = [urllib.parse.quote(art['artist']) for art in artists[:50]]
        artist_str = 'artists[]=' + '&artists[]='.join(arts)
        url = BASE_URL + 'location=use_geoip&radius=50&per_page=100&%s' % (artist_str)
        results = utils.get_JSON_response(url, folder='BandsInTown')
        if results:
            return self.handle_events(results)
        return []
        
bandsintown = BandsInTown()