# -*- coding: utf8 -*-

from lib.tools import utils

URL_BASE = 'http://coverartarchive.org/'

class CoverArtArchive(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('CoverArtArchive.__init__')

    def get_data(self, mbid, imageid=None, size=None, entitytype='release', cache_days=1):
        utils.log('CoverArtArchive.get_data')       
        if mbid:
            path = [entitytype, mbid]
        else:
            path = [entitytype, '1']
            
        if imageid and size:
            path.append("%s-%s" % (imageid, size))
        elif imageid:
            path.append(imageid)
            
        url = '%s%s' % (URL_BASE, '/'.join(path))
        utils.log(url)       
        return utils.get_JSON_response(url=url, 
                                       cache_days=cache_days, 
                                       folder='CoverArtArchive')
                                       
    def get_image(self, mbid, imageid, size=None, entitytype='release'):
        utils.log('CoverArtArchive.get_image')        
        if isinstance(imageid, int):
            imageid = '%d' % (imageid)
        if isinstance(size, int):
            size = '%d' % (size)
        return self.get_data(mbid=mbid, 
                             imageid=imageid, 
                             size=size, 
                             entitytype=entitytype)
                             
    def get_image_front(self, releaseid, size=None):
        utils.log('CoverArtArchive.get_image_front')        
        return self.get_image(mbid=releaseid, 
                              imageid='front', 
                              size=size)
        
    def get_image_back(self, releaseid, size=None):
        utils.log('CoverArtArchive.get_image_back')        
        return self.get_image(mbid=releaseid, 
                              imageid='back', 
                              size=size)
                              
    def get_release_group_image_front(self, releasegroupid, size=None):
        utils.log('CoverArtArchive.get_release_group_image_front')
        return self.get_image(mbid=releasegroupid, 
                              imageid='front', 
                              size=size, 
                              entitytype='release-group')
                              
    def get_release_group_image_back(self, releasegroupid, size=None):
        utils.log('CoverArtArchive.get_release_group_image_back')
        return self.get_image(mbid=releasegroupid, 
                              imageid='back', 
                              size=size, 
                              entitytype='release-group')
        
    def get_images(self, response, images):
        utils.log('CoverArtArchive.get_images')       
        if response:
            if response.get('images'):
                for img in response.get('images'):
                    if img.get('front') == True:
                        if img.get('thumbnails'):
                            if img.get('thumbnails').get('large'):
                                images['thumb'] = img.get('thumbnails').get('large')
                                break
                            if img.get('thumbnails').get('500'):
                                images['thumb'] = img.get('thumbnails').get('500')
                                break
                            if img.get('thumbnails').get('small'):
                                images['thumb'] = img.get('thumbnails').get('small')
                                break
                            if img.get('thumbnails').get('250'):
                                images['thumb'] = img.get('thumbnails').get('250')
                                break
        
        return images

    def get_image_list(self, releaseid, images):
        utils.log('CoverArtArchive.get_image_list')
        response = self.get_data(mbid=releaseid)       
        return self.get_images(response=response, 
                               images=images)

    def get_release_group_image_list(self, releasegroupid, images):
        utils.log('CoverArtArchive.get_release_group_image_list')        
        response = self.get_data(mbid=releasegroupid, 
                                 entitytype='release-group')
        return self.get_images(response=response, 
                               images=images)
               
caa = CoverArtArchive()