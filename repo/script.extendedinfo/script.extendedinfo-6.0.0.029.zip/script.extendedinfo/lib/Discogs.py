# -*- coding: utf8 -*-

import re
import json
from urllib.parse import urlunparse, urlencode

import xbmcgui

from lib import FanartTV
from lib import CoverArtArchive

from lib.tools import addon
from lib.tools import utils
from lib.tools import AudioItem
from lib.tools import ItemList
from lib.tools import localdb

BASE_HOSTNAME = 'https://api.discogs.com/'

class Discogs(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('Discogs.__init__')
        
discogs = Discogs()