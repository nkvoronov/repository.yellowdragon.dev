# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import unicode_literals

import xbmc
import xbmcgui

from lib.youtube import youtube
from lib.windowmanager import wm

from lib.tools import addon
from lib.tools import utils
from lib.tools import kodijson
from lib.tools import selectdialog
from lib.tools import slideshow
from lib.tools import AudioItem
from lib.tools import ActionHandler
from lib.tools import windows

chm = ActionHandler(type='music')
chv = ActionHandler(type='video')

ID_LIST_YOUTUBE = 350
ID_LIST_IMAGES = 1250
ID_BUTTON_BOUNCEUP = 20000
ID_BUTTON_BOUNCEDOWN = 20001

class DialogMusicInfo(windows.DialogXML):

    ACTION_PREVIOUS_MENU = [92, 9]
    ACTION_EXIT_SCRIPT = [13, 10]

    def __init__(self, *args, **kwargs):
        utils.log('DialogMusicInfo.__init__')
        super(DialogMusicInfo, self).__init__(*args, **kwargs)
        self.bouncing = False
        self.last_focus = None
        self.lists = None
        self.states = False
        self.yt_listitems = []
        self.info = AudioItem()
        self.last_control = None
        self.last_position = None

    def onInit(self, *args, **kwargs):
        utils.log('DialogMusicInfo.onInit')
        super(DialogMusicInfo, self).onInit()
        self.info.to_windowprops(window_id=self.window_id)
        for container_id, key in self.LISTS:
            try:
                self.getControl(container_id).reset()
                items = [i.get_listitem() for i in self.lists[key]]
                self.getControl(container_id).addItems(items)
            except Exception:
                utils.log('Notice: No container with id %i available' % container_id)
        if self.last_control:
            self.setFocusId(self.last_control)
        if self.last_control and self.last_position:
            try:
                self.getControl(self.last_control).selectItem(self.last_position)
            except Exception:
                pass
        addon.set_global('ImageColor', self.info.get_property('ImageColor'))
        addon.set_global('infobackground', self.info.get_art('fanart'))
        self.setProperty('type', self.TYPE)

    def onAction(self, action):
        utils.log('DialogMusicInfo.onAction')
        chm.serve_action(action, self.getFocusId(), self)
        chv.serve_action(action, self.getFocusId(), self)

    def onClick(self, control_id):
        utils.log('DialogMusicInfo.onClick')
        super(DialogMusicInfo, self).onClick(control_id)
        chm.serve(control_id, self)
        chv.serve(control_id, self)

    def onFocus(self, control_id):
        utils.log('DialogMusicInfo.onFocus')
        if control_id == ID_BUTTON_BOUNCEUP:
            if not self.bouncing:
                self.bounce('up')
            self.setFocusId(self.last_focus)
        elif control_id == ID_BUTTON_BOUNCEDOWN:
            if not self.bouncing:
                self.bounce('down')
            self.setFocusId(self.last_focus)
        self.last_focus = control_id

    def close(self):
        utils.log('DialogMusicInfo.close')
        try:
            self.last_position = self.getFocus().getSelectedPosition()
        except Exception:
            self.last_position = None
        addon.set_global('infobackground', '')
        self.last_control = self.getFocusId()
        super(DialogMusicInfo, self).close()
        
    @chv.click_by_type('video')
    def play_youtube_video(self, control_id):
        utils.log('DialogMusicInfo.play_youtube_video')
        wm.play_youtube_video(youtube_id=self.FocusedItem(control_id).getProperty('youtube_id'),
                              listitem=self.FocusedItem(control_id))

    @utils.run_async
    def bounce(self, identifier):
        utils.log('DialogMusicInfo.bounce')
        self.bouncing = True
        self.setProperty('Bounce.%s' % identifier, 'true')
        xbmc.sleep(200)
        self.clearProperty('Bounce.%s' % identifier)
        self.bouncing = False

    @chm.click_by_type('music')
    # hack: use 'music' until 'pictures' got added to core
    def open_image(self, control_id):
        utils.log('DialogMusicInfo.open_image')
        key = [key for container_id, key in self.LISTS if container_id == control_id][0]
        pos = slideshow.open(listitems=self.lists[key],
                             index=self.getControl(control_id).getSelectedPosition())
        self.getControl(control_id).selectItem(pos)
        
    @chm.action('parentdir', '*')
    @chm.action('parentfolder', '*')
    def previous_menu(self, control_id):
        utils.log('DialogMusicInfo.previous_menu')
        onback = self.getProperty('%i_onback' % control_id)
        if onback:
            xbmc.executebuiltin(onback)
        else:
            self.close()

    @chm.action('previousmenu', '*')
    def exit_script(self, control_id):
        utils.log('DialogMusicInfo.exit_script')
        self.exit()

    @utils.run_async
    def get_youtube_vids(self, search_str):
        utils.log('DialogMusicInfo.get_youtube_vids')
        utils.log(search_str)
        try:
            youtube_list = self.getControl(ID_LIST_YOUTUBE)
        except Exception:
            return None
        if not self.yt_listitems:
            self.yt_listitems = youtube.search(search_str, limit=15)
        if not self.yt_listitems:
            return None
        vid_ids = [item.get_property('key') for item in self.lists['videos']] if 'videos' in self.lists else []
        youtube_list.reset()
        youtube_list.addItems([i.get_listitem() for i in self.yt_listitems if i.get_property('youtube_id') not in vid_ids])

    @chm.click_by_type('artist')
    def open_artist_info(self, control_id):
        utils.log('DialogMusicInfo.open_artist_info')
        wm.open_actor_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainzartistid'),
                           dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())

    @chm.click_by_type('album')
    def open_album_info(self, control_id):
        utils.log('DialogMusicInfo.open_album_info')
        wm.open_album_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainzreleasegroupid'),
                           dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())

    @chm.click_by_type('song')
    def open_song_info(self, control_id):
        utils.log('DialogMusicInfo.open_song_info')
        wm.open_song_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainztrackid'),
                          dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())
                             
    @chv.context('video')
    def video_context_menu(self, control_id):
        utils.log('DialogMusicInfo.video_context_menu')
        index = xbmcgui.Dialog().contextmenu(list=[addon.LANG(33003)])
        if index == 0:
            utils.download_video(self.FocusedItem(control_id).getProperty('youtube_id'))

    @chm.context('music')
    def thumbnail_options(self, control_id):
        utils.log('DialogMusicInfo.thumbnail_options')
        listitem = self.FocusedItem(control_id)
        art_type = listitem.getProperty('type')
        options = []
        if self.info.get_info('dbid') and art_type == 'icon':
            options.append(('db_art', addon.LANG(32006)))
        if self.info.get_info('dbid') and art_type == 'fanart':
            options.append(('db_art', addon.LANG(32007)))
        if not options:
            return None
        action = utils.contextmenu(options=options)
        if action == 'db_art':
            kodijson.set_art(media_type=self.getProperty('type'),
                             art={art_type: listitem.get_art('original')},
                             dbid=self.info.get_info('dbid'))