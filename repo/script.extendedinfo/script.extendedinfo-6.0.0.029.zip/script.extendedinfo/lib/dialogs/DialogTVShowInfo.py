# -*- coding: utf8 -*-

import xbmc
import xbmcgui

from lib.themoviedb import tmdb
from lib.windowmanager import wm
from lib.dialogs import DialogVideoInfo

from lib.tools import imagetools
from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

ID_LIST_SIMILAR = 150
ID_LIST_SEASONS = 250
ID_LIST_NETWORKS = 1450
ID_LIST_STUDIOS = 550
ID_LIST_CERTS = 650
ID_LIST_CREW = 750
ID_LIST_GENRES = 850
ID_LIST_KEYWORDS = 950
ID_LIST_ACTORS = 1000
ID_LIST_VIDEOS = 1150
ID_LIST_IMAGES = 1250
ID_LIST_BACKDROPS = 1350

ID_BUTTON_BROWSE = 120
ID_BUTTON_OPENLIST = 6002
ID_BUTTON_RATED = 6006

chv = ActionHandler(type='video')

class DialogTVShowInfo(DialogVideoInfo):

    TYPE = 'TVShow'

    TYPE_ALT = 'tvshow'

    LISTS = [(ID_LIST_SIMILAR, 'similar'),
             (ID_LIST_SEASONS, 'seasons'),
             (ID_LIST_NETWORKS, 'networks'),
             (ID_LIST_STUDIOS, 'studios'),
             (ID_LIST_CERTS, 'certifications'),
             (ID_LIST_CREW, 'crew'),
             (ID_LIST_GENRES, 'genres'),
             (ID_LIST_KEYWORDS, 'keywords'),
             (ID_LIST_ACTORS, 'actors'),
             (ID_LIST_VIDEOS, 'videos'),
             (ID_LIST_IMAGES, 'images'),
             (ID_LIST_BACKDROPS, 'backdrops')
    ]

    def __init__(self, *args, **kwargs):
        utils.log('DialogTVShowInfo.__init__')
        super(DialogTVShowInfo, self).__init__(*args, **kwargs)
        data = tmdb.extended_tvshow_info(tvshow_id=kwargs.get('tmdb_id'),
                                         dbid=kwargs.get('dbid'))
        if not data:
            return None
        self.info, self.lists, self.states = data
        if not self.info.get_info('dbid'):
            self.info.set_art('poster', utils.get_file(self.info.get_art('poster')))
        self.info.update_properties(imagetools.blur(self.info.get_art('poster')))

    def onInit(self):
        utils.log('DialogTVShowInfo.onInit')
        self.get_youtube_vids('%s tv' % (self.info.get_info('title')))
        super(DialogTVShowInfo, self).onInit()
        super(DialogTVShowInfo, self).update_states()

    def onClick(self, control_id):
        utils.log('DialogTVShowInfo.onClick')
        super(DialogTVShowInfo, self).onClick(control_id)
        chv.serve(control_id, self)

    def set_buttons(self):
        utils.log('DialogTVShowInfo.set_buttons')
        self.set_visible(ID_BUTTON_BROWSE, self.get_info('dbid'))
        self.set_visible(ID_BUTTON_OPENLIST, self.logged_in)
        self.set_visible(ID_BUTTON_RATED, True)

    @chv.click(ID_BUTTON_BROWSE)
    def browse_tvshow(self, control_id):
        utils.log('DialogTVShowInfo.browse_tvshow')
        self.exit()
        xbmc.executebuiltin('Dialog.Close(all)')
        xbmc.executebuiltin('ActivateWindow(videos,videodb://tvshows/titles/%s/)' % self.info.get_info('dbid'))

    @chv.click(ID_LIST_SEASONS)
    def open_season_dialog(self, control_id):
        utils.log('DialogTVShowInfo.open_season_dialog')
        info = self.FocusedItem(control_id).getVideoInfoTag()
        wm.open_season_info(tvshow_id=self.info.get_property('id'),
                            season=info.getSeason(),
                            tvshow=self.info.get_info('title'))

    @chv.click(ID_LIST_STUDIOS)
    def open_company_info(self, control_id):
        utils.log('DialogTVShowInfo.open_company_info')
        filters = [{'id': self.FocusedItem(control_id).getProperty('id'),
                    'type': 'with_companies',
                    'label': self.FocusedItem(control_id).getLabel()}
        ]
        wm.open_tmdb_list(filters=filters)

    @chv.click(ID_LIST_KEYWORDS)
    def open_keyword_info(self, control_id):
        utils.log('DialogTVShowInfo.open_keyword_info')
        filters = [{'id': self.FocusedItem(control_id).getProperty('id'),
                    'type': 'with_keywords',
                    'label': self.FocusedItem(control_id).getLabel()}
        ]
        wm.open_tmdb_list(filters=filters)

    @chv.click(ID_LIST_GENRES)
    def open_genre_info(self, control_id):
        utils.log('DialogTVShowInfo.open_genre_info')
        filters = [{'id': self.FocusedItem(control_id).getProperty('id'),
                    'type': 'with_genres',
                    'label': self.FocusedItem(control_id).getLabel()}
        ]
        wm.open_tmdb_list(filters=filters,
                          media_type='tvshow')

    @chv.click(ID_LIST_NETWORKS)
    def open_network_info(self, control_id):
        utils.log('DialogTVShowInfo.open_network_info')
        filters = [{'id': self.FocusedItem(control_id).getProperty('id'),
                    'type': 'with_networks',
                    'label': self.FocusedItem(control_id).getLabel()}
        ]
        wm.open_tmdb_list(filters=filters,
                          media_type='tvshow')

    def get_manage_options(self):
        utils.log('DialogTVShowInfo.get_manage_options')
        options = []
        dbid = self.info.get_info('dbid')
        tvdb_id = self.info.get_property('tvdb_id')
        if dbid:
            call = 'RunScript(script.artwork.downloader,mediatype=tvshow,dbid={}%s)'.format(dbid)
            options += [(addon.LANG(413), call % (',mode=gui')),
                        (addon.LANG(14061), call % ('')),
                        (addon.LANG(32101), call % (',mode=custom,extrathumbs')),
                        (addon.LANG(32100), call % (',mode=custom'))]
        else:
            options += [(addon.LANG(32166), 'RunPlugin(plugin://plugin.video.sickrage?action=addshow&show_id=%s)' % tvdb_id)]
        options.append((addon.LANG(1049), 'Addon.OpenSettings(script.extendedinfo)'))
        return options

    @chv.click(ID_BUTTON_OPENLIST)
    def open_list(self, control_id):
        utils.log('DialogTVShowInfo.open_list')
        index = xbmcgui.Dialog().select(heading=addon.LANG(32136),
                                        list=[addon.LANG(32144), addon.LANG(32145)])
        if index == 0:
            wm.open_tmdb_list(media_type='tvshow',
                              mode='favorites')
        elif index == 1:
            wm.open_tmdb_list(mode='rating',
                              media_type='tvshow')

    @chv.click(ID_BUTTON_RATED)
    def open_rated_items(self, control_id):
        utils.log('DialogTVShowInfo.open_rated_items')
        wm.open_tmdb_list(mode='rating',
                          media_type='tvshow')

    def update_states(self):
        utils.log('DialogTVShowInfo.update_states')
        xbmc.sleep(2000)  # delay because MovieDB takes some time to update
        info = tmdb.get_tvshow(tvshow_id=self.info.get_property('id'),
                                          cache_days=0)
        self.states = info.get('account_states')
        super(DialogTVShowInfo, self).update_states()