# -*- coding: utf8 -*-

import xbmcgui
import xbmc

from lib.themoviedb import tmdb
from lib.dialogs import DialogBaseInfo

from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

BUTTONS = {8, 9, 10, 6001, 6002, 6003, 6005, 6006}

ID_BUTTON_PLOT = 132
ID_BUTTON_MANAGE = 445
ID_BUTTON_SETRATING = 6001
ID_BUTTON_FAV = 6003

ch = ActionHandler(type='music')

class DialogMusicInfo(DialogBaseInfo):

    def __init__(self, *args, **kwargs):
        utils.log('DialogMusicInfo.__init__')
        super(DialogMusicInfo, self).__init__(*args, **kwargs)

    def onClick(self, control_id):
        utils.log('DialogMusicInfo.onClick')
        super(DialogMusicInfo, self).onClick(control_id)
        ch.serve(control_id, self)

    def set_buttons(self):
        utils.log('DialogMusicInfo.set_buttons')
        for button_id in BUTTONS:
            self.set_visible(button_id, False)

    @ch.click(ID_BUTTON_PLOT)
    def show_plot(self, control_id):
        utils.log('DialogMusicInfo.show_plot')
        xbmcgui.Dialog().textviewer(heading=addon.LANG(32037),
                                    text=self.info.get_info('plot'))

    def get_manage_options(self):
        utils.log('DialogMusicInfo.get_manage_options')
        return []

    def get_identifier(self):
        utils.log('DialogMusicInfo.get_identifier')
        return self.info.get_property('id')

    @ch.click(ID_BUTTON_MANAGE)
    def show_manage_dialog(self, control_id):
        utils.log('DialogMusicInfo.show_manage_dialog')
        options = self.get_manage_options()
        index = xbmcgui.Dialog().select(heading=addon.LANG(32133),
                                        list=[i[0] for i in options])
        if index == -1:
            return None
        for item in options[index][1].split('||'):
            xbmc.executebuiltin(item)

    @ch.click(ID_BUTTON_FAV)
    def change_list_status(self, control_id):
        utils.log('DialogMusicInfo.change_list_status')
        tmdb.change_fav_status(media_id=self.info.get_property('id'),
                               media_type=self.TYPE_ALT,
                               status=str(not bool(self.states['favorite'])).lower())
        self.update_states()

    @ch.click(ID_BUTTON_SETRATING)
    def set_rating_dialog(self, control_id):
        utils.log('DialogMusicInfo.set_rating_dialog')
        preselect = int(self.states['rated']['value']) if (self.states and self.states.get('rated')) else -1
        rating = utils.input_userrating(preselect=preselect)
        if rating == -1:
            return None
        if tmdb.set_rating(media_type=self.TYPE_ALT,
                           media_id=self.get_identifier(),
                           rating=rating,
                           dbid=self.info.get_info('dbid')):
            self.setProperty('rated', str(rating) if rating > 0 else '')
            self.update_states()