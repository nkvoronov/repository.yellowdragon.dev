# -*- coding: utf8 -*-

from .dialogbasevideolist import DialogBaseVideoList
from .dialogthemoviedblist import DialogTheMovieDBList
from .dialogyoutubelist import DialogYoutubeList

from .dialogbasemusiclist import DialogBaseMusicList
from .dialogmusicbrainzlist import DialogMusicBrainzList

from .dialogbaseinfo import DialogBaseInfo
from .dialogvideoinfo import DialogVideoInfo
from .dialogmovieinfo import DialogMovieInfo
from .dialogactorinfo import DialogActorInfo
from .dialogtvshowinfo import DialogTVShowInfo
from .dialogepisodeinfo import DialogEpisodeInfo
from .dialogseasoninfo import DialogSeasonInfo

from .dialogmusicinfo import DialogMusicInfo
from .dialogartistinfo import DialogArtistInfo
from .dialogreleasegroupinfo import DialogReleaseGroupInfo
from .dialogreleaseinfo import DialogReleaseInfo
from .dialogrecordinginfo import DialogRecordingInfo




