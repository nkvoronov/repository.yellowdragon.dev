# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import unicode_literals

import xbmcgui

from lib.musicbrainz import mb
from lib.dialogs import DialogMusicInfo

from lib.tools import imagetools
from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

ID_CONTROL_PLOT = 132
ID_LIST_RELEASE = 160
ID_LIST_GENRES = 190
ID_LIST_LABELS = 191
ID_LIST_IMAGES = 210

chm = ActionHandler(type='alt')

class DialogReleaseInfo(DialogMusicInfo):

    TYPE = 'Album'
    
    TYPE_ALT = 'release'

    LISTS = [(ID_LIST_RELEASE, 'recording'),
             (ID_LIST_GENRES, 'genres'),
             (ID_LIST_LABELS, 'labels'),
             (ID_LIST_IMAGES, 'coverarts')
    ]
    
    def __init__(self, *args, **kwargs):
        utils.log('DialogReleaseInfo.__init__')
        super(DialogReleaseInfo, self).__init__(*args, **kwargs)
        data = mb.extended_release_info(release_id=kwargs.get('id'),
                                        dbid=kwargs.get('dbid'))
        if not data:
            return None
        self.info, self.lists = data

    def onInit(self):
        utils.log('DialogReleaseInfo.onInit')
        self.get_youtube_vids(self.info.get_property('youtube_search'))
        super(DialogReleaseInfo, self).onInit()

    def onClick(self, control_id):
        utils.log('DialogReleaseInfo.onClick')
        super(DialogReleaseInfo, self).onClick(control_id)
        chm.serve(control_id, self)
        
    @chm.click(ID_CONTROL_PLOT)
    def show_plot(self, control_id):
        utils.log('DialogReleaseInfo.show_plot')
        xbmcgui.Dialog().textviewer(heading=addon.LANG(32037),
                                    text=self.info.get_property('description'))