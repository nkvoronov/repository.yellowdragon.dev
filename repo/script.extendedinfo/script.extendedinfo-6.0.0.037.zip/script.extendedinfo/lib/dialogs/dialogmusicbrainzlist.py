# -*- coding: utf8 -*-

import xbmc
import xbmcgui

from lib.musicbrainz import mb
from lib.windowmanager import wm
from lib.dialogs import DialogBaseMusicList

from lib.tools import addon
from lib.tools import utils
from lib.tools import busy
from lib.tools import windows
from lib.tools import confirmdialog
from lib.tools import selectdialog
from lib.tools import ActionHandler

ID_BUTTON_SEARCH = 6100
ID_BUTTON_SORT = 5001
ID_BUTTON_GENREFILTER = 5002
ID_BUTTON_YEARFILTER = 5003
ID_BUTTON_ORDER = 5004

chm = ActionHandler(type='alt')

class DialogMusicBrainzList(DialogBaseMusicList, windows.DialogXML):

    TYPES = ['artist', 'releasegroup', 'release', 'recording']

    FILTERS = {}

    TRANSLATIONS = {'artist': addon.LANG(32174),
                    'releasegroup': addon.LANG(32175),
                    'release': addon.LANG(32211),
                    'recording': addon.LANG(32176)
    }

    SORTS = {'artist': {'score': addon.LANG(32178),
                        'genre': addon.LANG(135),
                        'artist_type': addon.LANG(564)},
             'releasegroup': {'score': addon.LANG(32178),
                              'genre': addon.LANG(135),
                              'album_type': addon.LANG(564),
                              'year': addon.LANG(562)}, 
             'release': {'score': addon.LANG(32178),
                         'genre': addon.LANG(135),
                         'album_type': addon.LANG(564),
                         'year': addon.LANG(562)},
             'recording': {'score': addon.LANG(32178),
                           'genre': addon.LANG(135),
                           'year': addon.LANG(562)}
    }

    LABEL2 = {'score': lambda x: x.get_property('score'),
              'genre': lambda x: x.get_info('genre'),
              'year': lambda x: x.get_info('year'),
              'artist_type': lambda x: x.get_property('artist_type'),
              'album_type': lambda x: x.get_property('album_type')
              
    }

    @busy.set_busy
    def __init__(self, *args, **kwargs):
        utils.log('DialogMusicBrainzList.__init__')
        self.type = kwargs.get('type', '')
        self.list_id = kwargs.get('list_id', False)
        super(DialogMusicBrainzList, self).__init__(*args, **kwargs)

    def onClick(self, control_id):
        utils.log('DialogMusicBrainzList.onClick')
        super(DialogMusicBrainzList, self).onClick(control_id)
        chm.serve(control_id, self)


    def onAction(self, action):
        utils.log('DialogMusicBrainzList.onAction')
        super(DialogMusicBrainzList, self).onAction(action)
        chm.serve_action(action, self.getFocusId(), self)                

    def update_ui(self):
        utils.log('DialogMusicBrainzList.update_ui')
        super(DialogMusicBrainzList, self).update_ui()
        
    @chm.click(ID_BUTTON_SEARCH)
    def open_search(self, control_id):
        utils.log('DialogMusicBrainzList.update_ui')
        super(DialogMusicBrainzList, self).open_search(control_id)

    @property
    def sort_key(self):
        utils.log('DialogMusicBrainzList.sort_key')
        return self.type

    @property
    def default_sort(self):
        utils.log('DialogMusicBrainzList.default_sort')
        return 'score'

    @chm.click(ID_BUTTON_SORT)
    def get_sort_type(self, control_id):
        utils.log('DialogMusicBrainzList.get_sort_type')
        if not self.choose_sort_method(self.sort_key):
            return None
        self.update()

    def add_filter(self, **kwargs):
        utils.log('DialogMusicBrainzList.add_filter')
        key = kwargs['key'].replace('.gte', '').replace('.lte', '')
        kwargs['typelabel'] = self.FILTERS[key]
        if kwargs['key'].endswith('.lte'):
            kwargs['label'] = '< %s' % kwargs['label']
        if kwargs['key'].endswith('.gte'):
            kwargs['label'] = '> %s' % kwargs['label']
        super(DialogMusicBrainzList, self).add_filter(force_overwrite=kwargs['key'].endswith(('.gte', '.lte')), **kwargs)

    @chm.click(ID_BUTTON_ORDER)
    def toggle_order(self, control_id):
        utils.log('DialogMusicBrainzList.toggle_order')
        self.order = 'desc' if self.order == 'asc' else 'asc'
        self.update()

    @chm.info('artist')
    @chm.click_by_type('artist')
    def open_artist(self, control_id):
        utils.log('DialogMusicBrainzList.open_artist')
        wm.open_artist_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainzartistid'),
                            dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())

    @chm.info('releasegroup')
    @chm.click_by_type('releasegroup')
    def open_release_group(self, control_id):
        utils.log('DialogMusicBrainzList.open_release_group')
        wm.open_release_group_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainzreleasegroupid'),
                                   dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())

    @chm.info('release')
    @chm.click_by_type('release')
    def open_release(self, control_id):
        utils.log('DialogMusicBrainzList.open_release')
        wm.open_release_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainzreleaseid'),
                             dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())
                            
    @chm.info('recording')
    @chm.click_by_type('recording')
    def open_recording(self, control_id):
        utils.log('DialogMusicBrainzList.open_recording')
        wm.open_recording_info(mbid=self.FocusedItem(control_id).getProperty('musicbrainztrackid'),
                               rmbid=self.FocusedItem(control_id).getProperty('musicbrainzreleaseid'),
                               dbid=self.FocusedItem(control_id).getMusicInfoTag().getDbId())

    def fetch_data(self, force=False):
        utils.log('DialogMusicBrainzList.fetch_data')
        utils.log('TYPE : %s' % self.type)
        utils.log('MODE : %s' % self.mode)
        utils.log('SORT : %s' % self.sort)
        utils.log('ORDER : %s' % self.order)
        if self.mode == 'search':
            self.filter_label = addon.LANG(32146) % self.search_str if self.search_str else ''
            return mb.search(search_str=self.search_str,
                             media_type=self.type,
                             page=self.page,
                             sort=self.sort, 
                             sort_order=self.order,
                             cache_days=0 if force else 2)