# -*- coding: utf8 -*-

import re
import json
from urllib.parse import urlunparse, urlencode

import xbmcgui

from .fanarttv import ftv
from .coverartarchive import caa

from lib.tools import addon
from lib.tools import utils
from lib.tools import AudioItem
from lib.tools import ItemList
from lib.tools import localdb

BASE_HOSTNAME = 'musicbrainz.org'
BASE_FMT = 'json'
LUCENE_SPECIAL = r'([+\-&|!(){}\[\]\^"~*?:\\\/])'
RELATABLE_TYPES = ['area', 'artist', 'label', 'place', 'event', 'recording', 'release', 'release-group', 'series', 'url', 'work', 'instrument']
RELATION_INCLUDES = [entity + '-rels' for entity in RELATABLE_TYPES]
TAG_INCLUDES = ['tags', 'user-tags']
RATING_INCLUDES = ['ratings', 'user-ratings']
PLUGIN_BASE = 'plugin://script.extendedinfo/?info='
MAX_LIMIT = 25 #100

VALID_INCLUDES = {
    'area' : ['aliases', 'annotation'] + RELATION_INCLUDES,
    'artist': [
        'recordings', 'releases', 'release-groups', 'works', # Subqueries
        'various-artists', 'discids', 'media', 'isrcs',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'annotation': [

    ],
    'instrument': ['aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES,
    'label': [
        'releases', # Subqueries
        'discids', 'media',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'place' : ['aliases', 'annotation'] + RELATION_INCLUDES + TAG_INCLUDES,
    'event' : ['aliases'] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'recording': [
        'artists', 'releases', # Subqueries
        'discids', 'media', 'artist-credits', 'isrcs',
        'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': [
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': [
        'artists', 'releases', 'discids', 'media',
        'artist-credits', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'series': [
        'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'work': [
        'artists', # Subqueries
        'aliases', 'annotation'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'discid': [ # Discid should be the same as release
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'isrc': ['artists', 'releases', 'puids', 'isrcs'],
    'iswc': ['artists'],
    'collection': ['releases'],
}

VALID_BROWSE_INCLUDES = {
    'artist': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'event': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'label': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'recording': ['artist-credits', 'isrcs'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': ['artist-credits', 'labels', 'recordings', 'isrcs',
                'release-groups', 'media', 'discids'] + RELATION_INCLUDES,
    'place': ['aliases'] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': ['artist-credits'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'work': ['aliases', 'annotation'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
}

#: These can be used to filter whenever releases are includes or browsed
VALID_RELEASE_TYPES = [
    'nat',
    'album', 'single', 'ep', 'broadcast', 'other', # primary types
    'compilation', 'soundtrack', 'spokenword', 'interview', 'audiobook',
    'live', 'remix', 'dj-mix', 'mixtape/street', # secondary types
]
#: These can be used to filter whenever releases or release-groups are involved
VALID_RELEASE_STATUSES = ['official', 'promotion', 'bootleg', 'pseudo-release']

VALID_SEARCH_FIELDS = {
    'annotation': [
        'entity', 'name', 'text', 'type'
    ],
    'area': [
        'aid', 'area', 'alias', 'begin', 'comment', 'end', 'ended',
        'iso', 'iso1', 'iso2', 'iso3', 'type'
    ],
    'artist': [
        'arid', 'artist', 'artistaccent', 'alias', 'begin', 'comment',
        'country', 'end', 'ended', 'gender', 'ipi', 'sortname', 'tag', 'type',
        'area', 'beginarea', 'endarea'
    ],
    'label': [
        'alias', 'begin', 'code', 'comment', 'country', 'end', 'ended',
        'ipi', 'label', 'labelaccent', 'laid', 'sortname', 'type', 'tag',
        'area'
    ],
    'recording': [
        'arid', 'artist', 'artistname', 'creditname', 'comment',
        'country', 'date', 'dur', 'format', 'isrc', 'number',
        'position', 'primarytype', 'puid', 'qdur', 'recording',
        'recordingaccent', 'reid', 'release', 'rgid', 'rid',
        'secondarytype', 'status', 'tnum', 'tracks', 'tracksrelease',
        'tag', 'type', 'video'
    ],
    'release-group': [
        'arid', 'artist', 'artistname', 'comment', 'creditname',
        'primarytype', 'rgid', 'releasegroup', 'releasegroupaccent',
        'releases', 'release', 'reid', 'secondarytype', 'status',
        'tag', 'type'
    ],
    'release': [
        'arid', 'artist', 'artistname', 'asin', 'barcode', 'creditname',
        'catno', 'comment', 'country', 'creditname', 'date', 'discids',
        'discidsmedium', 'format', 'laid', 'label', 'lang', 'mediums',
        'primarytype', 'puid', 'quality', 'reid', 'release', 'releaseaccent',
        'rgid', 'script', 'secondarytype', 'status', 'tag', 'tracks',
        'tracksmedium', 'type'
    ],
    'series': [
        'alias', 'comment', 'sid', 'series', 'type'
    ],
    'work': [
        'alias', 'arid', 'artist', 'comment', 'iswc', 'lang', 'tag',
        'type', 'wid', 'work', 'workaccent'
    ],
}

basestring = (str,bytes)
mb_cache_days = 1

# https://musicbrainz.org/ws/2/artist?query=accept&fmt=json 
# https://musicbrainz.org/ws/2/release-group?query=accept&fmt=json
# https://musicbrainz.org/ws/2/recording?query=paranoid&fmt=json  

# Exceptions.

class MusicBrainzError(Exception):
    pass

class UsageError(MusicBrainzError):
    pass

class InvalidSearchFieldError(UsageError):
    pass

class InvalidIncludeError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidIncludeError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg

class InvalidFilterError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidFilterError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg
        
class MusicBrainz(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('MusicBrainz.__init__')
        self.sort=None
        self.sort_order=None
        
    def get_genre(self, data):
        utils.log('MusicBrainz.get_genre')
        text = None
        genres = []
        if data:        
            for genre in data:
                genres.append(genre.get('name').title())
            text = ' / '.join(genres)
        return text  
        
    def get_artists(self, data):
        utils.log('MusicBrainz.get_artists')
        text = None
        artists = []
        if data:        
            for artistcredit in data:
                artists.append(artistcredit.get('artist').get('name'))
            text = ', '.join(artists)
        return text

    def get_artists_id(self, data):
        utils.log('MusicBrainz.get_artists_id')
        artists = []
        if data:
            for artistcredit in data:
                artists.append(artistcredit.get('artist').get('id'))
        return artists
        
    def get_album(self, data):
        utils.log('MusicBrainz.get_album')
        text = None
        if data:
            text = data[0].get('title')
        return text
        
    def get_album_ids(self, data):
        utils.log('MusicBrainz.get_album_ids')
        id = None
        gid = None
        if data:
            id = data[0].get('id')
            if data[0].get('release-group'):
                gid = data[0].get('release-group').get('id')
        return id, gid
        
    def get_secondary_types(self, data):
        utils.log('MusicBrainz.get_secondary_types')
        text = None
        tps = []
        if data:       
            for item in data:
                tps.append(item) 
            text = ', '.join(tps)
            text = text.lower()
        return text
        
    def get_releases(self, data):
        utils.log('MusicBrainz.get_releases')
        text = None
        releases = []
        if data:
            for release in data:
                releases.append(release.get('id'))
            text = ', '.join(releases)
        return text
        
    def get_area(self, data):
        utils.log('MusicBrainz.get_area')
        text = None
        if data:
            text = data.get('name')
        return text

    def handle_artist(self, results, sort=True):
        utils.log('MusicBrainz.handle_artist')
        artists = ItemList(content_type='artist')
        path = 'extendedartistinfo&&id=%s'
        for artist in results:
            musicbrainzartistid = artist.get('id')
            title = artist.get('name')
            genre = self.get_genre(artist.get('tags'))
            country = self.get_area(artist.get('area'))
            if country == None:
                country = artist.get('country')
            description = ''
            
            item = AudioItem(label=title, path=PLUGIN_BASE + path % musicbrainzartistid)
            
            item.set_infos({
                'title': title,
                'genre': genre,
                'mediatype': 'artist'
            })
            
            item.set_properties({
                'musicbrainzartistid': musicbrainzartistid,
                'artist_born': artist.get('life-span').get('begin'),
                'artist_died': artist.get('life-span').get('end'),            
                'artist_description': description,
                'artist_disambiguation': artist.get('disambiguation'),
                'artist_type': artist.get('type'),
                'artist_sortname': artist.get('sort-name'),            
                'artist_ended': artist.get('life-span').get('ended'),            
                'musicbrainztypeid': artist.get('type-id'),                     
                'country': country,
                'score': artist.get('score')
            })
            
            item.set_artwork(self.get_image_urls(id=musicbrainzartistid, mediatype='artist', icon='DefaultMusicArtists.png'))
            
            artists.append(item)
            
        return localdb.merge_with_local(media_type='artist',
                                        items=artists,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
        
    def handle_album(self, results, sort=True):
        utils.log('MusicBrainz.handle_album')
        albums = ItemList(content_type='album')
        path = 'extendedalbuminfo&&id=%s'
        for album in results:
            musicbrainzreleaseid = album.get('id')
            title = album.get('title')
            genre = self.get_genre(album.get('tags'))
            artist = self.get_artists(album.get('artist-credit'))
            musicbrainzreleasesid = self.get_releases(album.get('releases'))
            musicbrainzartistsid = self.get_artists_id(album.get('artist-credit'))
            secondary_types = self.get_secondary_types(album.get('secondary-types'))
            description = ''
            label = title
            if artist:
                label = artist + ' - ' + title

            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainzreleaseid)
            
            item.set_infos({
                'title': title,
                'artist': artist,
                'genre': genre,
                'year': int(utils.get_year(album.get('first-release-date'))),
                'mediatype': 'album'
            })
            
            item.set_properties({
                'musicbrainzreleaseid': musicbrainzreleaseid,
                'musicbrainztypeid': album.get('type-id'),
                'musicbrainzartistsid': ', '.join(musicbrainzartistsid),
                'musicbrainzreleasesid':musicbrainzreleasesid,
                'album_description': description, 
                'album_type': album.get('primary-type').lower(),
                'album_type2': secondary_types,
                'album_count': album.get('count'),           
                'score': album.get('score')
            })
            
            item.set_artwork(self.get_image_urls(id=musicbrainzartistsid[0], aid=musicbrainzreleaseid, mediatype='album', icon='DefaultMusicAlbums.png'))
            
            albums.append(item)

        return localdb.merge_with_local(media_type='album',
                                        items=albums,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
        
    def handle_song(self, results, sort=True):
        utils.log('MusicBrainz.handle_song')
        songs = ItemList(content_type='song')
        path = 'extendedsonginfo&&id=%s'
        for song in results:
            musicbrainztrackid = song.get('id')
            title = song.get('title')
            genre = self.get_genre(song.get('tags'))
            artist = self.get_artists(song.get('artist-credit'))
            album = self.get_album(song.get('releases'))        
            musicbrainzartistsid = self.get_artists_id(song.get('artist-credit'))
            musicbrainzreleaseid,musicbrainzgroupreleaseid = self.get_album_ids(song.get('releases'))
            if song.get('length'):
                diration = song.get('length')
            else:
                diration = None            
            label = title
            if artist:
                label = artist + ' - ' + title
            
            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainztrackid)
            
            item.set_infos({
                'title': title,
                'duration': diration,
                'artist': artist,
                'album': album,
                'genre': genre,
                'year': int(utils.get_year(song.get('first-release-date'))),
                'mediatype': 'song'
            })
            
            item.set_properties({
                'musicbrainztrackid': musicbrainztrackid,
                'musicbrainzartistsid':  ', '.join(musicbrainzartistsid),
                'musicbrainzreleaseid': musicbrainzreleaseid,
                'musicbrainzgroupreleaseid': musicbrainzgroupreleaseid,
                'score': song.get('score')
            })
            
            item.set_artwork(self.get_image_urls(id=musicbrainzartistsid[0], aid=musicbrainzgroupreleaseid, mediatype='song', icon='DefaultMusicSongs.png'))
            
            songs.append(item)

        return localdb.merge_with_local(media_type='song',
                                        items=songs,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
                                        
    def extended_artist_info(self, artist_id):
        utils.log('MusicBrainz.extended_artist_info')
        return None
        
    def extended_album_info(self, album_id):
        utils.log('MusicBrainz.extended_album_info')
        return None
        
    def extended_song_info(self, song_id):
        utils.log('MusicBrainz.extended_song_info')
        return None
        
    def get_image_urls(self, id, mediatype, aid=None,icon=None, fanart=None):
        utils.log('MusicBrainz.get_image_urls')        
        images = {}        
        if icon:
            images['icon'] = icon
        if fanart:
            images['fanart'] = fanart        
        if mediatype == 'artist':
            images = ftv.get_music_images(id, images)
        elif mediatype == 'album':
            images = ftv.get_music_albums_images(id, aid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(aid, images)
        elif mediatype == 'song':
            images = ftv.get_music_albums_images(id, aid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(aid, images)
        return images
            
    def search(self, search_str, media_type, page=1, sort=None, sort_order=None, cache_days=1):
        utils.log('MusicBrainz.search')
        self.sort = sort
        self.sort_order = sort_order
        offset = (page - 1) * MAX_LIMIT
        mb_cache_days = cache_days
        if media_type=='artist':
            response = self.search_artists(query=search_str, offset=offset)
        elif media_type=='album':
            response = self.search_release_groups(query=search_str, offset=offset)
        elif media_type=='song':
            response = self.search_recordings(query=search_str, offset=offset)
        if response['count'] > 0:
            utils.log('items count %s' % response['count'])        
            if media_type == 'artist':
                itemlist = self.handle_artist(response['artists'])
            elif media_type == 'album':
                itemlist = self.handle_album(response['release-groups'])
            elif media_type == 'song':
                itemlist = self.handle_song(response['recordings'])
            itemlist.set_totals(response['count'])
            itemlist.set_total_pages(response['count'] // MAX_LIMIT + 1)
            utils.log('list items count %s' % len(itemlist))
            return itemlist

    # Helpers for validating and formatting allowed sets.

    def _check_includes_impl(self, includes, valid_includes):
        utils.log('MusicBrainz._check_includes_impl')
        for i in includes:
            if i not in valid_includes:
                raise InvalidIncludeError('Bad includes: '
                                          '%s is not a valid include' % i)
    def _check_includes(self, entity, inc):
        utils.log('MusicBrainz._check_includes')
        self._check_includes_impl(inc, VALID_INCLUDES[entity])

    def _check_filter(self, values, valid):
        utils.log('MusicBrainz._check_filter')
        for v in values:
            if v not in valid:
                raise InvalidFilterError(v)
                
    def _check_filter_and_make_params(self, entity, includes, release_status=[], release_type=[]):
        utils.log('MusicBrainz._check_filter_and_make_params')
        if isinstance(release_status, basestring):
            release_status = [release_status]
        if isinstance(release_type, basestring):
            release_type = [release_type]
        self._check_filter(release_status, VALID_RELEASE_STATUSES)
        self._check_filter(release_type, VALID_RELEASE_TYPES)

        if (release_status 
                and 'releases' not in includes and entity != 'release'):
            raise InvalidFilterError("Can't have a status with no release include")
        if (release_type
                and 'release-groups' not in includes and 'releases' not in includes
                and entity not in ['release-group', 'release']):
            raise InvalidFilterError("Can't have a release type "
                    "with no releases or release-groups involved")

        # Build parameters.
        params = {}
        if len(release_status):
            params['status'] = '|'.join(release_status)
        if len(release_type):
            params['type'] = '|'.join(release_type)
        return params

    def _mb_request(self, path, client_required=False, args=None, data=None, body=None):
        utils.log('MusicBrainz._mb_request')
        if args is None:
            args = {}
        else:
            args = dict(args) or {}

        args['fmt'] = BASE_FMT

        # Convert args from a dictionary to a list of tuples
        # so that the ordering of elements is stable for easy
        # testing (in this case we order alphabetically)
        # Encode Unicode arguments using UTF-8.
        newargs = []
        for key, value in sorted(args.items()):
            if isinstance(value, str):
                value = value.encode('utf8')
            newargs.append((key, value))

        # Construct the full URL for the request, including hostname and
        # query string.
        url = urlunparse((
            'http',
            BASE_HOSTNAME,
            '/ws/2/%s' % path,
            '',
            urlencode(newargs),
            ''
        ))
        utils.log('%s' % (url))
        
        return utils.get_JSON_response(url=url, cache_days=mb_cache_days, folder='MusicBrainz')

    def _do_mb_query(self, entity, id, includes=[], params={}):
        utils.log('MusicBrainz._do_mb_query')
        # Build arguments.
        if not isinstance(includes, list):
            includes = [includes]
        self._check_includes(entity, includes)
        args = dict(params)
        if len(includes) > 0:
            inc = ' '.join(includes)
            args['inc'] = inc

        # Build the endpoint components.
        path = '%s/%s' % (entity, id)

        return self._mb_request(path, args=args)
            
    def _do_mb_search(self, entity, query='', fields={}, limit=25, offset=0, strict=False):
        utils.log('MusicBrainz._do_mb_search')
        # Encode the query terms as a Lucene query string.
        query_parts = []
        if query:
            # clean_query = util._unicode(query)
            clean_query = query
            if fields:
                clean_query = re.sub(LUCENE_SPECIAL, r'\\\1',
                             clean_query)
                if strict:
                    query_parts.append('"%s"' % clean_query)
                else:
                    query_parts.append(clean_query.lower())
            else:
                query_parts.append(clean_query)
        for key, value in fields.items():
            # Ensure this is a valid search field.
            if key not in VALID_SEARCH_FIELDS[entity]:
                raise InvalidSearchFieldError(
                    '%s is not a valid search field for %s' % (key, entity)
                )
            elif key == 'puid':
                warn('PUID support was removed from server\n'
                     'the "puid" field is ignored',
                     Warning, stacklevel=2)

            # Escape Lucene's special characters.
            # value = util._unicode(value)
            value = re.sub(LUCENE_SPECIAL, r'\\\1', value)
            if value:
                if strict:
                    query_parts.append('%s:"%s"' % (key, value))
                else:
                    value = value.lower() # avoid AND / OR
                    query_parts.append('%s:(%s)' % (key, value))
        if strict:
            full_query = ' AND '.join(query_parts).strip()
        else:
            full_query = ' '.join(query_parts).strip()

        if not full_query:
            raise ValueError('at least one query term is required')

        # Additional parameters to the search.
        params = {'query': full_query}
        if limit:
            params['limit'] = str(limit)
        if offset:
            params['offset'] = str(offset)

        return self._do_mb_query(entity, '', [], params)
        
    # Single entity by ID

    def get_area_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_area_by_id')
        params = self._check_filter_and_make_params('area', includes, release_status, release_type)
        return self._do_mb_query('area', id, includes, params)

    def get_artist_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_artist_by_id')
        params = self._check_filter_and_make_params('artist', includes, release_status, release_type)
        return self._do_mb_query('artist', id, includes, params)

    def get_instrument_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_instrument_by_id')
        params = self._check_filter_and_make_params('instrument', includes, release_status, release_type)
        return self._do_mb_query('instrument', id, includes, params)

    def get_label_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_label_by_id')
        params = self._check_filter_and_make_params('label', includes, release_status, release_type)
        return self._do_mb_query('label', id, includes, params)

    def get_place_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_place_by_id')
        params = _check_filter_and_make_params('place', includes, release_status, release_type)
        return self._do_mb_query('place', id, includes, params)

    def get_event_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_event_by_id')
        params = self._check_filter_and_make_params('event', includes, release_status, release_type)
        return self._do_mb_query('event', id, includes, params)

    def get_recording_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_recording_by_id')
        params = self._check_filter_and_make_params('recording', includes, release_status, release_type)
        return self._do_mb_query('recording', id, includes, params)

    def get_release_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_release_by_id')
        params = self._check_filter_and_make_params('release', includes, release_status, release_type)
        return self._do_mb_query('release', id, includes, params)

    def get_release_group_by_id(self, id, includes=[], release_status=[], release_type=[]):
        utils.log('MusicBrainz.get_release_group_by_id')
        params = _check_filter_and_make_params('release-group', includes, release_status, release_type)
        return self._do_mb_query('release-group', id, includes, params)

    def get_series_by_id(self, id, includes=[]):
        utils.log('MusicBrainz.get_series_by_id')
        return self._do_mb_query('series', id, includes)

    def get_work_by_id(self, id, includes=[]):
        utils.log('MusicBrainz.get_work_by_id')
        return self._do_mb_query('work', id, includes)

    def get_url_by_id(self, id, includes=[]):
        utils.log('MusicBrainz.get_url_by_id')
        return self._do_mb_query('url', id, includes)
            
    # Searching

    def search_annotations(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_annotations')
        return self._do_mb_search('annotation', query, fields, limit, offset, strict)

    def search_areas(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_areas')
        return self._do_mb_search('area', query, fields, limit, offset, strict)

    def search_artists(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_artists')
        return self._do_mb_search('artist', query, fields, limit, offset, strict)

    def search_events(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_events')
        return self._do_mb_search('event', query, fields, limit, offset, strict)

    def search_instruments(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_instruments')
        return self._do_mb_search('instrument', query, fields, limit, offset, strict)

    def search_labels(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_labels')
        return self._do_mb_search('label', query, fields, limit, offset, strict)

    def search_places(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_places')
        return self._do_mb_search('place', query, fields, limit, offset, strict)

    def search_recordings(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_recordings')
        return self._do_mb_search('recording', query, fields, limit, offset, strict)

    def search_releases(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_releases')
        return self._do_mb_search('release', query, fields, limit, offset, strict)

    def search_release_groups(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_release_groups')
        return self._do_mb_search('release-group', query, fields, limit, offset, strict)

    def search_series(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_series')
        return self._do_mb_search('series', query, fields, limit, offset, strict)

    def search_works(self, query='', limit=MAX_LIMIT, offset=0, strict=False, **fields):
        utils.log('MusicBrainz.search_works')
        return self._do_mb_search('work', query, fields, limit, offset, strict)
        
mb = MusicBrainz()
