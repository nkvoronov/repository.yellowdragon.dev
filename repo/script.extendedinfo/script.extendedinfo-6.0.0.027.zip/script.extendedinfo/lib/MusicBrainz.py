# -*- coding: utf8 -*-

import re
import time
import urllib.parse

from .fanarttv import ftv
from .coverartarchive import caa

from lib.tools import addon
from lib.tools import utils
from lib.tools import AudioItem
from lib.tools import ItemList
from lib.tools import localdb

URL_BASE = 'https://musicbrainz.org/ws/2/'
BASE_FMT = 'json'
LUCENE_SPECIAL = r'([+\-&|!(){}\[\]\^"~*?:\\\/])'
RELATABLE_TYPES = ['area', 'artist', 'label', 'place', 'event', 'recording', 'release', 'release-group', 'series', 'url', 'work', 'instrument']
RELATION_INCLUDES = [entity + '-rels' for entity in RELATABLE_TYPES]
TAG_INCLUDES = ['tags', 'user-tags']
RATING_INCLUDES = ['ratings', 'user-ratings']
PLUGIN_BASE = 'plugin://script.extendedinfo/?info='
MIN_LIMIT = 25
MAX_LIMIT = 100

VALID_INCLUDES = {
    'area' : ['aliases', 'annotation'] + RELATION_INCLUDES,
    'artist': [
        'recordings', 'releases', 'release-groups', 'works', # Subqueries
        'various-artists', 'discids', 'media', 'isrcs',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'annotation': [

    ],
    'instrument': ['aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES,
    'label': [
        'releases', # Subqueries
        'discids', 'media',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'place' : ['aliases', 'annotation'] + RELATION_INCLUDES + TAG_INCLUDES,
    'event' : ['aliases'] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'recording': [
        'artists', 'releases', # Subqueries
        'discids', 'media', 'artist-credits', 'isrcs',
        'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': [
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': [
        'artists', 'releases', 'discids', 'media',
        'artist-credits', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'series': [
        'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'work': [
        'artists', # Subqueries
        'aliases', 'annotation'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'discid': [ # Discid should be the same as release
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'isrc': ['artists', 'releases', 'puids', 'isrcs'],
    'iswc': ['artists'],
    'collection': ['releases'],
}

VALID_BROWSE_INCLUDES = {
    'artist': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'event': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'label': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'recording': ['artist-credits', 'isrcs'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': ['artist-credits', 'labels', 'recordings', 'isrcs',
                'release-groups', 'media', 'discids'] + RELATION_INCLUDES,
    'place': ['aliases'] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': ['artist-credits'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'work': ['aliases', 'annotation'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
}

#: These can be used to filter whenever releases are includes or browsed
VALID_RELEASE_TYPES = [
    'nat',
    'album', 'single', 'ep', 'broadcast', 'other', # primary types
    'compilation', 'soundtrack', 'spokenword', 'interview', 'audiobook',
    'live', 'remix', 'dj-mix', 'mixtape/street', # secondary types
]
#: These can be used to filter whenever releases or release-groups are involved
VALID_RELEASE_STATUSES = ['official', 'promotion', 'bootleg', 'pseudo-release']

VALID_SEARCH_FIELDS = {
    'annotation': [
        'entity', 'name', 'text', 'type'
    ],
    'area': [
        'aid', 'area', 'alias', 'begin', 'comment', 'end', 'ended',
        'iso', 'iso1', 'iso2', 'iso3', 'type'
    ],
    'artist': [
        'arid', 'artist', 'artistaccent', 'alias', 'begin', 'comment',
        'country', 'end', 'ended', 'gender', 'ipi', 'sortname', 'tag', 'type',
        'area', 'beginarea', 'endarea'
    ],
    'label': [
        'alias', 'begin', 'code', 'comment', 'country', 'end', 'ended',
        'ipi', 'label', 'labelaccent', 'laid', 'sortname', 'type', 'tag',
        'area'
    ],
    'recording': [
        'arid', 'artist', 'artistname', 'creditname', 'comment',
        'country', 'date', 'dur', 'format', 'isrc', 'number',
        'position', 'primarytype', 'puid', 'qdur', 'recording',
        'recordingaccent', 'reid', 'release', 'rgid', 'rid',
        'secondarytype', 'status', 'tnum', 'tracks', 'tracksrelease',
        'tag', 'type', 'video'
    ],
    'release-group': [
        'arid', 'artist', 'artistname', 'comment', 'creditname',
        'primarytype', 'rgid', 'releasegroup', 'releasegroupaccent',
        'releases', 'release', 'reid', 'secondarytype', 'status',
        'tag', 'type'
    ],
    'release': [
        'arid', 'artist', 'artistname', 'asin', 'barcode', 'creditname',
        'catno', 'comment', 'country', 'creditname', 'date', 'discids',
        'discidsmedium', 'format', 'laid', 'label', 'lang', 'mediums',
        'primarytype', 'puid', 'quality', 'reid', 'release', 'releaseaccent',
        'rgid', 'script', 'secondarytype', 'status', 'tag', 'tracks',
        'tracksmedium', 'type'
    ],
    'series': [
        'alias', 'comment', 'sid', 'series', 'type'
    ],
    'work': [
        'alias', 'arid', 'artist', 'comment', 'iswc', 'lang', 'tag',
        'type', 'wid', 'work', 'workaccent'
    ],
}

basestring = (str,bytes)

# https://musicbrainz.org/ws/2/artist?query=accept&fmt=json 
# https://musicbrainz.org/ws/2/release-group?query=accept&fmt=json
# https://musicbrainz.org/ws/2/recording?query=paranoid&fmt=json  

# Exceptions.

class MusicBrainzError(Exception):
    pass

class UsageError(MusicBrainzError):
    pass

class InvalidSearchFieldError(UsageError):
    pass

class InvalidIncludeError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidIncludeError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg

class InvalidFilterError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidFilterError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg
        
class MusicBrainz(object):
    
    def __init__(self, *args, **kwargs):
        utils.log('MusicBrainz.__init__')
        self.sort=None
        self.sort_order=None
        
    def get_field(self, data=None):
        utils.log('MusicBrainz.get_field')
        text = ''
        if data:
            text = data
        return text
        
    def get_subfield(self, data=None, field='name'):
        utils.log('MusicBrainz.get_subfield')
        text = ''
        if data:
            text = self.get_field(data.get(field))
        return text
        
    def get_strlist(self, data=None, field='name', sep=' / ', title=False, lower=False):
        utils.log('MusicBrainz.get_strlist')
        text = ''
        lst = []
        if data:        
            for item in data:
                fld = self.get_field(item.get(field))
                if title:
                    fld = fld.title()
                if lower:
                    fld = fld.lower()
                if fld != '':
                    lst.append(fld)
            text = sep.join(lst)
        return text
       
    def get_array_tostr(self, data=None, sep=', '):
        utils.log('MusicBrainz.get_array_tostr')
        text = ''
        tps = []
        if data:       
            for item in data:
                tps.append(item) 
            text = sep.join(tps)
        return text
        
    def get_description(self, media_type):
        utils.log('MusicBrainz.get_description')
        return ''
       
    def get_artist_credit(self, data=None, field='name'):
        utils.log('MusicBrainz.get_artists')
        text = ''
        artists = []
        if data:        
            for artistcredit in data:
                 artist = self.get_field(artistcredit.get('artist'))
                 if artist != '':
                    artists.append(self.get_field(artist.get(field)))         
            text = ', '.join(artists)
        return text

    def get_releases(self, data=None):
        utils.log('MusicBrainz.get_releases')
        titles = []
        ids = []
        gids = []
        if data:
            for release in data:
                title = self.get_field(release.get('title'))
                if title != '':
                    titles.append(title)
                id = self.get_field(release.get('id'))
                if id != '':
                    ids.append(id)
                release_group = self.get_field(release.get('release-group'))
                if release_group !='':
                    gid = self.get_field(release_group.get('id'))
                    if gid !='':
                        gids.append(gid)
        return titles, ids, gids

    def handle_artist(self, results, sort=True):
        utils.log('MusicBrainz.handle_artist')
        media_type = 'artist'
        artists = ItemList(content_type=media_type)
        path = 'extendedartistinfo&&id=%s'        
        for artist in results:            
            title = self.get_field(artist.get('name'))
            label = title
            genre = self.get_strlist(data=artist.get('tags'),
                                     title=True)
            musicbrainz_artist_id = self.get_field(artist.get('id'))
            artist_born = self.get_subfield(artist.get('life-span'), 'begin')
            artist_died = self.get_subfield(artist.get('life-span'), 'end')
            description = self.get_description(media_type)
            disambiguation = self.get_field(artist.get('disambiguation'))
            artist_type = self.get_field(artist.get('type'))
            artist_sortname = self.get_field(artist.get('sort-name'))            
            artist_gender = self.get_field(artist.get('gender'))
            artist_begin_area =  self.get_subfield(artist.get('begin-area'))
            artist_end_area =  self.get_subfield(artist.get('end-area'))            
            artist_ended = self.get_subfield(artist.get('life-span'), 'ended')
            if artist_ended == 'true':
                artist_ended = True
            else:
                artist_ended = False
            country = self.get_subfield(artist.get('area'))
            if country == '':
                country = str(self.get_field(artist.get('country'))).lower()
            score = self.get_field(artist.get('score'))

            if disambiguation != '':
                label = label + ' (' + disambiguation + ')'
            
            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_artist_id)
            
            item.set_infos({
                'title': title,
                'genre': genre,
                'mediatype': media_type
            })
            
            item.set_properties({
                'mediatype': media_type,
                'musicbrainzartistid': musicbrainz_artist_id,
                'artist_born': artist_born,
                'artist_died': artist_died,            
                'artist_description': description,
                'artist_disambiguation': disambiguation,
                'artist_type': artist_type,
                'artist_sortname': artist_sortname,                 
                'artist_gender': artist_gender,
                'artist_begin_area': artist_begin_area,
                'artist_end_area': artist_end_area,
                'artist_ended': artist_ended,
                'country': country,
                'score': score
            })
            
            item.set_artwork(self.get_image_urls(id=musicbrainz_artist_id, 
                                                 media_type=media_type,
                                                 icon='DefaultMusicArtists.png'))
            
            artists.append(item)
            
        return localdb.merge_with_local(media_type=media_type,
                                        items=artists,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
        
    def handle_album(self, results, sort=True):
        utils.log('MusicBrainz.handle_album')
        media_type = 'album'
        albums = ItemList(content_type=media_type)
        path = 'extendedalbuminfo&&id=%s'
        for album in results:
            title = self.get_field(album.get('title'))
            label = title
            artist = self.get_artist_credit(data=album.get('artist-credit'))
            genre = self.get_strlist(data=album.get('tags'),
                                     title=True)
            year = int(utils.get_year(self.get_field(album.get('first-release-date'))))            
            musicbrainz_release_group_id = self.get_field(album.get('id'))            
            musicbrainz_release_ids = self.get_strlist(data=album.get('releases'), 
                                                       field='id',
                                                       sep=', ')            
            musicbrainz_artist_ids = self.get_artist_credit(data=album.get('artist-credit'),
                                                            field='id')           
            description = self.get_description(media_type)
            primary_type = str(self.get_field(album.get('primary-type'))).lower()           
            secondary_types = str(self.get_array_tostr(data=album.get('secondary-types'))).lower()     
            album_releases = self.get_field(album.get('count'))
            score = self.get_field(album.get('score'))
            
            if artist:
                label = artist + ' - ' + title

            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_release_group_id)
            
            item.set_infos({
                'title': title,
                'artist': artist,
                'genre': genre,
                'year': year,
                'mediatype': media_type
            })
            
            item.set_properties({
                'mediatype': media_type,
                'musicbrainzreleasegroupid': musicbrainz_release_group_id,
                'musicbrainzartistsid': musicbrainz_artist_ids,
                'musicbrainzreleasesid':musicbrainz_release_ids,
                'album_description': description, 
                'album_type': primary_type,
                'album_type2': secondary_types,
                'album_releases': album_releases,           
                'score': score
            })
            
            musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
            item.set_artwork(self.get_image_urls(id=musicbrainz_artist_id, 
                                                 aid=musicbrainz_release_group_id, 
                                                 media_type=media_type, 
                                                 icon='DefaultMusicAlbums.png'))
            
            albums.append(item)

        return localdb.merge_with_local(media_type=media_type,
                                        items=albums,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
        
    def handle_song(self, results, sort=True):
        utils.log('MusicBrainz.handle_song')
        media_type = 'song'
        songs = ItemList(content_type=media_type)
        path = 'extendedsonginfo&&id=%s'
        for song in results:
            title = self.get_field(song.get('title'))
            label = title
            diration = self.get_field(song.get('length'))
            artist = self.get_artist_credit(data=song.get('artist-credit'))
            titles,ids,gds = self.get_releases(song.get('releases'))           
            album = titles[0] 
            genre = self.get_strlist(data=song.get('tags'),
                                     title=True)
            year = int(utils.get_year(self.get_field(song.get('first-release-date'))))            
            musicbrainz_track_id = self.get_field(song.get('id'))
            musicbrainz_artist_ids = self.get_artist_credit(data=song.get('artist-credit'),
                                                            field='id')         
            musicbrainz_release_id = ids[0]
            musicbrainz_group_release_id = gds[0]                                 
            score = self.get_field(song.get('score'))
            
            if artist:
                label = artist + ' - ' + title
            
            item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_track_id)
            
            item.set_infos({
                'title': title,
                'duration': diration,
                'artist': artist,
                'album': album,
                'genre': genre,
                'year': year,
                'mediatype': media_type
            })
            
            item.set_properties({
                'mediatype': media_type,
                'musicbrainztrackid': musicbrainz_track_id,
                'musicbrainzartistids': musicbrainz_artist_ids,
                'musicbrainzreleaseid': musicbrainz_release_id,
                'musicbrainzgroupreleaseid': musicbrainz_group_release_id,
                'score': score
            })
            
            musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
            item.set_artwork(self.get_image_urls(id=musicbrainz_artist_id, 
                                                 aid=musicbrainz_group_release_id, 
                                                 media_type=media_type,
                                                 icon='DefaultMusicSongs.png'))
            
            songs.append(item)

        return localdb.merge_with_local(media_type=media_type,
                                        items=songs,
                                        sort=sort,
                                        sort_by=self.sort,
                                        sort_order=self.sort_order)
                                        
    def extended_artist_info(self, artist_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for movie with *artist_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_artist_info')
        if not artist_id:
            return None
        info = self.get_artist(artist_id=artist_id, cache_days=cache_days)
        if not info:
            utils.notify('Could not get artist information')
            return {}
        media_type = 'artist'
        title = self.get_field(info.get('name'))
        label = title
        genre = self.get_strlist(data=info.get('tags'),
                                 title=True)        
        musicbrainz_artist_id = self.get_field(info.get('id'))
        artist_born = self.get_subfield(info.get('life-span'), 'begin')
        artist_died = self.get_subfield(info.get('life-span'), 'end')
        description = self.get_description(media_type)        
        disambiguation = self.get_field(info.get('disambiguation'))
        artist_type = self.get_field(info.get('type'))
        artist_sortname = self.get_field(info.get('sort-name'))            
        artist_gender = self.get_field(info.get('gender'))
        artist_begin_area =  self.get_subfield(info.get('begin-area'))
        artist_end_area =  self.get_subfield(info.get('end-area'))            
        artist_ended = self.get_subfield(info.get('life-span'), 'ended')
        if artist_ended == 'true':
            artist_ended = True
        else:
            artist_ended = False
        country = self.get_subfield(info.get('area'))
        if country == '':
            country = str(self.get_field(info.get('country'))).lower()

        if disambiguation != '':
                label = label + ' (' + disambiguation + ')'
        
        artist = AudioItem(label=label, path=PLUGIN_BASE + 'youtubevideo&&id=%s' % title)

        artist.set_infos({
                'title': title,
                'genre': genre,
                'mediatype': media_type
        })
            
        artist.set_properties({
                'mediatype': media_type,
                'musicbrainzartistid': musicbrainz_artist_id,
                'artist_born': artist_born,
                'artist_died': artist_died,            
                'artist_description': description,
                'artist_disambiguation': disambiguation,
                'artist_type': artist_type,
                'artist_sortname': artist_sortname,            
                'artist_ended': artist_ended,
                'artist_gender': artist_gender,
                'artist_begin_area': artist_begin_area,
                'artist_end_area': artist_end_area,
                'artist_ended': artist_ended,
                'country': country
        })
            
        artist.set_artwork(self.get_image_urls(id=musicbrainz_artist_id, 
                                               media_type=media_type, 
                                               icon='DefaultMusicArtists.png'))
        
        if dbid:
            local_item = localdb.get_artist(dbid)
            artist.update_from_listitem(local_item)
        else:
            artist = localdb.merge_with_local(media_type, [artist])[0]

        allitems = self.handle_release_group_for_artist(artist_id=artist_id)

        listitems = {'album': self.handle_albums_for_artist_types(items=allitems),
                     'albumcompilation': self.handle_albums_for_artist_types(items=allitems, atype2='compilation'),
                     'albumlive': self.handle_albums_for_artist_types(items=allitems, atype2='live'),
                     'single': self.handle_albums_for_artist_types(items=allitems, atype='single'),
                     'singlelive': self.handle_albums_for_artist_types(items=allitems, atype='single', atype2='live'),
                     'ep': self.handle_albums_for_artist_types(items=allitems, atype='ep'),
                     'eplive': self.handle_albums_for_artist_types(items=allitems, atype='ep', atype2='live'),
        }   
        return (artist, listitems)
        
    def handle_albums_for_artist_types(self, items=None, atype='album', atype2=''):
        media_type = 'album'
        albums_type = ItemList(content_type=media_type)
        for item in items:     
            if item.get_property('album_type') == atype and item.get_property('album_type2') == atype2:
                albums_type.append(item)
        return albums_type
       
    def handle_release_group_for_artist(self, artist_id=None):
        utils.log('MusicBrainz.handle_release_group_for_artist')
        media_type = 'album'
        release_groups = {}
        albums = ItemList(content_type=media_type)
        path = 'extendedalbuminfo&&id=%s'
        params = {'artist': artist_id,
                  'inc': 'artist-credits+release-groups+ratings'
        }
        releases = self.browse_release(params=params)
        for release in releases:
            release_group = release.get('release-group')
            release_group_id = release_group.get('id')
            if release_group_id not in release_groups:
                ids = []
                ids.append(release.get('id'))
                rg = {'release_ids': ids, 
                      'count_releases': 1
                }
                release_groups[release_group_id] = rg
                
                title = self.get_field(release_group.get('title'))
                label = title
                artist = self.get_artist_credit(data=release_group.get('artist-credit'))
                genre = self.get_strlist(data=release_group.get('tags'),
                                         title=True)
                year = int(utils.get_year(self.get_field(release_group.get('first-release-date'))))                
                musicbrainz_release_group_id = release_group_id
                musicbrainz_release_ids = ''
                musicbrainz_artist_ids = self.get_artist_credit(data=release_group.get('artist-credit'),
                                                                field='id')           
                description = self.get_description(media_type)
                primary_type = str(self.get_field(release_group.get('primary-type'))).lower()           
                secondary_types = str(self.get_array_tostr(data=release_group.get('secondary-types'))).lower()
                votes_count = self.get_subfield(release_group.get('rating'), 'votes-count')
                rating = self.get_subfield(release_group.get('rating'), 'value')
                album_releases = 0

                item = AudioItem(label=label, path=PLUGIN_BASE + path % musicbrainz_release_group_id)
                
                item.set_infos({
                    'title': title,
                    'artist': artist,
                    'genre': genre,
                    'year': year,
                    'mediatype': media_type
                })
            
                item.set_properties({
                    'musicbrainzreleasegroupid': musicbrainz_release_group_id,
                    'musicbrainzartistsid': musicbrainz_artist_ids,
                    'musicbrainzreleasesid': musicbrainz_release_ids,
                    'album_description': description, 
                    'album_type': primary_type,
                    'album_type2': secondary_types,
                    'votes-count': votes_count, 
                    'rating': rating, 
                    'album_releases': album_releases
                })
                
                musicbrainz_artist_id = list(musicbrainz_artist_ids.split(', '))[0]
            
                item.set_artwork(self.get_image_urls(id=musicbrainz_artist_id, 
                                                     aid=musicbrainz_release_group_id, 
                                                     media_type=media_type, 
                                                     icon='DefaultMusicAlbums.png'))
            
                albums.append(item)                
            else:
                rg = release_groups[release_group_id]
                ids = list(rg.get('release_ids'))
                ids.append(release.get('id'))
                count = int(rg.get('count_releases'))
                count += 1
                rg = {'release_ids': ids, 
                      'count_releases': count
                }
                release_groups[release_group_id] = rg
                
        for item in albums:
            release_group_id = item.get_property('musicbrainzreleasegroupid')
            rg = release_groups[release_group_id]
            item.set_property('musicbrainzreleasesid', ', '.join(list(rg.get('release_ids'))))
            item.set_property('album_releases', int(rg.get('count_releases')))

        return localdb.merge_with_local(media_type=media_type,
                                        items=albums,
                                        sort=True,
                                        sort_by='album_types/year/title',
                                        sort_order='asc')
        
    def get_artist(self, artist_id, cache_days=30):
        utils.log('MusicBrainz.get_artist')
        includes = []
        return self.get_artist_by_id(id=artist_id,
                                     includes=includes,
                                     cache_days=cache_days)
        
    def get_artist_mb_id(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_artist_mb_id')
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mb_id('artist', dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
        
    def extended_album_info(self, album_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for movie with *album_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_album_info')
        if not album_id:
            return None
        info = self.get_album(album_id=album_id, cache_days=cache_days)
        utils.log(info)
        if not info:
            utils.notify('Could not get album information')
            return {}
        return None
        
    def get_album(self, album_id, cache_days=30):
        utils.log('MusicBrainz.get_album')
        includes = []
        return self.get_release_group_by_id(id=album_id,
                                            includes=includes,
                                            cache_days=cache_days)
        
    def get_album_mb_id(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_album_mb_id')
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mb_id('album', dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return self.get_release_groups_from_release_id(mbid)
        return self.search_media(name) if name else None
        
    def get_release_groups_from_release_id(self, mbid=None):
        utils.log('MusicBrainz.get_release_groups_from_release_id')
        return mbid
        
    def extended_song_info(self, song_id=None, dbid=None, cache_days=14):
        '''
        get listitem with extended info for movie with *song_id
        merge in info from *dbid if available
        '''
        utils.log('MusicBrainz.extended_song_info')
        if not song_id:
            return None
        info = self.get_song(song_id=song_id, cache_days=cache_days)
        utils.log(info)
        if not info:
            utils.notify('Could not get song information')
            return {}
        return None
        
    def get_song(self, song_id, cache_days=30):
        utils.log('MusicBrainz.get_song')
        includes = []
        return self.get_recording_by_id(id=song_id,
                                        includes=includes,
                                        cache_days=cache_days)
       
    def get_song_mb_id(self, mbid=None, dbid=None, name=None):
        utils.log('MusicBrainz.get_song_mb_id')
        if dbid and (int(dbid) > 0):
            mbid = localdb.get_mb_id('song', dbid)
            if mbid:
                utils.log('MB Id from local DB: %s' % (mbid))
                return mbid
        return self.search_media(name) if name else None
        
    def search_media(self, media_name=None, year='', media_type='artist', cache_days=1):
        '''
        return list of items with type *media_type for search with *media_name
        '''
        utils.log('MusicBrainz.search_media')
        return None
        
    def get_image_urls(self, id, media_type, aid=None, icon=None, fanart=None):
        '''
        get a dict with all available images for given image types
        '''
        utils.log('MusicBrainz.get_image_urls')        
        images = {}        
        if icon:
            images['icon'] = icon
        if fanart:
            images['fanart'] = fanart        
        if media_type == 'artist':
            images = ftv.get_music_images(id, images)
        elif media_type == 'album':
            images = ftv.get_music_albums_images(id, aid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(aid, images)
        elif media_type == 'song':
            images = ftv.get_music_albums_images(id, aid, images)
            if images['icon'] == icon:
                images = caa.get_release_group_image_list(aid, images)
        return images
            
    def search(self, search_str, media_type, page=1, sort=None, sort_order=None, cache_days=1):
        utils.log('MusicBrainz.search')
        self.sort = sort
        self.sort_order = sort_order
        offset = (page - 1) * MIN_LIMIT
        if media_type=='artist':
            response = self.search_artists(query=search_str, 
                                           offset=offset, 
                                           cache_days=cache_days)
        elif media_type=='album':
            response = self.search_release_groups(query=search_str, 
                                                  offset=offset, 
                                                  cache_days=cache_days)
        elif media_type=='song':
            response = self.search_recordings(query=search_str, 
                                              offset=offset, 
                                              cache_days=cache_days)
        if response['count'] > 0:
            utils.log('items count %s' % response['count'])        
            if media_type == 'artist':
                itemlist = self.handle_artist(response['artists'])
            elif media_type == 'album':
                itemlist = self.handle_album(response['release-groups'])
            elif media_type == 'song':
                itemlist = self.handle_song(response['recordings'])
            itemlist.set_totals(response['count'])
            itemlist.set_total_pages(response['count'] // MIN_LIMIT + 1)
            utils.log('list items count %s' % len(itemlist))
            return itemlist

    # Helpers for validating and formatting allowed sets.

    def check_includes_impl(self, includes, valid_includes):
        utils.log('MusicBrainz._check_includes_impl')
        for i in includes:
            if i not in valid_includes:
                raise InvalidIncludeError('Bad includes: '
                                          '%s is not a valid include' % i)
    def check_includes(self, entity, inc):
        utils.log('MusicBrainz._check_includes')
        self.check_includes_impl(inc, VALID_INCLUDES[entity])

    def check_filter(self, values, valid):
        utils.log('MusicBrainz._check_filter')
        for v in values:
            if v not in valid:
                raise InvalidFilterError(v)
                
    def check_filter_and_make_params(self, entity, includes, release_status=[], release_type=[]):
        utils.log('MusicBrainz._check_filter_and_make_params')
        if isinstance(release_status, basestring):
            release_status = [release_status]
        if isinstance(release_type, basestring):
            release_type = [release_type]
        self.check_filter(release_status, VALID_RELEASE_STATUSES)
        self.check_filter(release_type, VALID_RELEASE_TYPES)

        if (release_status 
                and 'releases' not in includes and entity != 'release'):
            raise InvalidFilterError('Can''t have a status with no release include')
        if (release_type
                and 'release-groups' not in includes and 'releases' not in includes
                and entity not in ['release-group', 'release']):
            raise InvalidFilterError('Can''t have a release type '
                    'with no releases or release-groups involved')

        # Build parameters.
        params = {}
        if len(release_status):
            params['status'] = '|'.join(release_status)
        if len(release_type):
            params['type'] = '|'.join(release_type)
        return params

    def get_data(self, url='', params=None, cache_days=14):
        utils.log('MusicBrainz.get_data')
        params = params if params else {}
        params['fmt'] = BASE_FMT
        params = {k: v for k, v in params.items() if v}
        url = '%s%s?%s' % (URL_BASE, url, urllib.parse.urlencode(params))
        utils.log(url)
        return utils.get_JSON_response(url=url,
                                       cache_days=cache_days, 
                                       folder='MusicBrainz')

    def get_query(self, entity, id='', includes=[], params={}, cache_days=14):
        utils.log('MusicBrainz.get_query')
        # Build arguments.
        if not isinstance(includes, list):
            includes = [includes]
        self.check_includes(entity, includes)
        params = dict(params)
        if len(includes) > 0:
            inc = ' '.join(includes)
            params['inc'] = inc

        # Build the endpoint components.
        if id == '':
            url = entity
        else:
            url = '%s/%s' % (entity, id)

        return self.get_data(url=url, 
                             params=params,
                             cache_days=cache_days)
            
    def get_search(self, entity, query='', fields={}, limit=MIN_LIMIT, offset=0, strict=False, cache_days=14):
        utils.log('MusicBrainz.get_search')
        # Encode the query terms as a Lucene query string.
        query_parts = []
        if query:
            # clean_query = util._unicode(query)
            clean_query = query
            if fields:
                clean_query = re.sub(LUCENE_SPECIAL, r'\\\1', clean_query)
                if strict:
                    query_parts.append('"%s"' % clean_query)
                else:
                    query_parts.append(clean_query.lower())
            else:
                query_parts.append(clean_query)
        for key, value in fields.items():
            # Ensure this is a valid search field.
            if key not in VALID_SEARCH_FIELDS[entity]:
                raise InvalidSearchFieldError(
                    '%s is not a valid search field for %s' % (key, entity)
                )
            elif key == 'puid':
                warn('PUID support was removed from server\n'
                     'the "puid" field is ignored',
                     Warning, stacklevel=2)

            # Escape Lucene's special characters.
            # value = util._unicode(value)
            value = re.sub(LUCENE_SPECIAL, r'\\\1', value)
            if value:
                if strict:
                    query_parts.append('%s:"%s"' % (key, value))
                else:
                    value = value.lower() # avoid AND / OR
                    query_parts.append('%s:(%s)' % (key, value))
        if strict:
            full_query = ' AND '.join(query_parts).strip()
        else:
            full_query = ' '.join(query_parts).strip()

        if not full_query:
            raise ValueError('at least one query term is required')

        # Additional parameters to the search.
        params = {'query': full_query}
        if limit:
            params['limit'] = str(limit)
        if offset:
            params['offset'] = str(offset)

        return self.get_query(entity=entity, 
                              params=params,
                              cache_days=cache_days)
        
    # Single entity by ID

    def get_area_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_area_by_id')
        params = self.check_filter_and_make_params(entity='area', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='area', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_artist_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_artist_by_id')
        params = self.check_filter_and_make_params('artist', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='artist', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_instrument_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_instrument_by_id')
        params = self.check_filter_and_make_params(entity='instrument', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='instrument', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_label_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_label_by_id')
        params = self.check_filter_and_make_params(entity='label', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='label', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_place_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_place_by_id')
        params = self.check_filter_and_make_params(entity='place', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='place', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_event_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_event_by_id')
        params = self.check_filter_and_make_params(entity='event', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='event', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_recording_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_recording_by_id')
        params = self.check_filter_and_make_params(entity='recording', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='recording', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_release_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_release_by_id')
        params = self.check_filter_and_make_params(entity='release', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='release', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_release_group_by_id(self, id, includes=[], release_status=[], release_type=[], cache_days=14):
        utils.log('MusicBrainz.get_release_group_by_id')
        params = self.check_filter_and_make_params(entity='release-group', 
                                                   includes=includes, 
                                                   release_status=release_status, 
                                                   release_type=release_type)
        return self.get_query(entity='release-group', 
                              id=id, 
                              includes=includes, 
                              params=params,
                              cache_days=cache_days)

    def get_series_by_id(self, id, includes=[], cache_days=14):
        utils.log('MusicBrainz.get_series_by_id')
        return self.get_query(entity='series', 
                              id=id, 
                              includes=includes,
                              cache_days=cache_days)

    def get_work_by_id(self, id, includes=[], cache_days=14):
        utils.log('MusicBrainz.get_work_by_id')
        return self.get_query(entity='work', 
                              id=id, 
                              includes=includes,
                              cache_days=cache_days)

    def get_url_by_id(self, id, includes=[], cache_days=14):
        utils.log('MusicBrainz.get_url_by_id')
        return self.get_query(entity='url', 
                              id=id, 
                              includes=includes,
                              cache_days=cache_days)
            
    # Searching

    def search_annotations(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_annotations')
        return self.get_search(entity='annotation', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_areas(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_areas')
        return self.get_search(entity='area', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_artists(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_artists')
        return self.get_search(entity='artist', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_events(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_events')
        return self.get_search(entity='event', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_instruments(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_instruments')
        return self.get_search(entity='instrument', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_labels(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_labels')
        return self.get_search(entity='label', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_places(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_places')
        return self.get_search(entity='place', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_recordings(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_recordings')
        return self.get_search(entity='recording', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_releases(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_releases')
        return self.get_search(entity='release', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_release_groups(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_release_groups')
        return self.get_search(entity='release-group', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_series(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_series')
        return self.get_search(entity='series', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)

    def search_works(self, query='', limit=MIN_LIMIT, offset=0, strict=False, cache_days=14, **fields):
        utils.log('MusicBrainz.search_works')
        return self.get_search(entity='work', 
                               query=query, 
                               fields=fields, 
                               limit=limit, 
                               offset=offset, 
                               strict=strict,
                               cache_days=cache_days)
        
    # Browseing and Other
    
    def browse_release_groups(self, artist_id, atype='album', offset=0):
        utils.log('MusicBrainz.browse_release_groups')
        params = {'artist': artist_id,
                  'type': atype,
                  'inc': 'artist-credits',
                  'offset': offset, 
                  'limit': MAX_LIMIT
        }
        return self.get_data(url='release-group', 
                             params=params)
                             
    def browse_release(self, params=None):
        utils.log('MusicBrainz.browse_release')
        offset = 0
        releases = []
        params = params if params else {}
        params['offset'] = offset
        params['limit'] = MAX_LIMIT
        
        response = self.get_data(url='release', 
                                 params=params)
        count = response['release-count']
        if count > 0:
            releases = response.get('releases')
            while(offset + MAX_LIMIT < count):
                offset += MAX_LIMIT                
                params['offset'] = offset
                response = self.get_data(url='release',
                                         params=params)
                releases = releases + response.get('releases')
        return releases
        
    def get_all_genres(self):
        utils.log('MusicBrainz.get_all_genres')
        offset = 0
        genres = []
        params = params if params else {}
        params['offset'] = offset
        params['limit'] = MAX_LIMIT
        
        response = self.get_data(url='genre/all', 
                                 params=params)
        count = response['genre-count']
        if count > 0:
            genres = response.get('genres')
            while(offset + MAX_LIMIT < count):
                offset += MAX_LIMIT                
                params['offset'] = offset
                response = self.get_data(url='genre/all',
                                         params=params)
                genres = genres + response.get('genres')
        return genres
        
mb = MusicBrainz()
