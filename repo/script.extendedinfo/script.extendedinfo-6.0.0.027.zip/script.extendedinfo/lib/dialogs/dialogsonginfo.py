# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import unicode_literals

import xbmcgui

from lib.musicbrainz import mb
from lib.dialogs import DialogMusicInfo

from lib.tools import imagetools
from lib.tools import addon
from lib.tools import utils
from lib.tools import ActionHandler

ID_CONTROL_PLOT = 132

chm = ActionHandler(type='music')

class DialogSongInfo(DialogMusicInfo):

    TYPE = 'Song'
    
    TYPE_ALT = 'song'

    LISTS = []
    
    def __init__(self, *args, **kwargs):
        utils.log('DialogSongInfo.__init__')
        super(DialogSongInfo, self).__init__(*args, **kwargs)
        data = mb.extended_song_info(song_id=kwargs.get('id'))
        if not data:
            return None
        self.info, self.lists = data
        self.info.update_properties(imagetools.blur(self.info.get_art('thumb')))

    def onInit(self):
        utils.log('DialogSongInfo.onInit')
        self.get_youtube_vids(self.info.label)
        super(DialogSongInfo, self).onInit()

    def onClick(self, control_id):
        utils.log('DialogSongInfo.onClick')
        super(DialogSongInfo, self).onClick(control_id)
        chm.serve(control_id, self)
        
    @chm.click(ID_CONTROL_PLOT)
    def show_plot(self, control_id):
        utils.log('DialogSongInfo.show_plot')
        xbmcgui.Dialog().textviewer(heading=addon.LANG(32037),
                                    text=self.info.get_property('biography'))