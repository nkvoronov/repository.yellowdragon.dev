# -*- coding: utf8 -*-

import urllib.parse
import re

from lib.tools import addon
from lib.tools import utils
from lib.tools import ItemList

BASE_URL = 'https://api.discogs.com/'

def get_data():
	return None