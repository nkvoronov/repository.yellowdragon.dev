# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import xbmcgui

from lib.tools import utils

class WindowXML(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        utils.log('WindowXML.__init__')
        super(WindowXML, self).__init__()
        self.window_type = 'window'
        self.cancelled = False

    def onInit(self):
        utils.log('WindowXML.onInit')
        self.window_id = xbmcgui.getCurrentWindowId()

    def FocusedItem(self, control_id):
        utils.log('WindowXML.FocusedItem')
        try:
            control = self.getControl(control_id)
            listitem = control.getSelectedItem()
            if not listitem:
                listitem = self.getListItem(self.getCurrentListPosition())
            return listitem
        except Exception:
            return None

    def set_visible(self, control_id, condition):
        utils.log('WindowXML.set_visible')
        try:
            self.getControl(control_id).setVisible(bool(condition))
            return True
        except Exception:
            return False

    def check_visible(self, control_id):
        utils.log('WindowXML.check_visible')
        try:
            self.getControl(control_id)
            return True
        except Exception:
            return False

    def exit(self):
        utils.log('WindowXML.exit')
        self.cancelled = True
        self.close()

class DialogXML(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        utils.log('DialogXML.__init__')
        super(DialogXML, self).__init__()
        self.window_type = 'dialog'
        self.cancelled = False

    def onInit(self):
        utils.log('DialogXML.onInit')
        self.window_id = xbmcgui.getCurrentWindowDialogId()

    def FocusedItem(self, control_id):
        utils.log('DialogXML.FocusedItem')
        try:
            control = self.getControl(control_id)
            listitem = control.getSelectedItem()
            if not listitem:
                listitem = self.getListItem(self.getCurrentListPosition())
            return listitem
        except Exception:
            return None

    def set_visible(self, control_id, condition):
        utils.log('DialogXML.set_visible')
        try:
            self.getControl(control_id).setVisible(bool(condition))
            return True
        except Exception:
            return False

    def check_visible(self, control_id):
        utils.log('DialogXML.check_visible')
        try:
            self.getControl(control_id)
            return True
        except Exception:
            return False

    def exit(self):
        utils.log('DialogXML.exit')
        self.cancelled = True
        self.close()
