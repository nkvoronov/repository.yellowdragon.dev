# -*- coding: utf8 -*-

import urllib.parse
import re
import json
import xbmcgui
from urllib.parse import urlunparse, urlencode
from lib import FanartTV as ft
from lib import CoverArtArchive as caa

from lib.tools import addon
from lib.tools import utils
from lib.tools import ItemList
from lib.tools import AudioItem

BASE_HOSTNAME = 'musicbrainz.org'
BASE_FMT = 'json'
LUCENE_SPECIAL = r'([+\-&|!(){}\[\]\^"~*?:\\\/])'
RELATABLE_TYPES = ['area', 'artist', 'label', 'place', 'event', 'recording', 'release', 'release-group', 'series', 'url', 'work', 'instrument']
RELATION_INCLUDES = [entity + '-rels' for entity in RELATABLE_TYPES]
TAG_INCLUDES = ['tags', 'user-tags']
RATING_INCLUDES = ['ratings', 'user-ratings']
PLUGIN_BASE = 'plugin://script.extendedinfo/?info='

VALID_INCLUDES = {
    'area' : ['aliases', 'annotation'] + RELATION_INCLUDES,
    'artist': [
        'recordings', 'releases', 'release-groups', 'works', # Subqueries
        'various-artists', 'discids', 'media', 'isrcs',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'annotation': [

    ],
    'instrument': ['aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES,
    'label': [
        'releases', # Subqueries
        'discids', 'media',
        'aliases', 'annotation'
    ] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'place' : ['aliases', 'annotation'] + RELATION_INCLUDES + TAG_INCLUDES,
    'event' : ['aliases'] + RELATION_INCLUDES + TAG_INCLUDES + RATING_INCLUDES,
    'recording': [
        'artists', 'releases', # Subqueries
        'discids', 'media', 'artist-credits', 'isrcs',
        'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': [
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': [
        'artists', 'releases', 'discids', 'media',
        'artist-credits', 'annotation', 'aliases'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'series': [
        'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'work': [
        'artists', # Subqueries
        'aliases', 'annotation'
    ] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'discid': [ # Discid should be the same as release
        'artists', 'labels', 'recordings', 'release-groups', 'media',
        'artist-credits', 'discids', 'puids', 'isrcs',
        'recording-level-rels', 'work-level-rels', 'annotation', 'aliases'
    ] + RELATION_INCLUDES,
    'isrc': ['artists', 'releases', 'puids', 'isrcs'],
    'iswc': ['artists'],
    'collection': ['releases'],
}
VALID_BROWSE_INCLUDES = {
    'artist': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'event': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'label': ['aliases'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'recording': ['artist-credits', 'isrcs'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'release': ['artist-credits', 'labels', 'recordings', 'isrcs',
                'release-groups', 'media', 'discids'] + RELATION_INCLUDES,
    'place': ['aliases'] + TAG_INCLUDES + RELATION_INCLUDES,
    'release-group': ['artist-credits'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
    'url': RELATION_INCLUDES,
    'work': ['aliases', 'annotation'] + TAG_INCLUDES + RATING_INCLUDES + RELATION_INCLUDES,
}

#: These can be used to filter whenever releases are includes or browsed
VALID_RELEASE_TYPES = [
    'nat',
    'album', 'single', 'ep', 'broadcast', 'other', # primary types
    'compilation', 'soundtrack', 'spokenword', 'interview', 'audiobook',
    'live', 'remix', 'dj-mix', 'mixtape/street', # secondary types
]
#: These can be used to filter whenever releases or release-groups are involved
VALID_RELEASE_STATUSES = ['official', 'promotion', 'bootleg', 'pseudo-release']
VALID_SEARCH_FIELDS = {
    'annotation': [
        'entity', 'name', 'text', 'type'
    ],
    'area': [
        'aid', 'area', 'alias', 'begin', 'comment', 'end', 'ended',
        'iso', 'iso1', 'iso2', 'iso3', 'type'
    ],
    'artist': [
        'arid', 'artist', 'artistaccent', 'alias', 'begin', 'comment',
        'country', 'end', 'ended', 'gender', 'ipi', 'sortname', 'tag', 'type',
        'area', 'beginarea', 'endarea'
    ],
    'label': [
        'alias', 'begin', 'code', 'comment', 'country', 'end', 'ended',
        'ipi', 'label', 'labelaccent', 'laid', 'sortname', 'type', 'tag',
        'area'
    ],
    'recording': [
        'arid', 'artist', 'artistname', 'creditname', 'comment',
        'country', 'date', 'dur', 'format', 'isrc', 'number',
        'position', 'primarytype', 'puid', 'qdur', 'recording',
        'recordingaccent', 'reid', 'release', 'rgid', 'rid',
        'secondarytype', 'status', 'tnum', 'tracks', 'tracksrelease',
        'tag', 'type', 'video'
    ],
    'release-group': [
        'arid', 'artist', 'artistname', 'comment', 'creditname',
        'primarytype', 'rgid', 'releasegroup', 'releasegroupaccent',
        'releases', 'release', 'reid', 'secondarytype', 'status',
        'tag', 'type'
    ],
    'release': [
        'arid', 'artist', 'artistname', 'asin', 'barcode', 'creditname',
        'catno', 'comment', 'country', 'creditname', 'date', 'discids',
        'discidsmedium', 'format', 'laid', 'label', 'lang', 'mediums',
        'primarytype', 'puid', 'quality', 'reid', 'release', 'releaseaccent',
        'rgid', 'script', 'secondarytype', 'status', 'tag', 'tracks',
        'tracksmedium', 'type'
    ],
    'series': [
        'alias', 'comment', 'sid', 'series', 'type'
    ],
    'work': [
        'alias', 'arid', 'artist', 'comment', 'iswc', 'lang', 'tag',
        'type', 'wid', 'work', 'workaccent'
    ],
}

basestring = (str,bytes)
mb_cache_days = 1

# https://musicbrainz.org/ws/2/artist?query=accept&fmt=json 
# https://musicbrainz.org/ws/2/release-group?query=accept&fmt=json
# https://musicbrainz.org/ws/2/recording?query=paranoid&fmt=json  

# Exceptions.

class MusicBrainzError(Exception):
    pass

class UsageError(MusicBrainzError):
    pass

class InvalidSearchFieldError(UsageError):
    pass

class InvalidIncludeError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidIncludeError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg

class InvalidFilterError(UsageError):
    def __init__(self, msg='Invalid Includes', reason=None):
        super(InvalidFilterError, self).__init__(self)
        self.msg = msg
        self.reason = reason

    def __str__(self):
        return self.msg
        
def get_tags(data):
    text = ''
    if data:
        tags = []
        for tag in data:
            tags.append(tag.get('name').title())
        text = ' / '.join(tags)
    return text  
    
def get_artists(data):
    text = ''
    if data:
        artists = []
        for artistcredit in data:
            artists.append(artistcredit.get('artist').get('name'))
        text = ', '.join(artists)
    return text
    
def get_artist(data):
    title = None
    if data:
        if data[0].get('artist'):
            title = data[0].get('artist').get('name')
    return title
    
def get_artist_id(data):
    id = None
    if data:
        if data[0].get('artist'):
            id = data[0].get('artist').get('id')
    return id
    
def get_album(data):
    title = None
    if data:
        title = data[0].get('title')
    return title
    
def get_album_ids(data):
    id = None
    gid = None
    if data:
        id = data[0].get('id')
        if data[0].get('release-group'):
            gid = data[0].get('release-group').get('id')
    return id, gid
    
def get_secondary_types(data):
    tp = None
    if data:
        tps = []
        for item in data:
            tps.append(item) 
        tp = ', '.join(tps)
    return tp

def handle_search(results, media_type):
    utils.log('handle_search')
    if media_type == 'artist':
        listitems = handle_artist(results['artists'])
    elif media_type == 'album':
        listitems = handle_album(results['release-groups'])
    elif media_type == 'song':
        listitems = handle_song(results['recordings'])   
    return listitems
    
def handle_artist(results, local_first=True, sortkey='score'):
    utils.log('handle_artist')
    artists = ItemList(content_type='artist')
    path = 'extendedinfo&&id=%s'
    for artist in results:
        id = artist.get('id')
        title = artist.get('name')
        tags = get_tags(artist.get('tags'))
        country = artist.get('country')        
        
        item = AudioItem(label=title, path=PLUGIN_BASE + path % artist.get('id'))
        
        item.set_infos({
            'title': title,
            'genre': tags,
            'mediatype': 'artist'
        })
        
        item.set_properties({
            'id': id,
            'type-id': artist.get('type-id'),
            'score': artist.get('score'),
            'country': country,
            'mediatype': 'artist',
            'Artist_Type': artist.get('type'),
            'Artist_Sortname': artist.get('sort-name'),
            'Artist_Disambiguation': artist.get('disambiguation'),
            'Artist_Born': artist.get('life-span').get('begin'),
            'Artist_Died': artist.get('life-span').get('end'),
            'Artist_Ended': artist.get('life-span').get('ended')            
        })
        
        item.set_artwork(get_image_urls(id=id, mediatype='artist', icon='DefaultMusicArtists.png'))
        
        artists.append(item)
    return artists
    
def handle_album(results, local_first=True, sortkey='score'):
    utils.log('handle_album')
    albums = ItemList(content_type='album')
    path = 'extendedinfo&&id=%s'
    for album in results:
        id = album.get('id')
        title = album.get('title')
        tags = get_tags(album.get('tags'))
        artist = get_artist(album.get('artist-credit'))
        aid = get_artist_id(album.get('artist-credit'))
        secondary_types = get_secondary_types(album.get('secondary-types'))
        label = title
        if artist:
            label = artist + ' - ' + title

        item = AudioItem(label=label, path=PLUGIN_BASE + path % album.get('id'))
        
        item.set_infos({
            'title': title,
            'artist': artist,
            'genre': tags,
            'year': utils.get_year(album.get('first-release-date')),
            'mediatype': 'album'
        })
        
        item.set_properties({
            'id': id,
            'type-id': album.get('type-id'),
            'artist_id': aid,
            'score': album.get('score'),
            'mediatype': 'album',
            'Album_Type': album.get('primary-type'),
            'Album_Count': album.get('count'),
            'Album_Subtype': secondary_types
        })
        
        item.set_artwork(get_image_urls(id=aid, aid=id, mediatype='album', icon='DefaultMusicAlbums.png'))
        
        albums.append(item)
    return albums
    
def handle_song(results, local_first=True, sortkey='score'):
    utils.log('handle_song')
    songs = ItemList(content_type='song')
    path = 'extendedinfo&&id=%s'
    for song in results:
        id = song.get('id')
        title = song.get('title')
        tags = get_tags(song.get('tags'))
        artist = get_artist(song.get('artist-credit'))
        album = get_album(song.get('releases'))
        aid = get_artist_id(song.get('artist-credit'))
        rid,gid = get_album_ids(song.get('releases'))
        if song.get('length'):
            diration = song.get('length')
        else:
            diration = None            
        label = title
        if artist:
            label = artist + ' - ' + title
        
        item = AudioItem(label=label, path=PLUGIN_BASE + path % song.get('id'))
        
        item.set_infos({
            'title': title,
            'duration': diration,
            'artist': artist,
            'album': album,
            'year': utils.get_year(song.get('first-release-date')),
            'genre': tags,
            'mediatype': 'song',
        })
        
        item.set_properties({
            'id': id,
            'artist_id': aid,
            'release_id': rid,
            'release_group_id': gid,
            'score': song.get('score'),
            'mediatype': 'song',
        })
        
        item.set_artwork(get_image_urls(id=aid, aid=gid, mediatype='song', icon='DefaultMusicSongs.png'))
        
        songs.append(item)
    return songs
    
def get_image_urls(id, mediatype, aid=None,icon=None, fanart=None):
    utils.log('get_image_urls')
    
    images = {}
    
    if icon:
        images['icon'] = icon
    if fanart:
        images['fanart'] = fanart
    
    if mediatype == 'artist':
        images = ft.get_music_images(id, images)
    elif mediatype == 'album':
        images = ft.get_music_albums_images(id, aid, images)
        if images['icon'] == icon:
            images = caa.get_release_group_image_list(aid, images)
    elif mediatype == 'song':
        images = ft.get_music_albums_images(id, aid, images)
        if images['icon'] == icon:
            images = caa.get_release_group_image_list(aid, images)
    return images
        
def search(search_str, media_type, page=1, cache_days=1):
    utils.log('search')
    offset = (page - 1) * 24
    mb_cache_days = cache_days
    if media_type=='artist':
        response = search_artists(query=search_str, offset=offset)
    elif media_type=='album':
        response = search_release_groups(query=search_str, offset=offset)
    elif media_type=='song':
        response = search_recordings(query=search_str, offset=offset)
    if response['count'] > 0:
        utils.log('items count %s' % response['count'])
        itemlist = handle_search(response, media_type)
        itemlist.set_totals(response['count'])
        total_page = response['count'] // 24 + 1
        itemlist.set_total_pages(total_page)
        utils.log('list items count %s' % len(itemlist))
        return itemlist

# Helpers for validating and formatting allowed sets.

def _check_includes_impl(includes, valid_includes):
    for i in includes:
        if i not in valid_includes:
            raise InvalidIncludeError('Bad includes: '
                                      '%s is not a valid include' % i)
def _check_includes(entity, inc):
    _check_includes_impl(inc, VALID_INCLUDES[entity])

def _check_filter(values, valid):
    for v in values:
        if v not in valid:
            raise InvalidFilterError(v)
            
def _check_filter_and_make_params(entity, includes, release_status=[], release_type=[]):
    if isinstance(release_status, basestring):
        release_status = [release_status]
    if isinstance(release_type, basestring):
        release_type = [release_type]
    _check_filter(release_status, VALID_RELEASE_STATUSES)
    _check_filter(release_type, VALID_RELEASE_TYPES)

    if (release_status
            and 'releases' not in includes and entity != 'release'):
        raise InvalidFilterError("Can't have a status with no release include")
    if (release_type
            and 'release-groups' not in includes and 'releases' not in includes
            and entity not in ['release-group', 'release']):
        raise InvalidFilterError("Can't have a release type "
                "with no releases or release-groups involved")

    # Build parameters.
    params = {}
    if len(release_status):
        params['status'] = '|'.join(release_status)
    if len(release_type):
        params['type'] = '|'.join(release_type)
    return params

def _mb_request(path, client_required=False, args=None, data=None, body=None):
    if args is None:
        args = {}
    else:
        args = dict(args) or {}

    args['fmt'] = BASE_FMT

    # Convert args from a dictionary to a list of tuples
    # so that the ordering of elements is stable for easy
    # testing (in this case we order alphabetically)
    # Encode Unicode arguments using UTF-8.
    newargs = []
    for key, value in sorted(args.items()):
        if isinstance(value, str):
            value = value.encode('utf8')
        newargs.append((key, value))

    # Construct the full URL for the request, including hostname and
    # query string.
    url = urlunparse((
        'http',
        BASE_HOSTNAME,
        '/ws/2/%s' % path,
        '',
        urlencode(newargs),
        ''
    ))
    utils.log('%s' % (url))
    
    return utils.get_JSON_response(url=url, cache_days=mb_cache_days, folder='MusicBrainz')

def _do_mb_query(entity, id, includes=[], params={}):
    # Build arguments.
    if not isinstance(includes, list):
        includes = [includes]
    _check_includes(entity, includes)
    args = dict(params)
    if len(includes) > 0:
        inc = ' '.join(includes)
        args['inc'] = inc

    # Build the endpoint components.
    path = '%s/%s' % (entity, id)

    return _mb_request(path, args=args)
        
def _do_mb_search(entity, query='', fields={}, limit=25, offset=0, strict=False):
    # Encode the query terms as a Lucene query string.
    query_parts = []
    if query:
        # clean_query = util._unicode(query)
        clean_query = query
        if fields:
            clean_query = re.sub(LUCENE_SPECIAL, r'\\\1',
                         clean_query)
            if strict:
                query_parts.append('"%s"' % clean_query)
            else:
                query_parts.append(clean_query.lower())
        else:
            query_parts.append(clean_query)
    for key, value in fields.items():
        # Ensure this is a valid search field.
        if key not in VALID_SEARCH_FIELDS[entity]:
            raise InvalidSearchFieldError(
                '%s is not a valid search field for %s' % (key, entity)
            )
        elif key == 'puid':
            warn('PUID support was removed from server\n'
                 'the "puid" field is ignored',
                 Warning, stacklevel=2)

        # Escape Lucene's special characters.
        # value = util._unicode(value)
        value = re.sub(LUCENE_SPECIAL, r'\\\1', value)
        if value:
            if strict:
                query_parts.append('%s:"%s"' % (key, value))
            else:
                value = value.lower() # avoid AND / OR
                query_parts.append('%s:(%s)' % (key, value))
    if strict:
        full_query = ' AND '.join(query_parts).strip()
    else:
        full_query = ' '.join(query_parts).strip()

    if not full_query:
        raise ValueError('at least one query term is required')

    # Additional parameters to the search.
    params = {'query': full_query}
    if limit:
        params['limit'] = str(limit)
    if offset:
        params['offset'] = str(offset)

    return _do_mb_query(entity, '', [], params)
    
# Single entity by ID

def get_area_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('area', includes,
                                           release_status, release_type)
    return _do_mb_query('area', id, includes, params)

def get_artist_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('artist', includes,
                                           release_status, release_type)
    return _do_mb_query('artist', id, includes, params)

def get_instrument_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('instrument', includes,
                                           release_status, release_type)
    return _do_mb_query('instrument', id, includes, params)

def get_label_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('label', includes,
                                           release_status, release_type)
    return _do_mb_query('label', id, includes, params)

def get_place_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('place', includes,
                                           release_status, release_type)
    return _do_mb_query('place', id, includes, params)

def get_event_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('event', includes,
                                           release_status, release_type)
    return _do_mb_query('event', id, includes, params)

def get_recording_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('recording', includes,
                                           release_status, release_type)
    return _do_mb_query('recording', id, includes, params)

def get_release_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('release', includes,
                                           release_status, release_type)
    return _do_mb_query('release', id, includes, params)

def get_release_group_by_id(id, includes=[], release_status=[], release_type=[]):
    params = _check_filter_and_make_params('release-group', includes,
                                           release_status, release_type)
    return _do_mb_query('release-group', id, includes, params)

def get_series_by_id(id, includes=[]):
    return _do_mb_query('series', id, includes)

def get_work_by_id(id, includes=[]):
    return _do_mb_query('work', id, includes)

def get_url_by_id(id, includes=[]):
    return _do_mb_query('url', id, includes)
        
# Searching

def search_annotations(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('annotation', query, fields, limit, offset, strict)

def search_areas(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('area', query, fields, limit, offset, strict)

def search_artists(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('artist', query, fields, limit, offset, strict)

def search_events(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('event', query, fields, limit, offset, strict)

def search_instruments(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('instrument', query, fields, limit, offset, strict)

def search_labels(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('label', query, fields, limit, offset, strict)

def search_places(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('place', query, fields, limit, offset, strict)

def search_recordings(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('recording', query, fields, limit, offset, strict)

def search_releases(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('release', query, fields, limit, offset, strict)

def search_release_groups(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('release-group', query, fields, limit, offset, strict)

def search_series(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('series', query, fields, limit, offset, strict)

def search_works(query='', limit=24, offset=0, strict=False, **fields):
    return _do_mb_search('work', query, fields, limit, offset, strict)

